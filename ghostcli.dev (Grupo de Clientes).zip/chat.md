# Exportação de conversas do WhatsApp: ghostcli.dev (Grupo de Clientes)
Data de exportação: 13 de setembro de 2026 às 23:16

---

## 30 de julho de 2026

[5:09] __Castro Kwai criou o grupo__

---

## 31 de agosto de 2026

[22:52] __As mensagens e as ligações são protegidas com a criptografia de ponta a ponta e ficam somente entre você e os participantes desta conversa. Nem mesmo o WhatsApp pode lê-las ou ouvi-las. Toque para saber mais.__

[22:52] __Você entraram usando o link de convite__

[23:16] **+55 11 98099-6397:** Manutenção temporária

[23:17] __[Notificação do sistema]__

---

## 1 de setembro de 2026

[0:57] **+55 47 9618-4437:** Serviço normalizado.

[2:23] __+55 11 93449-7547 entraram usando o link de convite__

[3:09] __+94 77 862 7664 entraram usando o link de convite__

[3:36] **+55 21 98102-9583:** boa noite/bom dia, pessoal! Uma dúvida, não fica gravado o contexto da conversa após a ativação do ghostcli? Pergunto porque reparei que não há o "acúmulo" de contexto no VS Code e, paralelamente, estou tendo uns problemas de alucinação/burrice do sistema por isso. Fui cobrar um prompt que dei no início do chat e ele acusou que "nunca foi dado esse prompt". Conseguiriam me ajudar quanto a isso?

[4:17] **+94 77 862 7664:** I want to buy this one.how can i trust this?

[4:19] **+356 7737 9669:**
> _+94 77 862 7664: I want to buy this one.how can i trust this?_
Fully legit am using  from eu and am super happy

[4:20] **+63 926 268 4844:**
> _+94 77 862 7664: I want to buy this one.how can i trust this?_
+1

[4:25] **+94 77 862 7664:** [Imagem] Because I always get stuck in situations like this. I can't do anything properly. Is this a solution for me regarding the usage limit?

[4:35] **+356 7737 9669:** Yes buy subscribe  and install like on guide  enjoy  no limits

[6:46] __+55 51 8955-8864 entraram usando o link de convite__

[6:56] __@Hapoxa entraram usando o link de convite__

[10:27] **+55 81 9575-5362:** Pessoal, alguém tá tendo problema com a API depois da atualização?

[10:27] **+55 81 9575-5362:** No meu VSCode ele pensa e não tá mais tendo output

[10:30] **+63 926 268 4844:**
> _+94 77 862 7664: Imagem: Because I always get stuck in situations like this. I can't do anything properly. Is this a solution for me regarding the usage limit?_
you use free trial plan?

[11:17] **+55 21 98102-9583:**
> _+55 81 9575-5362: No meu VSCode ele pensa e não tá mais tendo output_
Acho que foi exatamente o que aconteceu comigo ontem e ele aparentemente só está trocando as mensagens, não guardando contexto

[11:18] **+55 81 9575-5362:** O meu nem me responder tá respondendo

[11:19] **+55 81 9575-5362:**
> _+55 21 98102-9583: Acho que foi exatamente o que aconteceu comigo ontem e ele aparentemente só está trocando as mensagens, não guardando contexto_
Tu ta usando no vscode também?

[11:20] **+55 35 9946-8945:** Sempre fui mais dev raiz, to aprendendo as coisas de IA ainda, vale muito o contexto que você passa para a API, de fato o system prompt, ele apenas pela api tende a não entender muita coisa! Diferente de um plano que já refinado.

Resumo, refinar melhor o contexto e system prompt pode ajudar

[11:21] **Jk Cli:**
> _+55 21 98102-9583: Acho que foi exatamente o que aconteceu comigo ontem e ele aparentemente só está trocando as mensagens, não guardando contexto_
Vamos investigar isso

[11:21] **Jk Cli:** Qualquer coisa lançamos uma att

[11:22] **+55 81 9575-5362:**
> _Jk Cli: Qualquer coisa lançamos uma att_
Show mestre, quando tiver algum retorno avisa por favor que desde a atualização não conseguir mais fazer nada com a IA, tô fazendo tudo na mão

[11:24] **+55 21 98102-9583:**
> _+55 81 9575-5362: Tu ta usando no vscode também?_
Isso, na madrugada passei um bocado de raiva com isso e percebi que não estava guardando o “acúmulo” do uso de token. Como comecei a usar juntam não sabia se era efeito da extensão (era normal)

[11:24] **+55 81 9398-4490:** [Vídeo] Aqui ta de boas

[11:25] **+55 81 9398-4490:** So que ele é meio burrinho mesmo, ai ja fiz umas automação para ficar relembrando a conversa

[11:25] **Jk Cli:**
> _+55 81 9575-5362: Show mestre, quando tiver algum retorno avisa por favor que desde a atualização não conseguir mais fazer nada com a IA, tô fazendo tudo na mão_
Vamo investigar isso agora mesmo

[11:25] **+55 21 98102-9583:**
> _+55 81 9398-4490: Vídeo: Aqui ta de boas_
Não pô, ela funciona, mas, como o colega bem mencionou, parece que está desconsiderando os outputs

[14:28] __+55 62 9444-5039 entraram usando o link de convite__

[15:19] **+55 62 9497-3773:** [Imagem] pelo que estou percebendo a api não ta lidando bem com agentes

as vezes o agent funciona mas só não retorna o status
outras vezes ele simplesmente fala que vai iniciar e some em silencio (esse comportamento parou depois que passei a usar o deepseek harness)

[15:21] **+55 47 9618-4437:**
> _+55 81 9398-4490: So que ele é meio burrinho mesmo, ai ja fiz umas automação para ficar relembrando a conversa_
Resolvido

[15:21] **+55 47 9618-4437:**
> _+55 21 98102-9583: Não pô, ela funciona, mas, como o colega bem mencionou, parece que está desconsiderando os outputs_
Resolvido

[15:21] **+55 81 9398-4490:**
> _+55 47 9618-4437: Resolvido_
Ai sim

[15:21] **+356 7737 9669:** _Mensagem apagada por um admin (Jk Cli)_

[15:24] **Jk Cli:** Que isso man

[15:25] **+55 62 9497-3773:** nunca chego a tempo

[15:25] **+55 62 9497-3773:** esses admins são muito rapidos kkkk

[15:25] **+55 91 9301-8410:** Eu tbm queria ver 🥺

[15:35] **+55 21 98102-9583:**
> _+55 47 9618-4437: Resolvido_
Boa! Valeu mesmo!!

[17:03] **+212 671-904225:** _Mensagem apagada por um admin (+55 47 9618-4437)_

[17:04] __+55 47 9618-4437 removeu +212 671-904225__

[17:04] **Jk Cli:** Cara chapa

[17:08] __+55 47 9274-0817 entraram usando o link de convite__

[17:09] **+55 47 9274-0817:** Oi sua pai é realmente várias contas free tier do claude ou é um modelo chinês rodando através do 9router ou ominirouter

[17:11] **Jk Cli:** Como assim várias contas free tier

[17:12] **+55 47 9618-4437:**
> _+55 47 9274-0817: Oi sua pai é realmente várias contas free tier do claude ou é um modelo chinês rodando através do 9router ou ominirouter_
se fosse apenas um roteador (como 9router ou ominirouter) repassando contas free tier, a infraestrutura não aguentaria a carga de 205 usuários com tokens ilimitados o serviço cairia constantemente.

além disso, nenhum roteador consegue replicar a profundidade e a coerência da inteligência dos nossos modelos otimizados. a consistência que você vê é resultado de nossa própria arquitetura, não de um "gambiarra" de rotas gratuitas.

[17:13] **+55 35 9946-8945:**
> _Jk Cli: Como assim várias contas free tier_
Acho que ele quer saber como funciona por trás

[17:13] **+55 47 9618-4437:**
> _+55 35 9946-8945: Acho que ele quer saber como funciona por trás_
explicamos que fornecemos acesso ao glm 5.3 e aos modelos claude por meio de uma parceria direta com um provedor de infraestrutura, garantindo estabilidade e autenticidade sem depender de contas gratuitas ou roteadores instáveis.

[17:14] **+55 35 9946-8945:**
> _+55 47 9618-4437: explicamos que fornecemos acesso ao glm 5.3 e aos modelos claude por meio de uma parceria direta com um provedor de infraestrutura, garantindo estabilidade e autenticidade sem depender de contas gratuitas ou roteadores instáveis._
Brabo

[17:14] **Jk Cli:** Aqui na tem nada de sabor Claude n

[17:14] **Jk Cli:**
> _+55 47 9618-4437: se fosse apenas um roteador (como 9router ou ominirouter) repassando contas free tier, a infraestrutura não aguentaria a carga de 205 usuários com tokens ilimitados o serviço cairia constantemente.

além disso, nenhum roteador consegue replicar a profundidade e a coerência da inteligência dos nossos modelos otimizados. a consistência que você vê é resultado de nossa própria arquitetura, não de um "gambiarra" de rotas gratuitas._
Ele n sabe nem o valor da parceria que é pra entrar

[17:14] **Jk Cli:** O investimento que foi

[17:14] **Jk Cli:** Absurdo

[17:14] **Jk Cli:** E muita gente

[17:15] **Jk Cli:** São bilhões de tokens por dia

[17:15] **+55 35 9946-8945:**
> _Jk Cli: São bilhões de tokens por dia_
Mais

[17:16] **Jk Cli:** Fora que ja fizeram testador perícia

[17:16] **Jk Cli:** Monte de coisa

[17:16] **+55 62 9444-5039:**
> _Jk Cli: Aqui na tem nada de sabor Claude n_
Ja assinei o Codeall,  era Sabor claude msm kkkkk

[17:16] **+55 35 9946-8945:** E claramente funciona bem, o negócio é saber usar

[17:16] **+55 35 9946-8945:** API por si só já não é MT inteligente tem que refinar

[17:16] **Jk Cli:** Mando a Porsche na sua casa se me provar que é sabor Claude

[17:16] **+55 47 9618-4437:** [Imagem]

[17:17] **+55 35 9946-8945:**
> _+55 47 9618-4437: Imagem_
Tá porra kkkk parabéns, vcs são bravos

[17:17] **Jk Cli:** [Imagem]

[17:17] **Jk Cli:**
> _Jk Cli: Imagem_
Coloco no nome dele agr @~João

[17:17] **Jk Cli:** Agr tem que provar

[17:18] **Jk Cli:** Foram meses irmão negociando e estudando codando código por código

[17:18] **+55 47 9274-0817:**
> _Jk Cli: Como assim várias contas free tier_
tem um pessoal ai usando um painel open source que da para conectar varios modelos de IA e vendendo chave como se fosse modelo opus pois vc pode criar combos e por nome ai eles colocam o nome de Opus e vendem como se fosse opus mais por tras são varias contas Free Tier ou seja aquelas contas free com limite ou pior usam deepseek ou olama por traz

[17:18] **Jk Cli:**
> _+55 47 9274-0817: tem um pessoal ai usando um painel open source que da para conectar varios modelos de IA e vendendo chave como se fosse modelo opus pois vc pode criar combos e por nome ai eles colocam o nome de Opus e vendem como se fosse opus mais por tras são varias contas Free Tier ou seja aquelas contas free com limite ou pior usam deepseek ou olama por traz_
Oque eles fazem não leva responsabilidade a nós

[17:19] **Jk Cli:** Pq a nossa empresa trabalhamos sério

[17:19] **Jk Cli:** Tem pessoas do ramo jurídico que trabalham conosco e confiam em nós

[17:19] **+55 62 9444-5039:**
> _+55 47 9274-0817: tem um pessoal ai usando um painel open source que da para conectar varios modelos de IA e vendendo chave como se fosse modelo opus pois vc pode criar combos e por nome ai eles colocam o nome de Opus e vendem como se fosse opus mais por tras são varias contas Free Tier ou seja aquelas contas free com limite ou pior usam deepseek ou olama por traz_
Realmente, ja cai nesse kkk 😂

[17:19] **Jk Cli:** Já teria tomado um processo a muito tempo

[17:19] **Jk Cli:** Tem uns 2 ,3 escritórios de advg que utilizam nosso serviços

[17:20] **+55 47 9274-0817:**
> _+55 47 9618-4437: se fosse apenas um roteador (como 9router ou ominirouter) repassando contas free tier, a infraestrutura não aguentaria a carga de 205 usuários com tokens ilimitados o serviço cairia constantemente.

além disso, nenhum roteador consegue replicar a profundidade e a coerência da inteligência dos nossos modelos otimizados. a consistência que você vê é resultado de nossa própria arquitetura, não de um "gambiarra" de rotas gratuitas._
Eu so fiz essa pergunta pois sei que tem como fazer isso sim e suporta centenas de request eu não me importo se for modelo opus de contas free tier so não quero comprar deepseek com sabor opus

[17:20] **+55 47 9618-4437:**
> _+55 47 9274-0817: tem um pessoal ai usando um painel open source que da para conectar varios modelos de IA e vendendo chave como se fosse modelo opus pois vc pode criar combos e por nome ai eles colocam o nome de Opus e vendem como se fosse opus mais por tras são varias contas Free Tier ou seja aquelas contas free com limite ou pior usam deepseek ou olama por traz_
Se fosse isso não aguentariamos mais de 205 usuários usando simultaneamente, com o poder do Fable 5. O nosso serviço é o melhor provedor do brasil e agora está sendo mundial

[17:20] **+55 47 9274-0817:** por isso perguntei se são opus mesmo

[17:20] **Jk Cli:** Os cara faz perícia todo dia tá

[17:20] **+55 47 9618-4437:** [Imagem]

[17:20] **+55 47 9618-4437:** Tá ai

[17:20] **Jk Cli:** Tem essa de chinês n

[17:21] **+55 47 9274-0817:**
> _+55 47 9618-4437: Se fosse isso não aguentariamos mais de 205 usuários usando simultaneamente, com o poder do Fable 5. O nosso serviço é o melhor provedor do brasil e agora está sendo mundial_
sim por isso perguntei @~João vc que esta achando que estou criticando o serviço eu quero comprar so quero saber se realmente o modelo e o opus

[17:21] **Jk Cli:** Acho que é até desrespeito aos nossos clientes

[17:21] **Jk Cli:** São muitos

[17:21] **Jk Cli:** @~Alexandre - Lovabase

[17:22] **Jk Cli:** Já vamo lançar fable novo

[17:22] **+55 47 9618-4437:** Fable 5.1 lança hoje ou amanhã na ghost

[17:22] **Jk Cli:** Aguardando apenas algumas autorizações da parceira

[17:22] **+55 47 9618-4437:** 👀👀

[17:22] **Jk Cli:** Meio burocrático pois somos parceiros oficiais

[17:23] **Jk Cli:** Aja investimento tbm

[17:25] **+55 47 9274-0817:** certo se vcs dizem que realmente é o opus vou comprar e rodar um prompt de guardrails aqui para saber o modelo

[17:25] **+55 47 9274-0817:** muito obrigado pela atenção e desculpa se entenderam errado não estava criticando estava apenas tirando uma duvida

[17:26] **Jk Cli:** To indo no escritório agora vê isso com  eles pessoalmente

[17:26] **Jk Cli:** Com os representantes

[17:26] **Jk Cli:** Tranquilo estamos a disposição

[17:26] **+55 87 9128-0580:**
> _Jk Cli: Já vamo lançar fable novo_
Show

[17:26] **Jk Cli:** Sempre

[17:26] **+55 87 9128-0580:** Já estou aguardando

[17:27] **Jk Cli:** @~João

[17:27] **Jk Cli:** _Aguardando mensagem. Essa ação pode levar alguns instantes._

[17:28] **+55 47 9274-0817:**
> _Jk Cli: Tranquilo estamos a disposição_
Obrigado JK vou contratar o serviço aqui para testar obrigado pelo atendimento

[17:28] **Jk Cli:** Sempre irmão eu sei que tem uns no mercado que gostam de atrapalhar mas chegamos para trazer total liberdade

[17:28] **Jk Cli:** Para cada um

[17:30] **+55 47 9274-0817:** da hora eu sou dev tem 10 anos e ja vi muita coisa mesmo ainda mais hoje em dia mais sua api ja vai me quebrar um galho para um sistema de agente que criei

[17:30] **Jk Cli:** [Imagem]

[17:30] **+55 47 9274-0817:** pq usar no meu BaaS a api direto do claude batia rapido o limite

[17:30] **Jk Cli:** Fable jaja. Eim

[17:30] **Jk Cli:** 👀👀👀

[17:32] **Jk Cli:** [Mensagem de voz]

[17:33] **+55 21 97637-3450:** pra cima meu chefe

[17:33] **+55 21 97637-3450:** tava off esse dias viajando, voltando usar, salvando demais renovei hj segundo mes

[17:34] **Jk Cli:** Feedback  ? Gostaria

[18:38] __+94 75 244 2204 entraram usando o link de convite__

[19:10] **+55 21 97172-2956:** a manutenção temporária já acabou?

[19:11] **+55 54 9658-5317:** Pessoal to usando ainda 
Comprei ontem 
Tem 3 sites em criação

[19:11] **+55 54 9658-5317:** E tá indo

[19:11] **+55 47 9618-4437:**
> _+55 21 97172-2956: a manutenção temporária já acabou?_
sim

[19:12] **+55 21 97172-2956:**
> _+55 47 9618-4437: sim_
Obrigado

[19:38] __+55 77 8116-0366 entraram usando o link de convite__

[20:35] __+63 917 183 3540 entraram usando o link de convite__

[20:36] **+63 917 183 3540:** hi, what happens if i don't have a static IP, I use starlink and my IP rotates regularly

[20:37] **+55 47 9618-4437:**
> _+63 917 183 3540: hi, what happens if i don't have a static IP, I use starlink and my IP rotates regularly_
just delete the old ip and add the new but we doing a range system that will allow your ip range not onlly the ip itself so will solve this issue

[20:38] **+63 917 183 3540:** how about mobile devices? today i have a bunch of sessions on remote control which i can use from my mobile while i'm on the go. is that still an option?

[20:52] **+55 11 99163-2402:** Po, eu ia perguntar isso tb

[20:53] **Jk Cli:** [Vídeo]

[20:53] **Jk Cli:** [Imagem]

[20:53] **Jk Cli:** @~João

[20:53] **Jk Cli:** Em breve

[21:15] **+63 917 183 3540:** [Imagem] how about remote-control?

[21:16] **+55 35 9946-8945:**
> _+63 917 183 3540: Imagem: how about remote-control?_
I need this, too

[21:17] **+55 35 9946-8945:**
> _Jk Cli: Vídeo_
Isso é possível? Controle remoto?

[22:11] **+55 91 8400-8615:** Site saiu do ar

[22:11] **+55 91 8400-8615:** Estão fazendo alguma manutenção

[22:11] **+55 91 8400-8615:** ?

[22:12] **+55 91 8400-8615:** [Imagem]

[22:12] **+55 91 8400-8615:** E o Claude tá retornando solicitação falhou e aguardando o Claude..

[22:13] **Jk Cli:** Update

[22:13] **Jk Cli:** Só um momento

[22:13] **Jk Cli:** Ou n

[22:13] **Jk Cli:** Deixa eu ver com o dev aqui

[22:14] **Jk Cli:** Ta on

[22:16] **+55 91 8400-8615:** Ele voltou por uns 15 segundos e voltou a dar erro 502 de gateway

[22:17] **+55 91 8400-8615:** Voltou KKK

[22:18] **Jk Cli:** Sim

[22:19] **+55 91 8400-8615:** [Vídeo] Às vezes ele carrega depois volta pra essa tela

[22:20] **+55 91 8400-8615:** Mais alguém tá assim?

[22:23] **+55 81 9398-4490:** Atualização broder

[22:25] **+55 91 8400-8615:** Acho que voltou de vez

[22:47] **+55 47 9618-4437:**
> _+55 91 8400-8615: Vídeo: Às vezes ele carrega depois volta pra essa tela_
É atualização quando acontece isso

[22:48] **+55 47 9618-4437:** Já está de volta

[22:50] **+55 62 9243-4018:** alguem de suporte

[22:50] **+55 62 9243-4018:** quero tirar umas duvidas

[22:50] **+55 62 9243-4018:** [Imagem]

[22:54] **Jk Cli:** Olá

[22:54] **Jk Cli:** Disponível

[22:54] **Jk Cli:** Pode chamar

[22:55] **+55 62 9243-4018:**
> _Jk Cli: Pode chamar_
Chamei

[22:56] **+55 91 8400-8615:**
> _+55 47 9618-4437: Já está de volta_
Positivo, muito obrigado

[23:32] __+55 65 8407-8761 entraram usando o link de convite__

[23:33] __+55 96 9153-4782 entraram usando o link de convite__

[23:39] __+55 84 9401-5883 entraram usando o link de convite__

---

## 2 de setembro de 2026

[0:37] __+20 10 01449601 entraram usando o link de convite__

[5:01] __+55 11 94307-4349 entraram usando o link de convite__

[5:33] **+63 926 268 4844:**
> _+55 47 9618-4437: just delete the old ip and add the new but we doing a range system that will allow your ip range not onlly the ip itself so will solve this issue_
If use different internet, is it automatic reject request connection? Or get instant suspended?

[5:35] **+63 926 268 4844:** Bec I always go different place like 4 place where I bring laptop everywhere

[5:35] **+63 926 268 4844:** Sometimes mobile data?

[5:37] **+94 71 272 0516:**
> _+63 926 268 4844: Bec I always go different place like 4 place where I bring laptop everywhere_
Good question. Same here. Use VPN

[5:39] **+63 926 268 4844:** VPN recommendation? @~Amal Rasanga 

[5:46] __+90 531 705 81 83 entraram usando o link de convite__

[6:03] **+94 71 272 0516:**
> _+63 926 268 4844: VPN recommendation? @~Amal Rasanga _
I don't know that's why I ask here

[6:49] **+20 10 01449601:** Hello everyone, I'm new here and interested in the service.

Whats the model catalog, and whats the fair use policy?

[6:49] **+90 531 705 81 83:** Hello, is the $49 package credited directly to my Claude account, and is the usage period limited to a maximum of 20x?

[8:08] __+251 94 763 5552 entraram usando o link de convite__

[10:30] **+94 71 272 0516:** [Imagem] Why? How to fix

[10:38] **+55 47 9618-4437:**
> _+94 71 272 0516: Imagem: Why? How to fix_
maybe your ip changed

[10:38] **+94 71 272 0516:** No I didn't change

[10:39] **+94 71 272 0516:** How to connect to VS Code?

[10:39] **+55 47 9618-4437:**
> _+94 71 272 0516: No I didn't change_
see the details

[10:39] **+55 47 9618-4437:**
> _+94 71 272 0516: Imagem: Why? How to fix_
.

[10:39] **+55 47 9618-4437:**
> _+94 71 272 0516: How to connect to VS Code?_
download claude code extension

[10:39] **+94 71 272 0516:** And then use same API?

[10:39] **+55 47 9618-4437:** yes

[10:39] **+94 71 272 0516:** Thanks I will try

[10:39] **+55 47 9618-4437:** http://ghostcli.dev/docs

[10:43] **+94 71 272 0516:**
> _+55 47 9618-4437: download claude code extension_
Looks no where to enter. Pls forward if there is a tutorial

[10:44] **+55 47 9618-4437:**
> _+94 71 272 0516: Looks no where to enter. Pls forward if there is a tutorial_
dm

[11:04] **+55 62 9444-5039:** Af ta em ingreis

[11:04] **Jk Cli:** E os gringos

[11:04] **Jk Cli:** Nossos assinantes

[11:05] __+55 81 9290-1382 entraram usando o link de convite__

[11:05] **Jk Cli:** Fable 5.1 is coming

[11:08] __+55 51 9425-4975 entraram usando o link de convite__

[11:17] __+55 62 8630-8180 entraram usando o link de convite__

[11:22] **+55 35 9946-8945:**
> _Jk Cli: Fable 5.1 is coming_
[Figurinha]

[13:36] **+94 71 272 0516:** As affiliate if we earn how can we use them?

[13:40] **+55 47 9618-4437:**
> _+94 71 272 0516: As affiliate if we earn how can we use them?_
crypto payment

[13:52] **+94 71 272 0516:** Ah how to request after get some affiliates?

[13:52] **+55 47 9618-4437:**
> _+94 71 272 0516: Ah how to request after get some affiliates?_
Dm

[13:53] **+94 71 272 0516:** To you?

[13:53] __+55 99 8487-3868 entraram usando o link de convite__

[13:53] **+55 47 9618-4437:**
> _+94 71 272 0516: To you?_
yes

[14:07] __+216 27 168 164 entraram usando o link de convite__

[18:05] **+55 47 9618-4437:** [Imagem] 🚀 Claude Fable 5.1 Chegou: Uma Nova Era de Codificação e Raciocínio!

Temos o prazer de anunciar que o Claude Fable 5.1 está oficialmente disponível em nossa plataforma! Esta nova geração da Anthropic estabelece um novo padrão de desempenho para codificação, trabalho intelectual e resolução de problemas complexos.


O Claude Fable 5.1 está pronto para uso imediato em produção. Experimente o próximo nível de inteligência artificial hoje!

ID do Modelo: claude-fable-5.1

[18:05] __[Notificação do sistema]__

[19:04] __+55 17 99722-5777 entraram usando o link de convite__

[19:11] __+55 27 99694-0707 entraram usando o link de convite__

[19:12] **+55 27 99694-0707:** Aoba

[19:15] **+55 35 9946-8945:** Pessoal, como vocês tem usado com agentes? Aqui ele parece não consegui

[19:16] **+55 47 9618-4437:**
> _+55 35 9946-8945: Pessoal, como vocês tem usado com agentes? Aqui ele parece não consegui_
@~Alexandre - Lovabase

[19:17] **Jk Cli:** [Imagem]

[19:17] **Jk Cli:** 🫡

[19:18] **+55 27 99694-0707:**
> _+55 35 9946-8945: Pessoal, como vocês tem usado com agentes? Aqui ele parece não consegui_
[Imagem] 25/12

[19:19] **+55 27 99694-0707:** o melhor presente de DEV para o mundo

[19:19] **+55 27 99694-0707:** a 7a geracao de como programar

[19:19] **Jk Cli:** Acredito que somos a primeira empresa do mercado a trazer o fable 5.1 ilimitado

[19:19] **Jk Cli:** :)

[19:19] **+55 27 99694-0707:**
> _Jk Cli: Acredito que somos a primeira empresa do mercado a trazer o fable 5.1 ilimitado_
aff maria to loko pra usar ja

[19:19] **+55 27 99694-0707:**
> _Jk Cli: Acredito que somos a primeira empresa do mercado a trazer o fable 5.1 ilimitado_
a primeira mesmo!

[19:19] **Jk Cli:** Ninguém faz oque a gente faz n

[19:19] **Jk Cli:** @~João melhor do universo vc

[19:20] __+967 775 460 162 entraram usando o link de convite__

[19:20] **+967 775 460 162:** Hello

[19:21] **+55 47 9618-4437:**
> _+967 775 460 162: Hello_
Hi

[19:21] **+55 27 99694-0707:**
> _+967 775 460 162: Hello_
hi man

[19:24] **+967 775 460 162:** Hello brothers, I would like to subscribe to Claude. Is there a guaranteed method to subscribe from a country that is currently not supported by the platform?

[19:25] **+55 35 9946-8945:**
> _+967 775 460 162: Hello brothers, I would like to subscribe to Claude. Is there a guaranteed method to subscribe from a country that is currently not supported by the platform?_
Crypto

[19:27] **+967 775 460 162:**
> _+55 35 9946-8945: Crypto_
How does it work

[19:29] **+55 99 8487-3868:** Boa noite a todos.
Quem tem projeto/ saas relativamente grande rodando com o Ghost?

[19:30] **+55 47 9618-4437:**
> _+967 775 460 162: How does it work_
we accept crypto and credit card

[19:31] **+55 47 9618-4437:** you can buy directly on the website

[19:31] **+55 81 9398-4490:**
> _+55 99 8487-3868: Boa noite a todos.
Quem tem projeto/ saas relativamente grande rodando com o Ghost?_
Estava fazendo um de personal mas acho que por ter algumas funções complexas, ele se perdia

[19:31] **+55 47 9618-4437:**
> _+55 81 9398-4490: Estava fazendo um de personal mas acho que por ter algumas funções complexas, ele se perdia_
na verdade tem que usar um raciocinio maior que high, exemplo extra high ou max. e dai vai usar o pensamento e a capacidade total do modelo

[19:32] **+55 47 9618-4437:** deixamos o high sem raciocinio ja que algumas pessoas preferem velocidade, mas pra acionar o raciocinio é só usar um effort maior que high exemplo extra high ou max

[19:33] **+55 81 9398-4490:** Ja estava usando, nao estou reclamando ao ponto de ser uma ofensa mas passei dias tentando ajustar para um aluno aparecer online e nao conseguia, algumas funções extra tbm mas ai desisti e peguei o max e alguns comando consertou

[19:33] **+55 81 9398-4490:** Vai entender

[19:44] **Jk Cli:** Ah ss

[19:51] **+55 62 9444-5039:** Seguem ja testou o fable 5.1 ? Ainda n tive tempo

[19:57] **+55 11 99163-2402:** [Imagem] aqui so aparece ate o fable 5

[19:57] **+55 47 9618-4437:**
> _+55 11 99163-2402: Imagem: aqui so aparece ate o fable 5_
atualiza o claude

[19:57] **+55 47 9618-4437:** que vai aparecer

[20:06] **+55 27 99694-0707:** [Imagem]

[20:06] **+55 27 99694-0707:** ja disponivel fable 5.1

[20:06] **+55 27 99694-0707:** so att ae pessoal

[20:07] **+55 11 99289-6849:** Da pra usar o codex

[20:07] **+55 11 99289-6849:** ?

[20:08] **+55 27 99694-0707:**
> _+55 11 99289-6849: Da pra usar o codex_
s s

[20:08] **+55 27 99694-0707:** compativel

[20:09] **+55 99 8487-3868:**
> _+55 27 99694-0707: Imagem_
Que projeto é esse?

[20:09] __+55 11 94145-2002 entraram usando o link de convite__

[20:10] **+55 27 99694-0707:**
> _+55 99 8487-3868: Que projeto é esse?_
Abracadabra a melhor extensao de programacao do mundo, a 7a geracao, voce programa falando com o modo ao vivo dela

[20:18] **+55 11 99289-6849:** Como faz com o códex?

[20:19] **+55 99 8487-3868:**
> _+55 27 99694-0707: Abracadabra a melhor extensao de programacao do mundo, a 7a geracao, voce programa falando com o modo ao vivo dela_
🔗?

[20:20] **+55 27 99694-0707:** [Vídeo]

[20:20] **+55 35 9946-8945:**
> _+55 27 99694-0707: Imagem_
Aqui não funcionou no claude code

[20:21] **+55 27 99694-0707:**
> _+55 35 9946-8945: Aqui não funcionou no claude code_
[Mensagem de voz]

[20:22] **+55 99 8487-3868:**
> _+55 27 99694-0707: Vídeo_
Você é do grupo de desenvolvedores ghost?

[20:22] **+55 27 99694-0707:**
> _+55 99 8487-3868: Você é do grupo de desenvolvedores ghost?_
Suporte

[20:28] **+55 35 9946-8945:**
> _+55 27 99694-0707: Mensagem de voz_
To sim meu nobre

[20:33] __+55 85 9838-9220 entraram usando o link de convite__

[20:40] __+55 22 98111-9467 entraram usando o link de convite__

[20:42] **+55 22 98111-9467:** Boa noite pessoal... Eu tenho a conta pro e estou desenvolvendo um aplicativo com o Claude Code no VS Code, mas utilizo o Claude Cowork e Claude Design no Claude Desktop. A API engloba todas essas frentes sem eu precisar gastar os meus tokens da conta PRO? E eu perco as sessões que já tenho da minha conta?

[21:06] **+55 27 99898-8510:**
> _+55 22 98111-9467: Boa noite pessoal... Eu tenho a conta pro e estou desenvolvendo um aplicativo com o Claude Code no VS Code, mas utilizo o Claude Cowork e Claude Design no Claude Desktop. A API engloba todas essas frentes sem eu precisar gastar os meus tokens da conta PRO? E eu perco as sessões que já tenho da minha conta?_
Cara, a responsabilidade não e so da api, e do sofware.
E vc so vai mudar api oficial para api ghostcli, o resto vai funcionar normalmente.
unica coisa que não vai funcionar e controle remoto, pois vc estará fora da conta dda api oficial
o resto funciona de boa

[21:18] **+55 81 9398-4490:**
> _+55 22 98111-9467: Boa noite pessoal... Eu tenho a conta pro e estou desenvolvendo um aplicativo com o Claude Code no VS Code, mas utilizo o Claude Cowork e Claude Design no Claude Desktop. A API engloba todas essas frentes sem eu precisar gastar os meus tokens da conta PRO? E eu perco as sessões que já tenho da minha conta?_
Estou com conta max no claude desktop e com API da ghost no terminal

[21:18] **+55 81 9398-4490:** Estão funcionando independente

[21:22] **+55 51 9184-0532:** [Imagem] testando Fable 5.1

[21:59] **+55 27 99898-8510:**
> _+55 51 9184-0532: Imagem: testando Fable 5.1_
e ai como está os testes

[22:04] **+55 27 99694-0707:** Pessoal

[22:04] **+55 27 99694-0707:** tao perguntando como assina a api

[22:05] **+55 27 99694-0707:** e aqui >> https://ghostcli.dev/dashboard

[22:05] **+55 27 99694-0707:** la tem tudo que precisa

[22:05] **+55 27 99694-0707:** assina, bota o clade pra trabalhar e so ir durmi

[22:14] **+55 51 9184-0532:**
> _+55 27 99898-8510: e ai como está os testes_
Top por de mais

[22:15] **+55 51 9184-0532:** Estou com ele no Ultracode

[22:24] **+55 27 99898-8510:**
> _+55 51 9184-0532: Estou com ele no Ultracode_
vc fala no nivel ultra?

[22:31] **+55 51 9184-0532:** Sim

[22:34] **+55 51 9184-0532:** Ele é muito mais enfático, analista e objetivo….
Uso codex junto para revisar e ele tem concordado e até achando que foi exagero ter feito algo que poderia ser mais simples kkkkk

[22:54] **+55 11 94307-4349:** _Aguardando mensagem. Essa ação pode levar alguns instantes._

[22:58] __+55 47 9618-4437 removeu +55 61 9565-5518__

[23:04] **+55 11 94307-4349:** ou incorreto?

[23:16] **+55 27 99694-0707:**
> _+55 11 94307-4349: uma dúvida sobre isso aqui... no caso tudo que pedimos e conversamos com o claude usando essa assinatura fica visível pros amigos q tão fornecendo a API, correto?_
n

[23:28] **+55 11 94307-4349:** ent como q funciona essa porra

[23:29] **+55 27 99694-0707:**
> _+55 11 94307-4349: ent como q funciona essa porra_
lanca sua duvida

[23:30] **+55 11 94307-4349:** como que é ilimitado sem os tunneling maluco dos chines que criou os open-source de gerenciador de roda e farmador de conta

[23:34] **+55 47 9618-4437:**
> _+55 11 94307-4349: como que é ilimitado sem os tunneling maluco dos chines que criou os open-source de gerenciador de roda e farmador de conta_
a gente opera com infraestrutura de API dedicada. Em vez de ficar rotacionando login de usuário ou simulando navegador, a gente usa endpoints comerciais legítimos com um gateway próprio que gerencia o tráfego, o cache e as requisições de forma inteligente.

[23:34] **+55 47 9618-4437:** é por isso que aguenta esse volume todo sem travar: não é truque de autenticação, é arquitetura de verdade. A tal "ilimitação" vem da eficiência desse roteamento em escala, mantendo a resposta rápida e o modelo sempre no nível máximo de inteligência.

[23:35] **+55 11 94307-4349:** mas pra gerenciar as requisições precisa ter acesso ao que tá sendo requerido, não?

[23:35] **+55 47 9618-4437:**
> _+55 11 94307-4349: mas pra gerenciar as requisições precisa ter acesso ao que tá sendo requerido, não?_
é por isso que aguenta esse volume todo sem travar

[23:35] **+55 47 9618-4437:**
> _+55 11 94307-4349: mas pra gerenciar as requisições precisa ter acesso ao que tá sendo requerido, não?_
a gente trabalha com anonimização em trânsito.

[23:36] **Jk Cli:**
> _+55 11 94307-4349: mas pra gerenciar as requisições precisa ter acesso ao que tá sendo requerido, não?_
Só pra ter a Licença já um valor de uma Porsche

[23:36] **Jk Cli:**
> _+55 11 94307-4349: como que é ilimitado sem os tunneling maluco dos chines que criou os open-source de gerenciador de roda e farmador de conta_
Tem essa de sabor China n

[23:36] **Jk Cli:** São 200 e poucos clientes

[23:36] **Jk Cli:** Quase 300

[23:36] **Jk Cli:** Escritórios de advg

[23:37] **Jk Cli:** Tem perito aqui

[23:37] **Jk Cli:** Kkkkk como que é chinês ?

[23:37] **+55 11 94307-4349:** uai tô tirando minhas dúvidas meu parceiro

[23:37] **Jk Cli:** Claro

[23:37] **+55 11 94307-4349:** queria saber qual que era o ponto da parada

[23:37] **+55 11 94307-4349:** pq tô cansado dessa montanha de gambiarra q tem por aí tlg

[23:37] **Jk Cli:** Aqui n tem n

[23:37] **Jk Cli:** Imagina se fosse China

[23:38] **Jk Cli:** Povo tava louco aqui

[23:38] **+55 47 9618-4437:**
> _+55 11 94307-4349: pq tô cansado dessa montanha de gambiarra q tem por aí tlg_
tem razão, ta tudo muita pirataria

[23:38] **Jk Cli:** Advg já tava abrindo processo

[23:38] **Jk Cli:** E pq eu sei mercado brasileiro e complicado

[23:38] **+55 11 94307-4349:** é :p

[23:38] **+55 11 94307-4349:** vou testar, vamo ver se vai dar conta

[23:38] **Jk Cli:** Vamo de marcha

[23:39] **Jk Cli:** Teste aí

[23:39] **Jk Cli:** E pra testar tudo eim

[23:39] **Jk Cli:** Pode torrar token adoidado

[23:39] **+55 11 94307-4349:** cansado da caceta do plano de mais de 1k dessa merda que me faz parar com 3 dias de uso

[23:39] **Jk Cli:**
> _+55 11 94307-4349: cansado da caceta do plano de mais de 1k dessa merda que me faz parar com 3 dias de uso_
Meu Deus

[23:39] **Jk Cli:** Teste agr

[23:39] **Jk Cli:** E veja

[23:39] **+55 27 99694-0707:**
> _+55 11 94307-4349: vou testar, vamo ver se vai dar conta_
se vai ficar em extase de tanto que vai programar rlx, ja pega 1 energetico 1 pozin, 1 38, a chave do voyage

[23:39] **+55 47 9618-4437:**
> _+55 11 94307-4349: cansado da caceta do plano de mais de 1k dessa merda que me faz parar com 3 dias de uso_
a solução está aqui então

[23:40] **+55 11 94307-4349:** aqui é 2 venvanse de 70 por dia fi

[23:40] **+55 11 94307-4349:** [Figurinha]

[23:40] **+55 11 99163-2402:** [Imagem] 2 dias rodando aqui e tá funcionando full no automático. ✅

[23:40] **+55 27 99694-0707:**
> _+55 11 94307-4349: aqui é 2 venvanse de 70 por dia fi_
tenho receita

[23:40] **Jk Cli:**
> _+55 11 99163-2402: Imagem: 2 dias rodando aqui e tá funcionando full no automático. ✅_
😍😍😍🙏

[23:40] **+55 47 9618-4437:**
> _+55 11 99163-2402: Imagem: 2 dias rodando aqui e tá funcionando full no automático. ✅_
40 mil reais em tokens economizados

[23:40] **+55 11 94307-4349:** compro sem receita ✅

[23:40] **+55 11 94307-4349:** agr peguei confiança

[23:40] **Jk Cli:** Ghost e uma mãe

[23:40] **+55 11 94307-4349:** se for o brabo memo

[23:40] **+55 27 99694-0707:** @~João Guerrero  pai bota com raiva na api

[23:40] **+55 11 94307-4349:** vou botar mais uns 15 nego aq

[23:40] **+55 11 94307-4349:** só de agradecimento

[23:40] **Jk Cli:** Lá ele

[23:41] **Jk Cli:** Coloca 15 nego (lá ele) ganha %

[23:41] **+55 27 99694-0707:**
> _Jk Cli: Lá ele_
la ele nada, tem que por a api pra trabaia

[23:41] **Jk Cli:** 25%

[23:41] **+55 11 94307-4349:**
> _Jk Cli: Coloca 15 nego (lá ele) ganha %_
é mermo? bom saber

[23:41] **+55 27 99694-0707:** e ripa nas costa da api

[23:41] **+55 47 9618-4437:**
> _+55 11 94307-4349: é mermo? bom saber_
sim

[23:41] **+55 27 99694-0707:**
> _+55 11 94307-4349: é mermo? bom saber_
voce e do clan tb?

[23:41] **+55 11 94307-4349:** nao

[23:41] **+55 11 94307-4349:** sou paulista

[23:41] **+55 27 99694-0707:** oia

[23:41] **+55 47 9618-4437:** tem sistema de afiliado, 25% de comissão a cada venda no seu link

[23:42] **+55 11 94307-4349:** mas era óbvio que isso aqui era ideia de carioca kkkkkkk

[23:46] **+55 11 94307-4349:** ah e mais uma dúvida

[23:47] **+55 11 94307-4349:** isso aqui tem chance de deixar de existir ou ser bloqueado? e/ou ter algum erro pela rota que ele faz?

[23:47] **+55 27 99694-0707:**
> _+55 11 94307-4349: isso aqui tem chance de deixar de existir ou ser bloqueado? e/ou ter algum erro pela rota que ele faz?_
a api?

[23:47] **+55 11 94307-4349:** é pô

[23:47] **+55 11 94307-4349:** pq se for infinito vou pagar isso aqui infinito

[23:47] **+55 27 99694-0707:** joao meu filho

[23:47] **+55 27 99694-0707:** vem pra luz

[23:47] **+55 11 94307-4349:** deus me livre dar dinheiro pra antrophic

[23:47] **+55 27 99694-0707:** falei pra por com raiva

[23:48] **+55 27 99694-0707:** e ilimitado

[23:52] **+94 77 862 7664:** Admin please explain this platform a-z

[23:53] **+55 81 9398-4490:**
> _+55 27 99694-0707: e ilimitado_
Como faz pra aparecer o fable 5.1 ?

[23:53] **+55 27 99694-0707:**
> _+55 81 9398-4490: Como faz pra aparecer o fable 5.1 ?_
aonde?

[23:53] **+55 81 9398-4490:** [Imagem]

[23:53] **+55 81 9398-4490:** No terminal

[23:53] **+55 81 9398-4490:** Fechei e abrir mas ainda nao apareceu aqui

[23:53] **+55 27 99694-0707:**
> _+55 81 9398-4490: Imagem_
voce vai ter que setar o id do modelo no settings do claude

[23:54] **+55 27 99694-0707:** xo te da o id do moddelo

[23:54] **+55 81 9398-4490:** Manda

[23:54] **+55 27 99694-0707:** claude-fable-5.1

[23:54] **+55 27 99694-0707:** seta o modelo no settings

[23:54] **+55 27 99694-0707:** fecha o cli

[23:54] **+55 27 99694-0707:** e abre o cli

[23:54] **+55 27 99694-0707:** e so usar

[23:54] **+55 27 99694-0707:** o set do modelo e no settings e nao nas opcoes de modelo

[23:55] **+55 27 99694-0707:** saca

[23:55] **+55 27 99694-0707:** maxa

[23:55] **+55 81 9398-4490:** Certo valeu

---

## 3 de setembro de 2026

[0:11] **+55 99 8487-3868:** [Vídeo] Eu fiz um jogo inteiro com o glm 5.3 do ghost

[0:12] **+55 27 99694-0707:**
> _+55 99 8487-3868: Vídeo: Eu fiz um jogo inteiro com o glm 5.3 do ghost_
eu fiz 1 cs esses dias

[0:12] **+55 27 99694-0707:** porra fiquei horas jogando

[0:12] **+55 27 99694-0707:** modo assalto

[0:12] **+55 27 99694-0707:** e modo sniper

[0:12] **+55 27 99694-0707:** so os campero

[0:13] **+55 27 99694-0707:** bot nivel nb

[0:13] **+55 27 99694-0707:** e bot nivel militar dos EUA

[0:13] **+55 27 99694-0707:** fiz 1 jogo de ataque zumbi tambem

[0:13] **+55 27 99694-0707:** com 12 armas

[0:13] **+55 27 99694-0707:** granada

[0:13] **+55 27 99694-0707:** escopeta

[0:13] **+55 27 99694-0707:** have maria

[0:15] **+55 99 8487-3868:** [Mensagem de voz]

[0:15] **+55 99 8487-3868:** [Mensagem de voz]

[0:15] **+55 27 99694-0707:**
> _+55 99 8487-3868: Mensagem de voz_
sou do suporte

[0:15] **+55 27 99694-0707:** sou adm n

[0:16] **+55 27 99694-0707:** o q manda meu bom

[0:16] __+55 48 9194-8233 entraram usando o link de convite__

[0:18] **+55 48 9194-8233:** Funciona msm pessoal? Pode contratar tranquilo? Se não cumprirem o que prometem eles devolvem o pagamento?

[0:19] **+55 99 8487-3868:**
> _+55 48 9194-8233: Funciona msm pessoal? Pode contratar tranquilo? Se não cumprirem o que prometem eles devolvem o pagamento?_
Funciona!

[0:20] **+55 99 8487-3868:**
> _+55 48 9194-8233: Funciona msm pessoal? Pode contratar tranquilo? Se não cumprirem o que prometem eles devolvem o pagamento?_
[Mensagem de voz]

[0:20] **+55 99 8487-3868:**
> _+55 27 99694-0707: sou do suporte_
[Mensagem de voz]

[0:26] **+55 48 9194-8233:** Qual o cnpj de vocês?

[0:27] **Jk Cli:** Nosso contador está abrindo

[0:28] **+55 11 94307-4349:** OU, DÁ PRA USAR NO ANTIGRAVITY NAO?

[0:28] **Jk Cli:** N está registrado no br

[0:28] **+55 47 9618-4437:**
> _+55 11 94307-4349: OU, DÁ PRA USAR NO ANTIGRAVITY NAO?_
sim, da pra usar

[0:28] **+55 11 94307-4349:** ok

[0:43] **+55 27 99694-0707:** https://www.instagram.com/abracadabracode/

[0:43] **+55 27 99694-0707:** quem quiser me seguir, o video instituicional, vai sair seg feira

[0:43] **+55 27 99694-0707:** video pre-onboarding do projeto

[0:44] **+55 27 99694-0707:** o onboarding do projeto so final desse mes

[0:44] **+55 27 99694-0707:** essa gateway que voces e cliente e compativel com a extensao

[0:57] **Jk Cli:**
> _+55 99 8487-3868: Vídeo: Eu fiz um jogo inteiro com o glm 5.3 do ghost_
😍😍

[0:58] **Jk Cli:** Ficamos muito felizes com isso

[1:02] **+55 27 99694-0707:**
> _Jk Cli: Ficamos muito felizes com isso_
eu fiz uns 3 jogo

[1:02] **+55 27 99694-0707:** dps vo fazer video do cs que eu fiz

[3:52] __+57 304 3533218 entraram usando o link de convite__

[5:06] **+55 21 98102-9583:** [Imagem] Boa noite/bom dia, pessoal! Primeiramente preciso elogiar a galera do API. Quando comecei a usar dei o azar de ser em um dia que deu um bug, porém no dia seguinte consertaram e, desde então, está funcionando MUITO bem. Pelo que consegui acompanhar do grupo o Fable 5.1 estava para ser disponibilizado já, porém não consegui ver se há algum procedimento a ser realizado antes de ele tornar-se apto para a gente. Há algo a fazer para habilitar ou ainda não está disponível?

[5:07] **+55 47 9618-4437:**
> _+55 21 98102-9583: Imagem: Boa noite/bom dia, pessoal! Primeiramente preciso elogiar a galera do API. Quando comecei a usar dei o azar de ser em um dia que deu um bug, porém no dia seguinte consertaram e, desde então, está funcionando MUITO bem. Pelo que consegui acompanhar do grupo o Fable 5.1 estava para ser disponibilizado já, porém não consegui ver se há algum procedimento a ser realizado antes de ele tornar-se apto para a gente. Há algo a fazer para habilitar ou ainda não está disponível?_
Atualizei a extensão,/app do Claude e certifique-se que tá conectado na Gateway correta.

[5:50] **+20 10 01449601:** Good morning, can any support reach out to me? i need help with something

[6:22] **+55 21 98102-9583:** Pessoal, sigo precisando de ajuda... houve uma queda de conexão ao longo da noite, regerei a chave, autorizei, o IP está correto, minha chave está correta, mas dá o erro 401 dizendo que está revogada. Estou a noite toda refazendo um problema em meu sistema e preciso terminar de botar no ar para a minha empresa toda voltar ao trabalho, se alguém do suporte estiver on e puder, gentilmente, me ajudar, agradeço bastante

[6:46] **+55 87 9128-0580:**
> _+55 21 98102-9583: Pessoal, sigo precisando de ajuda... houve uma queda de conexão ao longo da noite, regerei a chave, autorizei, o IP está correto, minha chave está correta, mas dá o erro 401 dizendo que está revogada. Estou a noite toda refazendo um problema em meu sistema e preciso terminar de botar no ar para a minha empresa toda voltar ao trabalho, se alguém do suporte estiver on e puder, gentilmente, me ajudar, agradeço bastante_
[Mensagem de voz]

[6:48] **+55 21 98102-9583:**
> _+55 87 9128-0580: Mensagem de voz_
Bom dia, meu amigo! É windows. Na real estava rodando normalmente até atualizar e tentar usar o fable novo, deu o erro que mandei mais acima. Depois simplesmente parou de funcionar tudo e decidi trocar a chave. Agora ele fica "pensando" o tempo todo e não faz nada, tô quebrando a cabeça no claude code (que também já travou), consegui trocar a chave em um outro lugar "interno" também mas não está indo de jeito nenhum

[6:50] **+55 21 98102-9583:** [Imagem] o problema é que o vs code fica pensando toda hora e, depois de um tempo, ele pede para fazer o login novamente. Fico nesse looping

[6:58] **+55 87 9128-0580:** [Mensagem de voz]

[6:58] __+1 (226) 344-5508 entraram usando o link de convite__

[7:04] **+55 21 98102-9583:** Valeu mesmo pela ajuda, ainda não foi, mas sigo tentando aqui. Bom descanso amigo!

[7:18] **+94 77 862 7664:** _Mensagem apagada_

[7:40] **+55 17 99722-5777:** Bom dia pessoal tirar uma dúvida, não sou programador mais lutando aqui. Eu usava a Claude paga, uso para consultar e logacizar processos na justiça, e depois para criar relatórios destes processos. Eu criei um programa para mim q estava muito bom. Só q eu estava pagando 50 centavos por processo q gerava o relatório através da api da anthropic. Como assinei a Ghosti preciso de uma api para por no lugar, vcs forcem essa api ? Aqui está funcionando normal a Claude pelo chat, mais meu programa não pq preciso desta api

[7:40] **+55 17 99722-5777:** [Imagem]

[7:44] **+55 22 98111-9467:** Pessoal.. a API funciona com o Cowork e Design?

[7:50] __+55 15 99700-3605 entraram usando o link de convite__

[8:17] **+32 472 86 01 90:** _Mensagem apagada_

[8:52] **+32 472 86 01 90:** who is the admin?

[9:27] **+32 472 86 01 90:** _Mensagem apagada por um admin (+55 47 9618-4437)_

[9:55] **+55 11 98191-0224:** Mudou os nomes dos modelos tava configurado e caiu tudo aqui

[9:55] **+55 11 98191-0224:** ??

[9:56] **Jk Cli:** Att

[9:56] __+55 47 9618-4437 removeu +32 472 86 01 90__

[9:57] **+55 47 9618-4437:**
> _+55 11 98191-0224: Mudou os nomes dos modelos tava configurado e caiu tudo aqui_
Muda pro nome novo

[9:58] **+55 47 9618-4437:** Claude-Fable-5.1

[9:58] **+55 47 9618-4437:** Tá lá no site

[9:58] __+55 15 99726-7892 entraram usando o link de convite__

[9:59] **+55 11 98191-0224:** https://ghostcli.dev/dashboard

[9:59] **+55 11 98191-0224:** vou ver obrigado

[10:25] **+55 22 98111-9467:**
> _+55 22 98111-9467: Pessoal.. a API funciona com o Cowork e Design?_
Alguém sabe dizer?

[11:41] **+55 27 99694-0707:**
> _+55 22 98111-9467: Pessoal.. a API funciona com o Cowork e Design?_
[Mensagem de voz]

[11:55] **+55 15 99700-3605:** Salve salve! To pensando em usar a api… e tenho duvidas se realmente entrega oq promete, se eh realmente Claude… fable etc 

Se alguém puder deixar uns depoimentos aqui agradeço

[12:03] **Jk Cli:** Claro

[12:04] **Jk Cli:** @~🆚

[12:11] **+55 99 8145-3910:**
> _+55 15 99700-3605: Salve salve! To pensando em usar a api… e tenho duvidas se realmente entrega oq promete, se eh realmente Claude… fable etc 

Se alguém puder deixar uns depoimentos aqui agradeço_
Realmente, a qualidade da GhostCLI é de outro nível. Os tokens são ilimitados mesmo  eu achava que não, mas são de verdade. A experiência de uso no desktop é muito boa e a qualidade é ótima

[12:12] **+55 62 8630-8180:** a qualidade dos modelos é a mesma? ou dá diferença?

[12:17] **+55 15 99700-3605:** e a velocidade das respostas? é igual ao uso padrão do claude?

[12:19] **+55 99 8145-3910:**
> _+55 15 99700-3605: e a velocidade das respostas? é igual ao uso padrão do claude?_
a velocidade é a mesma

[12:19] **+55 99 8145-3910:** eu achei até melhor

[12:19] **+55 99 8145-3910:** única diferença foi o preço kkkkkkk

[12:19] **+55 99 8145-3910:** até porque pagar 1200 é inviável

[12:19] **+55 51 9824-6610:** o ghostcli tem o codex tambem?

[12:22] **+55 27 99691-4255:**
> _+55 51 9824-6610: o ghostcli tem o codex tambem?_
Tem não

[12:47] **+55 51 9184-0532:**
> _+55 51 9184-0532: Imagem: testando Fable 5.1_
@~Andre Tauan 
Sou suspeito em falar

[12:48] **+55 51 9184-0532:** Esse rodou por 7h direto

[13:04] **+55 35 9946-8945:**
> _+55 27 99691-4255: Tem não_
Da pra usar o Codex, mas os modelos não, somente Claude

[13:04] **+55 35 9946-8945:** [Imagem] É isso, feliz demais

[13:05] **+55 62 8630-8180:** Da pra rodar no app do Claude

[13:06] **+55 15 99700-3605:** gratidão pelos feedbacks... ja to usando e ta excelente

[13:14] **Jk Cli:** 😍🙏

[13:30] **+55 18 99809-1003:** Oi danii

[13:30] **+55 18 99809-1003:**
> _+55 35 9946-8945: Imagem: É isso, feliz demais_
Brab9

[13:48] __+55 49 9977-0032 entraram usando o link de convite__

[13:49] **+55 49 9977-0032:** Uma pergunta. . É Claude  Code ou Codex da OpenIA?

[13:50] **Jk Cli:** Claude code

[13:50] **+55 62 8630-8180:** alguem tem cli do codex?

[13:51] **+55 51 9184-0532:**
> _+55 49 9977-0032: Uma pergunta. . É Claude  Code ou Codex da OpenIA?_
Vai de Claude e será feliz

[13:51] **+55 49 9977-0032:** É que no anúncio cita também o Codex

[13:51] **+55 87 8805-8510:** Qual diferença de codex e claude ?

[13:52] **+55 49 9977-0032:** Eu usei os 2, mas achei mais preciso o codex

[13:53] **Jk Cli:** Claude é melhor

[13:54] **+55 35 9946-8945:** Claude é melhor, já tem os subagents dele mesmo paralelo, já o Codex é agent único

[13:54] **Jk Cli:** [Imagem]

[13:54] **Jk Cli:** Fable chegou para dominar

[13:54] **+55 62 8630-8180:**
> _+55 49 9977-0032: Eu usei os 2, mas achei mais preciso o codex_
também

[13:55] **+55 62 8630-8180:** alguem manda o link de compra por favor

[13:55] **+55 47 9618-4437:**
> _+55 62 8630-8180: alguem manda o link de compra por favor_
https://ghostcli.dev/

[13:55] **+55 49 9977-0032:** Quem aqui já está usando o plano de 189? O que pode nos dizer

[13:55] **+55 62 8630-8180:**
> _+55 47 9618-4437: https://ghostcli.dev/_
grato

[13:57] **+55 84 9401-5883:** Entrei agora no grupo não tô ainda pá do que realmente se trata, então eu pago a assinatura e tenho Claude code ilimitado ?

[13:57] **+55 51 9184-0532:** Quer saber na prática? 
Deixe o modelo agir como um agente autônomo em um ambiente sandbox de terminal para resolver um problema de infraestrutura ou automação de dados.
Assim terá sua conclusão

[13:57] **+55 51 9184-0532:**
> _+55 84 9401-5883: Entrei agora no grupo não tô ainda pá do que realmente se trata, então eu pago a assinatura e tenho Claude code ilimitado ?_
Sim

[13:58] **+55 15 99700-3605:**
> _+55 49 9977-0032: Quem aqui já está usando o plano de 189? O que pode nos dizer_
to usando e ta perfeito ate o momento... no claude desktop

[13:58] **+55 35 9946-8945:**
> _+55 62 8630-8180: grato_
Comprei ele direto kkkk nem testei o mais barato

[13:58] **+55 62 8630-8180:**
> _+55 35 9946-8945: Comprei ele direto kkkk nem testei o mais barato_
to pensando em ir tbm

[13:58] **+55 51 9184-0532:**
> _+55 49 9977-0032: Quem aqui já está usando o plano de 189? O que pode nos dizer_
Uso

[13:58] **+55 84 9401-5883:**
> _+55 51 9184-0532: Sim_
Como eu uso a ferramenta? Eu integro ela no Claude é extensão ou uso direto na ferramenta? Alguém pode dar a luz

[14:00] **+55 15 99700-3605:** no painel tem um video explicando - ultra simples.... conecta no claude desktop ou CLI e ja era

[14:00] **+55 84 9401-5883:**
> _+55 15 99700-3605: no painel tem um video explicando - ultra simples.... conecta no claude desktop ou CLI e ja era_
Top, vou ver

[14:05] **Jk Cli:** Veja lá

[14:05] **Jk Cli:** Ta top

[14:06] **+55 62 8630-8180:** Vocês acham que o resultado do Claude é bom como o do códex?

[14:07] **Jk Cli:** Claude em questão de qualidade de código n tem nem comparação

[14:07] **+55 62 8630-8180:** Muito melhor que o códex?

[14:08] **Jk Cli:** Em qualidade sim

[14:08] **+55 51 9425-4975:** Eu acho que depende muito, eu gosto de alternar, as vezes o claude sai melhor, as vezes o codex

[14:08] **Jk Cli:** Claude e o REAL MADRI NO AUGE

[14:09] **Jk Cli:** Códex e tipo psg agr

[14:18] **+55 49 9977-0032:** Alguém aqui conseguiu usar direto no VS Code com extensão oficial da Athropic?

[14:18] **+55 81 9575-5362:** Opa

[14:18] **+55 81 9575-5362:** Eu

[14:18] **+55 81 9575-5362:**
> _+55 49 9977-0032: Alguém aqui conseguiu usar direto no VS Code com extensão oficial da Athropic?_
Ah com a extensão oficial não

[14:18] **+55 49 9977-0032:** Precisava falar com alguém da GhostCli antes de assinar...

[14:18] **+55 47 9618-4437:**
> _+55 49 9977-0032: Alguém aqui conseguiu usar direto no VS Code com extensão oficial da Athropic?_
da pra usar com a extensao do claude no vscode

[14:19] **+55 49 9977-0032:**
> _+55 47 9618-4437: da pra usar com a extensao do claude no vscode_
Isso é bom, já me interessa

[14:19] **+55 81 9575-5362:**
> _+55 47 9618-4437: da pra usar com a extensao do claude no vscode_
Depois me dá o toque como fazer, eu tava usando pelo cline

[14:20] **+55 47 9618-4437:**
> _+55 81 9575-5362: Depois me dá o toque como fazer, eu tava usando pelo cline_
ok

[14:22] **+55 49 9977-0032:** Mais uma duvida, no site tem 2 planos, 135 e 164,90, mas aparece um de 189,90 com o Fable 5.1, esse me interessa mas não tem onde assinar ele...

[14:22] **+55 49 9977-0032:** [Imagem]

[14:23] **Você:** Uma assinatura serve pros meu dois pc, ou é uma assinatura por pc ?

[14:31] **+55 47 9618-4437:**
> _+55 49 9977-0032: Mais uma duvida, no site tem 2 planos, 135 e 164,90, mas aparece um de 189,90 com o Fable 5.1, esse me interessa mas não tem onde assinar ele..._
o de 189,90 é o de 164,90 só que com a api incluida pra usar no claude code etc

[14:31] **+55 87 9128-0580:**
> _+55 49 9977-0032: Imagem_
Quando for assinar é só selecionar o de 164,90 e quando for para a segunda etapa tem a API

[14:31] **+55 87 9128-0580:** Que é 25,00

[14:31] **+55 47 9618-4437:**
> _Você: Uma assinatura serve pros meu dois pc, ou é uma assinatura por pc ?_
serve pros dois pc, se estiver no mesmo ip (mesmo wifi/rede)

[14:32] **+55 87 9128-0580:** Vou já colocar os agentes pra trabalhar e mostrar pra vocês.

[14:32] **+55 87 9128-0580:** [Figurinha]

[14:34] **+55 84 9401-5883:**
> _+55 87 9128-0580: Vou já colocar os agentes pra trabalhar e mostrar pra vocês._
Mostra pra nós ver

[14:35] **+55 17 99722-5777:** [Imagem] Bom dia pessoal tirar uma dúvida, não sou programador mais lutando aqui. Eu usava a Claude paga, uso para consultar e logacizar processos na justiça, e depois para criar relatórios destes processos. Eu criei um programa para mim q estava muito bom. Só q eu estava pagando 50 centavos por processo q gerava o relatório através da api da anthropic. Como assinei a Ghosti preciso de uma api para por no lugar, vcs forcem essa api ? Aqui está funcionando normal a Claude pelo chat, mais meu programa não pq preciso desta api

[14:36] **+55 17 99722-5777:** Alguém consegue me ajudar

[14:36] **+55 47 9618-4437:**
> _+55 17 99722-5777: Imagem: Bom dia pessoal tirar uma dúvida, não sou programador mais lutando aqui. Eu usava a Claude paga, uso para consultar e logacizar processos na justiça, e depois para criar relatórios destes processos. Eu criei um programa para mim q estava muito bom. Só q eu estava pagando 50 centavos por processo q gerava o relatório através da api da anthropic. Como assinei a Ghosti preciso de uma api para por no lugar, vcs forcem essa api ? Aqui está funcionando normal a Claude pelo chat, mais meu programa não pq preciso desta api_
muda o programa pra usar nossa api

[14:37] **+55 47 9618-4437:** https://ghostcli.dev/docs

[14:37] **+55 47 9618-4437:** aqui tem as documentações

[14:39] **+55 17 99722-5777:** Certo, a api q ponho aí é a q tenho q foi feita e confirmado com meu email ? Pois se vc essa estou pondo e n está dando conexão com o ghost, e lá só consigo gerar uma api

[14:39] __+55 11 99786-9391 entraram usando o link de convite__

[14:42] **+55 47 9618-4437:**
> _+55 17 99722-5777: Certo, a api q ponho aí é a q tenho q foi feita e confirmado com meu email ? Pois se vc essa estou pondo e n está dando conexão com o ghost, e lá só consigo gerar uma api_
tem que gerar a key la no painel

[14:42] **+55 47 9618-4437:** segue o tutorial

[14:42] **+55 47 9618-4437:** https://ghostcli.dev/guia

[14:53] **+55 11 99786-9391:** boa tarde!
pergunta bem ingênua mas queria entender como funciona o mecanismo. Eu já assinei plataformas como o Adapta, por exemplo e lá o modelo era diferente deste.
Como que aqui conseguimos usar os modelos mais rápidos (e caros) de forma ilimitada? tem algum risco "calculado"? No sentido de derrubarem a plataforma ou coisas do tipo?

[14:55] **+55 49 9977-0032:** Precisava ter alguém da empresa pra dar um suporte, tem coisa que tem que ficar garimpando no site meia hora e que o suporte poderia resolver em 2 minutos....

[14:56] **+55 47 9618-4437:**
> _+55 49 9977-0032: Precisava ter alguém da empresa pra dar um suporte, tem coisa que tem que ficar garimpando no site meia hora e que o suporte poderia resolver em 2 minutos...._
explica no pv

[14:56] **+55 51 9425-4975:** Explica ai, tbm tenho duvida nessa parte

[14:58] **+55 99 8487-3868:**
> _+55 49 9977-0032: Precisava ter alguém da empresa pra dar um suporte, tem coisa que tem que ficar garimpando no site meia hora e que o suporte poderia resolver em 2 minutos...._
No site/ painel tem tudo detalhado e la no discord recebi um retorno ate que rapido quando surgiu duvidas[

[14:58] **+55 49 9977-0032:** Só to querendo assinar, mas na hora de gerar o qrcode, nada acontece

[14:58] **+55 47 9618-4437:**
> _+55 49 9977-0032: Só to querendo assinar, mas na hora de gerar o qrcode, nada acontece_
ve agora

[14:58] **+55 47 9618-4437:** ctrl + f5, tavamos aplicando uma alteração na frontend

[15:00] **+55 49 9977-0032:** [Imagem] Alguém ai sabe onde conseguir um cupom de desconto? kkk\

[15:00] **+55 47 9618-4437:**
> _+55 49 9977-0032: Imagem: Alguém ai sabe onde conseguir um cupom de desconto? kkk\_
MAXPELOPRO

[15:00] **+55 47 9618-4437:** cupom do plano max pelo preço do pro

[15:01] **+55 49 9977-0032:** Só mais um detalhe, no site dizia que como é por pix não precisava de documentos, mas ta pedindo o meu CPF

[15:02] **+55 47 9618-4437:**
> _+55 49 9977-0032: Só mais um detalhe, no site dizia que como é por pix não precisava de documentos, mas ta pedindo o meu CPF_
sim, pede cpf pra conseguir gerar o qrcode do pix. nossa gateway de pagamento precisa disso

[15:02] **+55 47 9618-4437:** mas pode colocar qualquer cpf, um gerado qualquer um

[15:02] **+55 47 9618-4437:** se nao quiser colocar o seu

[15:03] **+55 49 9977-0032:** Ta feito, assinado, agora é ver se atende a minha expectativa. kkk

[15:08] **+55 49 9977-0032:** To clicando em gerar chave mas volta pra tela inicial do painel e não gera

[15:09] **+55 47 9618-4437:**
> _+55 49 9977-0032: To clicando em gerar chave mas volta pra tela inicial do painel e não gera_
ta gerando normal aqui

[15:09] **+55 47 9618-4437:** tenta dar f5

[15:10] **+55 27 99694-0707:**
> _+55 49 9977-0032: To clicando em gerar chave mas volta pra tela inicial do painel e não gera_
da ctrl + shift +r para limpar o cache da aba

[15:10] **+55 27 99694-0707:** e tenta

[15:11] **+55 35 9946-8945:**
> _+55 47 9618-4437: MAXPELOPRO_
Vou usar mês que vem em

[15:11] **+55 47 9618-4437:**
> _+55 35 9946-8945: Vou usar mês que vem em_
usa que vale a pena kk

[15:13] **+55 49 9977-0032:**
> _+55 27 99694-0707: da ctrl + shift +r para limpar o cache da aba_
[Imagem] Tem jeito não....

[15:13] **+55 47 9618-4437:** não é ai mano

[15:13] **+55 47 9618-4437:** https://ghostcli.dev/dashboard

[15:13] **+55 47 9618-4437:** é aqui

[15:14] **+55 49 9977-0032:** [Imagem] Mas então, clico aqui, me leva pra la e me tras de volata aqui sem gerar nada

[15:15] **+55 47 9618-4437:** [Imagem] é aqui

[15:15] **+55 27 99691-4255:**
> _+55 49 9977-0032: Imagem: Tem jeito não...._
inspeciona para ver o retorno no network

[15:22] **+55 49 9977-0032:** Deu certo

[15:29] **+55 27 99898-8510:**
> _+55 51 9184-0532: Ele é muito mais enfático, analista e objetivo….
Uso codex junto para revisar e ele tem concordado e até achando que foi exagero ter feito algo que poderia ser mais simples kkkkk_
vc está usando codex api oficial paga ou alguma outra api?

[15:33] **+55 49 9977-0032:** _Mensagem apagada_

[15:38] __Discord: https://discord.gg/ghostcli
Site para adquirir um plano: https://ghostcli.dev__

[15:59] **+55 15 99726-7892:** pessoal acabei colocando meu email vinculado Anthropic, com isso nao estou conseguindo usao extensao google

[15:59] **+55 15 99726-7892:** como corrigir este conflito

[16:12] **+55 27 99898-8510:** [Imagem] @~João / @Jk Cli 
qual valor para adicionar mais chave

[16:34] **+55 15 99700-3605:** vcs ja enfrentaram algum tipo de instabilidade em algum momento? da ia simplesmente n responder, parar no meio do caminho, etc...?

como estou usando agora - e por enquanto ta tudo ok - quero saber de vcs que ja usam a mais tempo se isso pode acontecer

[16:51] **+55 11 99163-2402:** acontece as vezes

[16:57] **@fortytwowill:** Plano estável, ilimitado e LLM são legítimos?

[17:06] **Jk Cli:** Sim e ilimitado

[17:06] **Jk Cli:** LLM e legit

[17:07] **+55 27 99898-8510:**
> _+55 15 99700-3605: vcs ja enfrentaram algum tipo de instabilidade em algum momento? da ia simplesmente n responder, parar no meio do caminho, etc...?

como estou usando agora - e por enquanto ta tudo ok - quero saber de vcs que ja usam a mais tempo se isso pode acontecer_
já sim, até com api oficial já aconteceu, e quando ocorre isso e mando uma msg pedindo para verificar o pq parou o processo e continuar

[17:09] **+55 99 8487-3868:** [Imagem] 🤣 meu antigravity não brinca

[17:40] **Jk Cli:** Kkkkkkkkkkkkk

[17:44] **+55 98 8590-9579:** @~João Porque a ghost cli seria segura se a gente precisa compartilhar o IP??

[17:44] **+55 98 8590-9579:** Porque a ghost cli seria segura se a gente precisa compartilhar o IP??

[17:44] **+55 98 8590-9579:** Alguém sabe me explicar?

[17:44] **+55 47 9618-4437:**
> _+55 98 8590-9579: Alguém sabe me explicar?_
revenda e compartilhamento de acesso

[17:45] **+55 27 99691-4255:**
> _+55 98 8590-9579: @~João Porque a ghost cli seria segura se a gente precisa compartilhar o IP??_
Senão tu vai poder sair compartilhando seu token e usar em um monte de canto

[17:46] **+55 47 9618-4437:** no caso dai da pra pedir a liberação de um ip adicional por 25,00

[17:46] **+55 47 9618-4437:** e o pagamento é unico, no proximo mês só paga o valor do plano

[17:57] **+55 98 8536-3798:**
> _+55 99 8487-3868: Imagem: 🤣 meu antigravity não brinca_
Maaaas… tem alguma APIzinha pra isso disponível ? 👀

[17:58] **+55 99 8487-3868:**
> _+55 98 8536-3798: Maaaas… tem alguma APIzinha pra isso disponível ? 👀_
É UMA CONFIGURAÇÃO KKKK

[17:58] **+55 98 8536-3798:**
> _+55 15 99700-3605: vcs ja enfrentaram algum tipo de instabilidade em algum momento? da ia simplesmente n responder, parar no meio do caminho, etc...?

como estou usando agora - e por enquanto ta tudo ok - quero saber de vcs que ja usam a mais tempo se isso pode acontecer_
Algumas vezes no Antigravity e Opencode, só pedir pra continuar que ela volta

[17:59] **+55 98 8536-3798:**
> _+55 99 8487-3868: É UMA CONFIGURAÇÃO KKKK_
A sim kkkkkkk

[18:29] **@fortytwowill:** A quanto tempo vcs já usam?

[18:32] **+55 87 9128-0580:**
> _@fortytwowill: A quanto tempo vcs já usam?_
Meses já man

[18:32] **+55 87 9128-0580:** [Mensagem de album]

[18:32] **+55 87 9128-0580:** [Imagem]

[18:32] **+55 87 9128-0580:** [Imagem]

[18:33] **+55 87 9128-0580:** Até mandar novamente

[18:33] **+55 87 9128-0580:** O uso do mês passado

[18:36] **+55 51 9184-0532:**
> _+55 27 99898-8510: vc está usando codex api oficial paga ou alguma outra api?_
codex oficial

[18:37] **@fortytwowill:** E não tem limite de request também?

[18:38] __+55 47 9763-4367 entraram usando o link de convite__

[18:38] **+55 27 99898-8510:**
> _+55 47 9618-4437: no caso dai da pra pedir a liberação de um ip adicional por 25,00_
So liberação de outro ip, e gerar outra chave?

[18:45] **+55 81 9398-4490:** [Imagem]

[18:45] **+55 81 9398-4490:** Rapai

[18:48] **@fortytwowill:** Top

[18:53] **Jk Cli:** Meu Deus

[18:53] **Jk Cli:** 200k ☠️☠️☠️☠️☠️

[18:53] **Jk Cli:** Dois Rolex

[18:53] **Jk Cli:** ☠️☠️☠️☠️☠️

[18:54] **+55 81 9398-4490:** [Figurinha]

[18:54] **+55 81 9398-4490:** Nao corta meu acesso

[18:54] **Jk Cli:** Não vou

[18:54] **Jk Cli:** Meu Deus

[18:54] **Jk Cli:** ☠️☠️☠️☠️☠️☠️☠️☠️☠️☠️

[18:54] **+55 11 93065-1948:** [Imagem] Thx Ghost 🙏🏽❤️

[18:55] **+55 11 93065-1948:** The best gateway

[18:55] **Jk Cli:** Sério tá usado tbm ?

[18:55] **Jk Cli:** Slk

[18:56] **Jk Cli:** ☠️☠️☠️☠️☠️☠️

[18:57] **+55 21 98102-9583:**
> _+55 87 9128-0580: [album]_
[Imagem] te entendo 🥲

[18:57] **+55 87 9128-0580:**
> _+55 21 98102-9583: Imagem: te entendo 🥲_
Ksksksk brabo. Tinha que ter um rank de consumo

[18:57] **+55 87 9128-0580:** Eu esses dias estou usando pouco

[18:58] **+55 87 9128-0580:** Pq estou com outros serviços

[18:58] **+55 47 9763-4367:** [Imagem] E eu achando muito

[18:58] **+55 21 98102-9583:**
> _+55 87 9128-0580: Ksksksk brabo. Tinha que ter um rank de consumo_
Ia ser top! hahahahahah

[18:59] **+55 21 98102-9583:** bateu 100k de gasto teórico avulso com 3 dias de uso... eu tô indicando a beça a ferramenta

[19:01] **+55 87 9128-0580:** [Imagem]

[19:01] **+55 34 8411-4261:** E compensa ?

[19:01] **+55 87 9128-0580:** [Imagem]

[19:01] **+55 34 8411-4261:** É o claude sem limite

[19:01] **+55 34 8411-4261:** ?

[19:01] **+55 87 9128-0580:**
> _+55 34 8411-4261: E compensa ?_
é só olha esse consumo de token ksksks se fosse para pagar direto a anthropic

[19:01] **+55 87 9128-0580:** quanto não ficaria

[19:01] **+55 87 9128-0580:** ksksksk

[19:02] **+55 87 9128-0580:** [Imagem]

[19:03] **+55 34 8411-4261:** Esse aí n é igual aquelas extensão da lovable n né que usa um ia similar em cima ?

[19:03] **+55 21 98102-9583:**
> _+55 34 8411-4261: E compensa ?_
Então, se a gente comprasse crédito pela openrouter, por exemplo, o nosso gasto seria esse aí que estamos mostrando

[19:03] **+55 21 98102-9583:** A conta 20x é incentivado, mas tem os limites das sessões e também voaria o consumo

[19:03] **+55 21 98102-9583:**
> _+55 34 8411-4261: Esse aí n é igual aquelas extensão da lovable n né que usa um ia similar em cima ?_
Não não, é uma máscara que não conta o consumo do claude

[19:04] **+55 21 98102-9583:** Bati TANTA cabeça essa noite pra resolver que até entendi a funcionalidade das paradas 😂

[19:05] **Jk Cli:**
> _+55 34 8411-4261: Esse aí n é igual aquelas extensão da lovable n né que usa um ia similar em cima ?_
Esquece lovable

[19:05] **Jk Cli:** Tem iss n

[19:06] **+55 21 98102-9583:** Eu usava o do lovable, aqui realmente é mais eficiente

[19:06] **+55 34 8411-4261:** Tava fazendo uns site lá mas n compensa a dor de cabeça

[19:06] **+55 34 8411-4261:** Vou testar a claude aproveito e crio uns sistemas junto

[19:06] **+55 21 98102-9583:** Vim pra cá pq cagaram pra mim na comunidade do lovable que diziam ter API do claude também

[19:06] **Jk Cli:** Sabor Claude n

[19:07] **+55 21 98102-9583:**
> _+55 34 8411-4261: Vou testar a claude aproveito e crio uns sistemas junto_
Cara, o custo benefício é muito bom. Entrei segunda na comunidade e tô curtindo demais. Como disse, tô indicando pra muita gente

[19:09] **+55 34 8411-4261:** Aí ela n tem limite né

[19:09] **+55 34 8411-4261:** Usa e usa

[19:09] **+55 34 8411-4261:** Kkkkkk

[19:09] **+55 34 8411-4261:** Slc

[19:09] **+55 34 8411-4261:** Vou pegar um plano aqui pra testar

[19:10] **+55 21 98102-9583:** Sim, se fosse com limite nem se eu quisesse muito conseguiria gastar isso hahahah

[19:11] **+55 11 93065-1948:**
> _Jk Cli: Sério tá usado tbm ?_
Ss

[19:12] **+55 77 8879-1790:**
> _+55 81 9398-4490: Imagem_
Caramba

[19:14] **Jk Cli:** Coisa de louco

[19:14] **Jk Cli:**
> _+55 81 9398-4490: Imagem_
@all

[19:26] **+55 81 9398-4490:** Por enquanto to top1

[19:28] **Jk Cli:** E mesmo

[19:33] **@fortytwowill:** Alguém usa a API no Pi (oh my pi) ?

[19:37] **+55 34 8411-4261:** [Imagem] O que quer dizer essa api ?

[19:39] **Jk Cli:** Api pra você usar no desktop

[19:39] **Jk Cli:** Tem que comprar com api

[19:39] **Jk Cli:** Para poder utilizar no desktop

[19:39] **+55 27 99694-0707:** Suporte on as 23:30

[19:40] **+55 98 8536-3798:**
> _+55 81 9398-4490: Imagem_
Prompt: crie o Claude 100.100, não cometa erros, trabalhe 72 horas ininterruptas kkkkkk

[19:41] **Jk Cli:** 🤣🤣🤣🤣🤣🤣

[19:41] **+55 98 8536-3798:** 🤣🤣🤣

[19:50] **@fortytwowill:** [Imagem]

[19:51] **+55 81 9290-1382:** [Imagem] Alguém já teve esse problema ao enviar o prompt ?

[19:51] **+55 81 9290-1382:** [Mensagem de unknown]

[19:54] **+55 47 9618-4437:**
> _+55 81 9290-1382: Imagem: Alguém já teve esse problema ao enviar o prompt ?_
Tem que ativar o negócio

[19:54] **+55 47 9763-4367:**
> _+55 81 9290-1382: Imagem: Alguém já teve esse problema ao enviar o prompt ?_
So um minuto

[19:54] **+55 47 9618-4437:** Clica no botão do cowork no botão superior esquerdo e baixa

[19:55] **+55 81 9290-1382:** Ativando....

[19:56] **+55 81 9290-1382:** Reiniciou o computador

[19:56] **+55 47 9763-4367:** O Vm computer reinicia mesmo

[19:56] **+55 47 9763-4367:** mas normalemente ele pergunta

[19:57] **+55 81 9290-1382:**
> _+55 47 9763-4367: mas normalemente ele pergunta_
Eu confirmei

[19:58] **+55 49 9977-0032:** Assinei o plano com o fable, mas não aparece aqui pra escolher o Fable, se tiver alguém no grupo que seja do suporte por gentileza me ajudar

[19:58] **+55 81 9290-1382:** Vocês são FODA!!!

[19:58] **+55 81 9290-1382:** Deu certo

[19:59] **+55 81 9290-1382:** [Figurinha]

[19:59] **+55 81 9290-1382:** [Figurinha]

[20:01] **@fortytwowill:**
> _@fortytwowill: Imagem_
Ideia?

[20:01] **+55 47 9763-4367:**
> _+55 49 9977-0032: Assinei o plano com o fable, mas não aparece aqui pra escolher o Fable, se tiver alguém no grupo que seja do suporte por gentileza me ajudar_
Esta usando por onde

[20:01] **+55 47 9618-4437:**
> _@fortytwowill: Ideia?_
só mandar um continue

[20:02] **+55 49 9977-0032:**
> _+55 47 9763-4367: Esta usando por onde_
Vs code com extensão Claude Code e também pelo Powershel

[20:02] **+55 47 9763-4367:**
> _+55 49 9977-0032: Vs code com extensão Claude Code e também pelo Powershel_
Tem que alterar o modelo claude, o normal da anthropic tem nome com 5-1 e aqui eles estão com 5.1 no nome

[20:03] **+55 47 9618-4437:** [Imagem] TOP 1 Da Ghost

[20:03] **+55 47 9763-4367:** Pede para o opus ajustar para ti, pesquisando no endpoint de modelos do ghost que ele ja ajusta

[20:03] **+55 49 9977-0032:**
> _+55 47 9763-4367: Tem que alterar o modelo claude, o normal da anthropic tem nome com 5-1 e aqui eles estão com 5.1 no nome_
Já fiz isso mas da erro na hora usar

[20:03] **+55 81 9398-4490:**
> _+55 47 9618-4437: Imagem: TOP 1 Da Ghost_
Kkkkkkk to com muito tempo vago mesmo

[20:04] **+55 81 9398-4490:** Olhe que comprei o claude max 5x e estou usando os dois

[20:04] **+55 47 9618-4437:**
> _+55 81 9398-4490: Kkkkkkk to com muito tempo vago mesmo_
kkk

[20:05] **Jk Cli:** Quem é o top2

[20:05] **Jk Cli:** Kkkkkkk

[20:05] **Jk Cli:**
> _+55 81 9398-4490: Kkkkkkk to com muito tempo vago mesmo_
Top1

[20:05] **Jk Cli:** Kkkkk

[20:05] **Jk Cli:** Taporra

[20:08] **+55 47 9763-4367:**
> _+55 49 9977-0032: Já fiz isso mas da erro na hora usar_
Consegue mandar um print do erro?

[20:08] **+55 49 9977-0032:** ● API Error: 400 Unknown model: claude-fable-5-1

[20:09] **+55 49 9977-0032:** [Imagem]

[20:10] **+55 65 8407-8761:** Boa noite!
Qual plataforma o pessoal tem usado aqui? 

Alguém antigravity ou Codex?

[20:10] **+55 47 9618-4437:**
> _+55 49 9977-0032: ● API Error: 400 Unknown model: claude-fable-5-1_
to vendo aqui um momento

[20:11] **+55 47 9763-4367:** [Imagem] abre o teu settings global e veja se esta assim

[20:11] **+55 47 9763-4367:** lembrando, que se tu estiver em uma pasta de projeto, e tenha settings de modelo tem que trocar la tbm

[20:13] **+55 65 8407-8761:**
> _+55 65 8407-8761: Boa noite!
Qual plataforma o pessoal tem usado aqui? 

Alguém antigravity ou Codex?_
?

[20:13] **+55 49 9977-0032:**
> _+55 47 9763-4367: Imagem: abre o teu settings global e veja se esta assim_
[Imagem]

[20:13] **@fortytwowill:**
> _+55 65 8407-8761: Boa noite!
Qual plataforma o pessoal tem usado aqui? 

Alguém antigravity ou Codex?_
Omp

[20:14] **+55 47 9763-4367:**
> _+55 65 8407-8761: ?_
Ide claude code, e claude code cli

[20:14] **+55 47 9763-4367:**
> _+55 49 9977-0032: Imagem_
Que doido

[20:14] **+55 65 8407-8761:** [Mensagem de voz]

[20:15] **+55 47 9618-4437:**
> _+55 65 8407-8761: Mensagem de voz_
funciona em ambas, no codex e antigravity

[20:15] **+55 47 9618-4437:** tem guia e documentação no site

[20:16] **+55 47 9763-4367:**
> _+55 65 8407-8761: Mensagem de voz_
Códex eu usei funcionou, antigravity não sei

[20:16] **+55 47 9763-4367:**
> _+55 47 9618-4437: funciona em ambas, no codex e antigravity_
Ai sim, antigravity é top

[20:16] **+55 65 8407-8761:** Pode usar ilimitado

[20:16] **+55 21 98102-9583:**
> _+55 49 9977-0032: ● API Error: 400 Unknown model: claude-fable-5-1_
Isso apareceu demais pra mim essa madrugada, pelo que entendi a nomeação do Fable está divergente, é 5-1 e está como 5.1

[20:16] **+55 65 8407-8761:** Tem alguma restrição

[20:16] **+55 49 9977-0032:**
> _+55 49 9977-0032: Imagem_
Parece que funcionou. C de claude estava em maiúsculo   Vou testar melhor

[20:17] **+55 21 98102-9583:** Ia falar pro João no privado

[20:17] **+55 47 9618-4437:**
> _+55 49 9977-0032: Imagem_
corrigido testa agr

[20:17] **+55 47 9763-4367:**
> _+55 49 9977-0032: Parece que funcionou. C de claude estava em maiúsculo   Vou testar melhor_
Ahh boaaa

[20:17] **+55 47 9618-4437:**
> _+55 21 98102-9583: Isso apareceu demais pra mim essa madrugada, pelo que entendi a nomeação do Fable está divergente, é 5-1 e está como 5.1_
arrumei aq, n tinha visto isso

[20:17] **+55 21 98102-9583:** Vc consegue abrir uma nova sessão no Fable 5.1, mas mudar no curso dela não tava dando

[20:17] **+55 21 98102-9583:**
> _+55 47 9618-4437: arrumei aq, n tinha visto isso_
Essa era a surra que eu tava tomando na madrugada, por isso te chamei no privado rs

[20:19] **Jk Cli:** Slk

[20:19] **Jk Cli:** To ficando louco já muita gente

[20:19] **Jk Cli:** Kkkkkk

[20:20] **+55 21 98102-9583:**
> _Jk Cli: To ficando louco já muita gente_
Liga pro psicólogo então e diz que ele vai ter mais trabalho contigo, vem mais gente 😂

[20:21] **Jk Cli:** Mkkkkkkkkkkkkk

[20:21] **Jk Cli:** Mds do céu

[20:21] **+55 21 98102-9583:** Vcs acharam o que todo mundo tá precisando, pô. Esse é o ônus hahahahah

[20:22] **Jk Cli:** Mkkkkkkkkkkkk

[20:22] **Jk Cli:** Sim

[20:22] **Jk Cli:** 25% galera

[20:22] **Jk Cli:** Indicou ganhou eim

[20:22] **Jk Cli:** Pix pix pix

[20:22] **Jk Cli:** 👻👻👻👻👻

[20:23] **+55 21 98102-9583:**
> _Jk Cli: 25% galera_
Cara, isso é maneiro...

[20:23] **+55 21 98102-9583:** [Imagem] mas isso não se paga hahahah

[20:24] **+20 10 01449601:** Hello, can any support talk to me in private? i'm having issues with ghostcli setup

[20:25] __[Notificação do sistema]__

[20:32] **+55 49 9977-0032:** [Imagem] Pessoal, alguém ta usando o Codex? Eu procurei no site, nos vídeos mas não encontrei uma forma de usar o codex no lugar do claude code

[20:33] **+55 51 9425-4975:** No codex da pra usar os modelos da open ia?

[20:34] __+57 301 7977034 entraram usando o link de convite__

[20:34] **+55 49 9977-0032:** Eu escolhi um plano que me fez entender que sim. Mas posso estar errado....

[20:34] **+55 47 9618-4437:**
> _+55 51 9425-4975: No codex da pra usar os modelos da open ia?_
não, somente os modelos da anthropic e glm

[20:34] **+55 47 9618-4437:**
> _+55 49 9977-0032: Imagem: Pessoal, alguém ta usando o Codex? Eu procurei no site, nos vídeos mas não encontrei uma forma de usar o codex no lugar do claude code_
@~Everteson

[20:34] **+55 51 9425-4975:** Qual a vantagem de ter o codex entao?

[20:34] **+55 49 9977-0032:**
> _+55 49 9977-0032: Imagem: Pessoal, alguém ta usando o Codex? Eu procurei no site, nos vídeos mas não encontrei uma forma de usar o codex no lugar do claude code_
Esse print aui então não tem nada haver com o codex da OpenIA?

[20:35] **+55 47 9618-4437:**
> _+55 51 9425-4975: Qual a vantagem de ter o codex entao?_
depende de pessoa pra pessoa, alguns se adapta melhor ao codex. mas eu pessoalmente prefiro o claude code

[20:35] **+55 47 9763-4367:**
> _+55 47 9618-4437: @~Everteson_
Me dá uns minutos

[20:35] **+55 47 9763-4367:** Deu pau no pc aqui kkkk

[20:39] **Jk Cli:**
> _+55 47 9618-4437: depende de pessoa pra pessoa, alguns se adapta melhor ao codex. mas eu pessoalmente prefiro o claude code_
Claudinho code

[20:39] **+55 47 9618-4437:**
> _Jk Cli: Claudinho code_
claudinho code é mto gostoso pra codar

[20:40] **Jk Cli:** Claudinho + tintinho pags

[20:40] **Jk Cli:** 👻

[20:41] **+57 301 7977034:** hola

[20:41] **+55 47 9618-4437:**
> _+57 301 7977034: hola_
hola

[20:41] **+57 301 7977034:** tengo una pregunta

[20:41] **+57 301 7977034:** la api se puede integrar con cualquier agente que maneje openai?

[20:42] **+55 47 9618-4437:**
> _+57 301 7977034: la api se puede integrar con cualquier agente que maneje openai?_
si

[20:42] **+57 301 7977034:** es ilimitado, sin interrupciones?

[20:42] **+55 47 9618-4437:** Compatible con OpenAI y Anthropic api compatible

[20:42] **+55 47 9618-4437:**
> _+57 301 7977034: es ilimitado, sin interrupciones?_
si, ilimitado

[20:42] **+57 301 7977034:** modelos Claude y codex?

[20:43] **+55 47 9618-4437:**
> _+57 301 7977034: modelos Claude y codex?_
solo modelos Claude

[20:43] **+57 301 7977034:** todos los modelos de Claude cierto

[20:43] **+57 301 7977034:** disculpe preguntar demasiado

[20:43] **+55 47 9618-4437:**
> _+57 301 7977034: todos los modelos de Claude cierto_
si sonnet 5, opus 5, fable 5.1

[20:43] **+55 47 9618-4437:** também temos o glm 5.3

[20:43] **+57 301 7977034:** perfecto ya me organizo para ver si compro el mes en dado caso tienen política de reembolso?

[20:44] **+57 301 7977034:** y si aceptan tarjeta

[20:44] **+55 47 9618-4437:**
> _+57 301 7977034: perfecto ya me organizo para ver si compro el mes en dado caso tienen política de reembolso?_
reembolso em até 7 días se nao por constante uso del producto

[20:44] **+55 47 9618-4437:**
> _+57 301 7977034: y si aceptan tarjeta_
si

[20:44] **+55 47 9618-4437:** Puedes comprar en el sitio web.

[20:45] **+57 301 7977034:** perfecto

[20:45] **+57 301 7977034:** ya miro

[20:48] **+55 47 9763-4367:**
> _+55 49 9977-0032: Imagem: Pessoal, alguém ta usando o Codex? Eu procurei no site, nos vídeos mas não encontrei uma forma de usar o codex no lugar do claude code_
Tu tem algum outro agente de ia no pc?

[20:48] **+55 47 9763-4367:** O mais fácil é tu pedir para ele configurar no códex o getway para o ghost e sua chave api

[20:48] **+55 47 9763-4367:** Meu oc está voltando já mostro como fica a config

[20:51] **+55 47 9763-4367:** pc*

[20:52] **+55 49 9977-0032:**
> _+55 47 9763-4367: O mais fácil é tu pedir para ele configurar no códex o getway para o ghost e sua chave api_
Mas pelo oque o @~João disse não tem o Codex

[20:52] **+55 47 9618-4437:**
> _+55 47 9618-4437: funciona em ambas, no codex e antigravity_
.

[20:52] **+55 47 9618-4437:** em nenhum momento falei que nao funciona no codex

[20:53] __+351 910 130 122 entraram usando o link de convite__

[20:54] **+55 47 9763-4367:**
> _+55 49 9977-0032: Mas pelo oque o @~João disse não tem o Codex_
Não tem os modelos do GPT, mas com a famosa gambi, tu pode usar o claude la

[20:55] **+55 49 9977-0032:**
> _+55 47 9763-4367: Não tem os modelos do GPT, mas com a famosa gambi, tu pode usar o claude la_
Sim, mas o que eu queria era o codex mesmo, to mais acostumado, mas agora vou me adaptar co o Claude code mesmo....

[20:55] **+351 910 130 122:** Ghostcli dá para usar com claude app e possui os mesmos modelos (fable e opus 5) com limites de 5 horas e x tokens por mês?

[20:56] **+55 47 9618-4437:**
> _+351 910 130 122: Ghostcli dá para usar com claude app e possui os mesmos modelos (fable e opus 5) com limites de 5 horas e x tokens por mês?_
sim da pra usar com o app do claude, é o principal inclusive e tem o fable e opus sim, não tem limite de consumo

[20:58] **+351 910 130 122:** Basicamente posso usar na minha conta atual claude? Tem acesso ao code, certo?

[20:58] **+55 47 9618-4437:**
> _+351 910 130 122: Basicamente posso usar na minha conta atual claude? Tem acesso ao code, certo?_
pode sim, e tem o acesso ao code

[21:01] **+351 910 130 122:** Ok. Não é necessário alterar nada na config do claude, certo? Basta fazer login e ja estara activado?

[21:01] **+55 47 9618-4437:**
> _+351 910 130 122: Ok. Não é necessário alterar nada na config do claude, certo? Basta fazer login e ja estara activado?_
isso

[21:04] **@fortytwowill:** Alguém usando o Claude com ruflo?

[21:06] **Jk Cli:**
> _+351 910 130 122: Ok. Não é necessário alterar nada na config do claude, certo? Basta fazer login e ja estara activado?_
Yes

[21:18] **+55 47 9763-4367:**
> _+351 910 130 122: Ok. Não é necessário alterar nada na config do claude, certo? Basta fazer login e ja estara activado?_
Na vdd tem que configurar sim, tu tem que trocar para o getway deles com a chave deles

[21:18] **+55 47 9763-4367:** Mas é de boa para fazer

[21:36] __+55 77 9917-7747 entraram usando o link de convite__

[22:15] **+55 27 99694-0707:** [Imagem] que tesao do cao esse novo fabio

[22:15] **+55 27 99694-0707:** e o fabio com botox

[22:18] **+55 27 99694-0707:** nossa senhora da i.a o trem e tao avancado se doido

[22:18] **+55 27 99694-0707:** suporte on em 30 min

[22:23] __+20 11 00996584 entraram usando o link de convite__

[22:58] **+55 99 8487-3868:** [Imagem] Fazendo um extra so divulgando o claude da ghost hehe

[23:10] __+230 5493 1587 entraram usando o link de convite__

[23:31] **Jk Cli:**
> _+55 99 8487-3868: Imagem: Fazendo um extra so divulgando o claude da ghost hehe_
Hehehe

[23:31] **Jk Cli:** Kkkkk

[23:31] **Jk Cli:**
> _+55 99 8487-3868: Imagem: Fazendo um extra so divulgando o claude da ghost hehe_
@all  e 25% eim galera

[23:44] __+55 47 9767-6672 entraram usando o link de convite__

[23:47] **+55 27 99694-0707:**
> _+55 99 8487-3868: Imagem: Fazendo um extra so divulgando o claude da ghost hehe_
hmmm ja posso te pedir emprestado einn

[23:49] __+55 32 8817-1150 entraram usando o link de convite__

[23:49] **+55 99 8487-3868:** [Imagem] Eu to vendendo acesso ao fornecedor kkkk
os cara compram e entra no meu link de afiliado hehe

[23:49] **+55 32 8817-1150:** a blz

[23:51] **+55 27 99694-0707:**
> _+55 99 8487-3868: Imagem: Eu to vendendo acesso ao fornecedor kkkk
os cara compram e entra no meu link de afiliado hehe_
danado

[23:52] __+55 48 9101-5225 entraram usando o link de convite__

[23:57] **+55 47 9767-6672:** Ola pessoal tudo certo!

Uma dúvida é apenas para Claude ou para Codex tbm?

[23:58] **Jk Cli:** Only Claude

[23:58] **Jk Cli:** Apenas Claude code

[23:58] **+55 47 9767-6672:**
> _Jk Cli: Apenas Claude code_
Muito obrigado

---

## 4 de setembro de 2026

[0:01] **Jk Cli:** Sim

[0:01] **+55 35 9946-8945:** [Imagem] Óia o pau moendo

[0:14] **Jk Cli:** Taporra

[0:15] **Jk Cli:** Kkkkk

[0:15] **+55 35 9946-8945:**
> _Jk Cli: Taporra_
Tá fazendo um teste e2e em mobile

[0:16] **+55 11 95990-6786:** Mãe ❤️ entrou no grupo

[0:17] **Jk Cli:** Taporra

[0:17] **Jk Cli:** Kkkk

[0:21] **+55 35 9946-8945:** Suporte, Web Search funciona com a API?

[0:33] **+55 27 99694-0707:**
> _+55 47 9767-6672: Ola pessoal tudo certo!

Uma dúvida é apenas para Claude ou para Codex tbm?_
funciona no codex tb

[0:33] **+55 27 99694-0707:** para programacao, no codex, tem um up a mais

[0:33] **+55 27 99694-0707:** _Mensagem apagada_

[0:33] **+55 27 99694-0707:** _Mensagem apagada_

[0:34] **+55 27 99694-0707:** _Mensagem apagada_

[0:34] **+55 27 99694-0707:** _Mensagem apagada_

[0:34] **+55 27 99694-0707:**
> _+55 35 9946-8945: Imagem: Óia o pau moendo_
voce disse o pau moendo?

[0:35] **+55 27 99694-0707:**
> _+55 27 99694-0707: funciona no codex tb_
codex extensao tb

[2:14] __+57 301 7977034 adicionou +57 301 6286091__

[2:15] __+55 11 94321-3342 entraram usando o link de convite__

[2:15] __+56 9 2986 0871 entraram usando o link de convite__

[2:20] __+1 (617) 320-6789 entraram usando o link de convite__

[2:31] __+55 21 99960-2516 entraram usando o link de convite__

[4:04] __+55 61 9842-2891 entraram usando o link de convite__

[4:04] **+55 61 9842-2891:** Rapqzeada boa noite

[4:05] **+55 61 9842-2891:** A api tem limite? Como é? Querendo colocar em um projeto aqui

[4:05] **Jk Cli:** Tem limite não

[4:05] **Jk Cli:** Boa noite /bom dia

[4:06] **Jk Cli:**
> _+55 61 9842-2891: A api tem limite? Como é? Querendo colocar em um projeto aqui_
Sem limites

[4:06] **+55 61 9842-2891:** Demorou bb, meter bala

[4:06] **+55 61 9842-2891:** _Mensagem apagada_

[4:06] **+55 61 9842-2891:** Sejam sinceros nego

[4:10] **+55 47 9618-4437:**
> _+55 61 9842-2891: Sejam sinceros nego_
Oq?

[4:34] **+57 301 7977034:** me gusta es rápido

[4:34] **+57 301 7977034:** si siguen así me tendrán como cliente

[4:34] **+57 301 7977034:** siempre

[6:57] __+55 11 97826-1508 entraram usando o link de convite__

[7:14] __+55 11 92085-9892 entraram usando o link de convite__

[7:50] **+55 27 99694-0707:**
> _+57 301 7977034: me gusta es rápido_
me gusta tb

[7:50] **+55 27 99694-0707:** minha nossa senhora minha nossa senhoraaaaa rooooooooriugueyyy

[7:50] **+55 27 99694-0707:** roriugui no problema

[7:51] **+55 27 99694-0707:** suporte on

[7:51] **+55 47 9763-4367:** Suporte 23h por dia

[7:51] **+55 47 9763-4367:** 01h pra dormir

[7:51] **+55 47 9763-4367:** _Mensagem apagada_

[7:51] **+55 47 9763-4367:** _Mensagem apagada_

[7:52] **+55 27 99694-0707:**
> _+55 47 9763-4367: 01h pra dormir_
rapais sou contra essas merda de durmi

[7:52] **+55 27 99694-0707:** n sei pq o sehumano dorme

[7:52] **+55 27 99694-0707:** ai lanca a i.a

[7:53] **+55 27 99694-0707:** ai caba de lasca com o resto do caba

[10:18] **+55 81 9290-1382:** Bom dia galera , alguém conhece quem vende créditos lovable, extensão, ou sabe com quem eu consigo no precinho? Me tornando revendendor.

[11:01] **@fortytwowill:** Viu no g2g.com ?

[11:07] **+55 27 99694-0707:** [Imagem] pega fogo mac

[11:07] **+55 91 9301-8410:**
> _+55 81 9290-1382: Bom dia galera , alguém conhece quem vende créditos lovable, extensão, ou sabe com quem eu consigo no precinho? Me tornando revendendor._
Eu vendo mano

[11:08] **+55 91 9301-8410:** @Castro Kwai me conhece

[11:20] **+55 35 9946-8945:**
> _+55 27 99694-0707: Imagem: pega fogo mac_
[Imagem] Tá de boa aqui

[11:20] **+55 35 9946-8945:** Codou a noite toda

[11:21] **+55 27 99694-0707:**
> _+55 35 9946-8945: Imagem: Tá de boa aqui_
estaciono na sombra 1 pokim ne

[11:21] **+55 27 99694-0707:** pra n bater o moto

[11:21] **+55 35 9946-8945:** [Figurinha]

[11:21] **+55 35 9946-8945:** Rapadura is Sweet, but not is soft

[11:27] **Jk Cli:**
> _+55 35 9946-8945: Imagem: Tá de boa aqui_
Taporra

[11:27] **+55 35 9946-8945:** claude code, codex funciona

[11:27] **+55 35 9946-8945:**
> _Jk Cli: Taporra_
Ta com pouco ainda, quero um dual xeon

[12:49] __+55 34 8411-4261 adicionou +55 75 8369-6286 e +55 34 9729-4956__

[12:55] **+55 11 97826-1508:** Como tá o fable 5.1

[13:06] **+55 27 99694-0707:**
> _+55 11 97826-1508: Como tá o fable 5.1_
rapais

[13:07] **+55 27 99694-0707:** eu sei nao

[13:07] **+55 27 99694-0707:** eu to vagabundo

[13:07] __+55 11 94057-2122 entraram usando o link de convite__

[13:07] **+55 27 99694-0707:**
> _+55 11 97826-1508: Como tá o fable 5.1_
eu fiz 1 cs no fable 5.1

[13:07] **+55 27 99694-0707:** eu larguei agora do jogo

[13:07] **+55 27 99694-0707:** o trem ficou bom demais

[13:07] **+55 27 99694-0707:** to tentando implementa a i.a no cs

[13:07] **+55 27 99694-0707:** para o CS ficar vivo

[13:08] **+55 11 92085-9892:**
> _+55 27 99694-0707: para o CS ficar vivo_
vai treinando a IA em como atirar bem, depois a gente n pode reclamar do exterminador do futuro, kkkkkkkkkk

[13:08] **+55 27 99694-0707:** tanto nas acoes do bot, como na questao estrutural do jogo, de acordo com o jogo a i.a vai codando mais o jogo no backend e fazendo o themerge no jogo

[13:08] **+55 27 99694-0707:** sou especialista em the merge

[13:08] **+55 11 92085-9892:**
> _+55 27 99694-0707: sou especialista em the merge_
O que é The Merge?

[13:09] **+55 27 99694-0707:**
> _+55 11 92085-9892: O que é The Merge?_
implementacao na producao sem danos erros ou bugs

[13:09] **+55 27 99694-0707:** apelido carinhoso que o ethereum deu

[13:09] **+55 27 99694-0707:** themerge

[13:09] **+55 11 92085-9892:** Legal. Tem alguma técnica pra compartilhar?

[13:09] **+55 11 92085-9892:** (eu nunca tinha ouvido falar disto até hj)

[13:09] **+55 11 92085-9892:** haha

[13:11] **+55 27 99694-0707:**
> _+55 11 92085-9892: Legal. Tem alguma técnica pra compartilhar?_
rapais

[13:12] **+55 27 99694-0707:** o que voce fais

[13:12] **+55 11 92085-9892:** eu tô aprendendo a programar. (faço IF)

[13:15] **+55 27 99694-0707:**
> _+55 11 92085-9892: eu tô aprendendo a programar. (faço IF)_
aprendendo a programar, certo, se apaixone por 1 linguagem, fique extremamente bom nela, que as proximas vai ser muito izi

[13:15] **+55 27 99694-0707:** de linguagem para outra n muda muita coisa

[13:15] **+55 27 99694-0707:** sintax e logica

[13:15] **+55 27 99694-0707:** pra voce ficar pica em logica e bom jogar muito jogo, so n manda mae tnc em

[13:15] **+55 11 92085-9892:**
> _+55 27 99694-0707: aprendendo a programar, certo, se apaixone por 1 linguagem, fique extremamente bom nela, que as proximas vai ser muito izi_
então, o professor, tá ensinando python. Tá sendo legal

[13:15] **+55 11 92085-9892:**
> _+55 27 99694-0707: pra voce ficar pica em logica e bom jogar muito jogo, so n manda mae tnc em_
slk, kkkk

[13:15] **+55 27 99694-0707:**
> _+55 11 92085-9892: então, o professor, tá ensinando python. Tá sendo legal_
excelente e completa linguagem para comecar

[13:16] **+55 27 99694-0707:** se faz tudo no python

[13:16] **+55 27 99694-0707:** .dmg para mac .exe para windows

[13:16] **+55 27 99694-0707:** trabalha muitooooooooo bem no debian ubuntu

[13:16] **+55 27 99694-0707:** so mais fan do debian e mais leve

[13:17] **+55 27 99694-0707:**
> _+55 11 92085-9892: slk, kkkk_
mano, uma vez mandei mamae tnc, o tapa foi tao sinistro, foi e o computador pro chao

[13:17] **+55 27 99694-0707:** tinha 16 anos

[13:18] **+55 27 99694-0707:** slk n esqueco ate hj

[13:18] **+55 11 92085-9892:**
> _+55 27 99694-0707: slk n esqueco ate hj_
kkkkkkkkkkkkkkkkkkkkkk

[13:19] **+55 11 92085-9892:** mae é sagrada vei, Aqui nem olhar torto a gente olha, senão o que tiver na mão vai

[13:21] **+55 27 99694-0707:** [Vídeo]

[13:23] **+55 11 97826-1508:**
> _+55 27 99694-0707: Vídeo_
Massa

[13:25] **+55 84 9401-5883:**
> _+55 27 99694-0707: Vídeo_
Todos os mac a tela fica assim ? Kkkkkk

[13:26] **+55 27 99694-0707:**
> _+55 84 9401-5883: Todos os mac a tela fica assim ? Kkkkkk_
janela ta aberta da caverna aki

[13:27] **+55 84 9401-5883:**
> _+55 27 99694-0707: janela ta aberta da caverna aki_
Nunca vi um com a tela limpinha kkk

[13:27] **+55 35 9946-8945:**
> _+55 84 9401-5883: Todos os mac a tela fica assim ? Kkkkkk_
Siim

[13:28] **+55 11 92085-9892:** vou nem mostrar o Lenovo daqui de casa então

[13:29] **+55 84 9401-5883:**
> _+55 11 92085-9892: vou nem mostrar o Lenovo daqui de casa então_
Lenovo é foda kkk

[13:32] **+55 11 92085-9892:**
> _+55 84 9401-5883: Lenovo é foda kkk_
depois que eu ganhar grana eu pego um Mac. por ora ele tá atendendo até bm

[13:34] **+55 27 99694-0707:**
> _+55 11 92085-9892: vou nem mostrar o Lenovo daqui de casa então_
mostra a mansao das formigas =D

[13:34] **+55 27 99694-0707:**
> _+55 11 92085-9892: depois que eu ganhar grana eu pego um Mac. por ora ele tá atendendo até bm_
claro q vai, quem faz, acontece

[13:34] **+55 27 99694-0707:** quem faz nada, merece nada

[13:35] **+55 11 92085-9892:**
> _+55 27 99694-0707: quem faz nada, merece nada_
Pow, eu sinto que tem gente, colegas meus, que desperdiçam demais o tempo deles.

[13:36] **+55 27 99694-0707:**
> _+55 11 92085-9892: Pow, eu sinto que tem gente, colegas meus, que desperdiçam demais o tempo deles._
trajico, ja vende 1 plano funerario pra eles

[15:57] **+55 62 9444-5039:**
> _+55 27 99694-0707: eu fiz 1 cs no fable 5.1_
Solta pra ver

[16:16] **+55 27 99694-0707:**
> _+55 62 9444-5039: Solta pra ver_
[Mensagem de voz]

[16:16] **+55 62 9444-5039:** Boaa

[16:17] **+55 27 99694-0707:** vo solta video pra voces Abracadabra Chaveiro

[16:17] **+55 27 99694-0707:** @~Rafael Junior  ja ta usando kkk

[16:25] **+55 49 9977-0032:** Instalei no meu pc e ta rodando normal, pra mim usar em outro pc na mesma rede, preciso fazer o que? Não vou usar simultaneamente...

[16:28] **+55 81 9398-4490:** [Imagem] Porque disso ?

[16:28] **+55 81 9398-4490:** Tava funcionando de boas

[16:29] **+55 48 9101-5225:**
> _+55 81 9398-4490: Imagem: Porque disso ?_
Teu ip deve ter trocado, tem q liberar no site denovo

[16:29] **+55 81 9398-4490:**
> _+55 48 9101-5225: Teu ip deve ter trocado, tem q liberar no site denovo_
Beleza

[16:30] **+55 49 9977-0032:** Não o Ip ta certo, mas pegou o IP da minha internet, se eu tento usar no meu PC vai de boa, se eu tento usar no outro PC loga de boa mas logo cai e pede pra conectar de novo

[16:31] **+55 81 9398-4490:**
> _+55 49 9977-0032: Não o Ip ta certo, mas pegou o IP da minha internet, se eu tento usar no meu PC vai de boa, se eu tento usar no outro PC loga de boa mas logo cai e pede pra conectar de novo_
Pode ser pq voce nao colocou que seria permanente a chave ou algo assim

[16:31] **+55 49 9977-0032:** vou verificar isso

[18:06] **+351 910 130 122:** Alguém aqui ja usou binance para efetuar pagamento da ghost?

[18:06] **+55 27 99694-0707:** normal

[18:07] **+351 910 130 122:** quero saber se é por BSC / BEP20 que transfiro USDC.

[18:12] **+55 27 99694-0707:**
> _+351 910 130 122: quero saber se é por BSC / BEP20 que transfiro USDC._
vou confirmar pra o senhor dr

[18:12] **+55 27 99694-0707:** so 1 seg

[18:13] **+351 910 130 122:** ok, fico a aguardar.

[18:13] **+55 27 99694-0707:**
> _+351 910 130 122: ok, fico a aguardar._
nao consigo te resp, so vizualizo pix

[18:17] **+351 910 130 122:** Pix não existe fora do brasil. Who cobra 25% em taxas. Paypal tambem não está disponivel como pagamento. Sobra apenas crypto, mas necessito de saber a chain pois no website não especifica.

[18:23] **+55 47 9618-4437:**
> _+351 910 130 122: Pix não existe fora do brasil. Who cobra 25% em taxas. Paypal tambem não está disponivel como pagamento. Sobra apenas crypto, mas necessito de saber a chain pois no website não especifica._
use solana, é instaneo e a melhor

[18:24] **+351 910 130 122:** USDC não tem solana chain disponivel.

[18:25] **+55 47 9618-4437:**
> _+351 910 130 122: USDC não tem solana chain disponivel._
[Imagem] use solana

[18:26] **+351 910 130 122:** eu estou com USDC não solana

[18:26] **+351 910 130 122:** Só necessito de saber qual chain usar para tranferir USDC na binance.

[18:32] **+55 21 98102-9583:** Galera, vcs conseguiram acesso ao Astra?

[18:34] **+55 62 8630-8180:** Ainda não

[18:48] **+55 27 99694-0707:**
> _+55 21 98102-9583: Galera, vcs conseguiram acesso ao Astra?_
astra?

[18:48] **+55 27 99694-0707:**
> _+55 21 98102-9583: Galera, vcs conseguiram acesso ao Astra?_
ja tive 1 astra 2.0

[18:52] **+55 91 8400-8615:**
> _+55 21 98102-9583: Galera, vcs conseguiram acesso ao Astra?_
Ainda não tbm

[19:08] **+55 27 99694-0707:** _Mensagem apagada_

[19:11] **+55 27 99694-0707:** [Imagem] 1 tarefa comeu metade do limite kkkkkkk por isso que eu falo rapasiada ghost e ilimitado

[19:11] **+55 27 99694-0707:** esse astra e 1 aspirador de limite

[19:18] **+55 27 99694-0707:** !ping

[19:18] **+55 27 99694-0707:** ⏱️ Tempo de resposta: 11ms

[19:18] **+55 27 99694-0707:** porra bot toma no seu cagador 11ms

[19:18] **+55 27 99694-0707:** ⏱️ Tempo de resposta: 10ms

[19:18] **+55 27 99694-0707:** !ping

[19:18] **+55 27 99694-0707:** ai melhorou fdp

[19:19] **+55 27 99694-0707:** rapa to fazendo o ghostinho vai ser 1 pessoa digital que vai conversar com voces e tirar duvida

[19:28] **Jk Cli:** _Mensagem apagada_

[19:28] **Jk Cli:** [Imagem]

[19:28] **+55 27 99694-0707:** !ping

[19:28] **+55 27 99694-0707:** ⏱️ Tempo de resposta: 8ms

[19:29] **+55 27 99694-0707:**
> _Jk Cli: Imagem_
bonito seu pc

[19:29] **+55 27 99694-0707:** mostra mais a cpu

[19:29] **+55 27 99694-0707:** lindo ele

[19:29] **+55 27 99694-0707:** qual vga dele?

[19:29] **Jk Cli:** [Imagem]

[19:30] **+55 62 9444-5039:** Ghoscli podia trazer umas IAS de video 😭

[19:30] **Jk Cli:** e trampo eim

[19:30] **Jk Cli:** kkkk

[19:30] **+55 27 99694-0707:** _Mensagem apagada_

[19:30] **+55 27 99694-0707:** _Mensagem apagada_

[19:30] **+55 27 99694-0707:** _Mensagem apagada_

[19:30] **Jk Cli:** aasdkajdas

[19:30] **Jk Cli:** oia o cara

[19:30] **+55 27 99694-0707:** _Mensagem apagada_

[19:30] **+55 27 99694-0707:** _Mensagem apagada_

[19:30] **+55 27 99694-0707:** _Mensagem apagada_

[19:31] **+55 27 99694-0707:**
> _Jk Cli: Imagem_
top demais mano

[19:31] **+55 62 9444-5039:**
> _Jk Cli: e trampo eim_
[Figurinha]

[19:33] **+55 21 98102-9583:**
> _+55 27 99694-0707: astra?_
Pelo que meu mentor de IA comentou e eu entendi é o “fable da openai”, mas tão dizendo que é melhor

[19:34] **+55 21 98102-9583:** Se eu falei besteira me corrijam, por favor 😂

[19:35] **+55 27 99694-0707:**
> _+55 21 98102-9583: Pelo que meu mentor de IA comentou e eu entendi é o “fable da openai”, mas tão dizendo que é melhor_
o astra e fodidasso

[19:35] **+55 27 99694-0707:** curti man

[19:36] **+55 21 98102-9583:**
> _+55 27 99694-0707: o astra e fodidasso_
Melhor que o fable?

[19:42] **Jk Cli:** acho  q n

[19:45] **+55 27 99694-0707:**
> _+55 21 98102-9583: Melhor que o fable?_
Man sempre vai existir concorrência e o que a empresa é melhor, por exemplo o códex é especialista em complexidade de backend, ghost tarefas extremamente longas e complexa também, Claude tem tempo que não uso não sei dizer, o astra não usei ainda, mas pode ter certeza que a Claude vai lança algo fuderoso

[19:53] **+55 51 9425-4975:** [Imagem] Boa noite, a funcionalidade de comprar mais 1 ip não esta funcionando, url: https://ghostcli.dev/checkout?item=ip

[19:53] **+55 27 99694-0707:**
> _+55 51 9425-4975: Imagem: Boa noite, a funcionalidade de comprar mais 1 ip não esta funcionando, url: https://ghostcli.dev/checkout?item=ip_
@Jk Cli

[19:53] **Jk Cli:**
> _+55 51 9425-4975: Imagem: Boa noite, a funcionalidade de comprar mais 1 ip não esta funcionando, url: https://ghostcli.dev/checkout?item=ip_
vamo ver isso agr

[19:54] **+55 27 99694-0707:**
> _+55 51 9425-4975: Imagem: Boa noite, a funcionalidade de comprar mais 1 ip não esta funcionando, url: https://ghostcli.dev/checkout?item=ip_
Em manutenção dr

[19:54] **+55 27 99694-0707:** Já já tá on

[19:54] **+55 27 99694-0707:** Ghost tá como modo turbo

[19:54] **+55 27 99694-0707:** [Figurinha]

[19:54] **+55 27 99694-0707:** [Figurinha]

[19:57] **+55 27 99694-0707:**
> _+55 21 98102-9583: Melhor que o fable?_
[Imagem] Tá achando q tio Cláudio tá devagar

[19:57] **+55 27 99694-0707:** Já lanço mofi

[19:58] **+55 27 99694-0707:** Fable5.1

[19:58] **+55 27 99694-0707:** O mesmo daqui

[19:58] **+55 27 99694-0707:** To meio desinformado da Claude tem muito tempo que não tenho conta Claude

[19:58] **+55 27 99694-0707:** Só uso api

[19:59] **+55 27 99694-0707:** Bom demais ilimitado tnc

[20:00] **+55 47 9618-4437:** Manutencao temporaria.

[20:00] __[Notificação do sistema]__

[20:24] **+55 51 9425-4975:** Tem previsão pra voltar?

[20:45] **+55 54 9658-5317:** Rapaz, eu tô
É querendo o chatgpt ilimitado

[20:45] **+55 54 9658-5317:** Tá dando um baile no claude

[20:46] **+55 11 98099-6397:**
> _+55 54 9658-5317: Tá dando um baile no claude_
Já lançou?

[20:46] **+55 11 98099-6397:** Tô ansioso pra testar

[20:46] **+55 54 9658-5317:** [Mensagem de voz]

[20:58] **+55 34 9729-4956:** _Mensagem apagada_

[21:05] **+55 27 99694-0707:**
> _+55 54 9658-5317: Tá dando um baile no claude_
[Mensagem de voz]

[21:05] **+55 27 99694-0707:** [Mensagem de voz]

[21:10] **+55 54 9658-5317:**
> _+55 27 99694-0707: Mensagem de voz_
Não tô falando do ghost n mano kkk

[21:11] **+55 54 9658-5317:** Tô falando do claude e do chatgpt 
Olha a mensagem ali encima 
Que eu dei que podia ter um chatgpt ilimitado igual vocês fizeram o claude

[21:23] **+55 27 99694-0707:**
> _+55 54 9658-5317: Tô falando do claude e do chatgpt 
Olha a mensagem ali encima 
Que eu dei que podia ter um chatgpt ilimitado igual vocês fizeram o claude_
entendi

[21:23] **+55 27 99694-0707:** tudo e possivel

[21:35] **+55 21 98102-9583:**
> _+55 27 99694-0707: Man sempre vai existir concorrência e o que a empresa é melhor, por exemplo o códex é especialista em complexidade de backend, ghost tarefas extremamente longas e complexa também, Claude tem tempo que não uso não sei dizer, o astra não usei ainda, mas pode ter certeza que a Claude vai lança algo fuderoso_
Essa competição que salva a gente, viu 😂

[21:36] **+55 21 98102-9583:**
> _+55 54 9658-5317: Mensagem de voz_
Qual?

[21:36] **+55 27 99694-0707:**
> _+55 21 98102-9583: Essa competição que salva a gente, viu 😂_
sim

[21:37] **+55 27 99694-0707:**
> _+55 54 9658-5317: Mensagem de voz_
mas em questao a imagem o gpt e melhor dvdd

[21:37] **+55 27 99694-0707:** vdd*

[21:38] **+55 11 97826-1508:** Pra codar esse novo ta melhor q o claudin?

[21:38] **+55 27 99694-0707:**
> _+55 11 97826-1508: Pra codar esse novo ta melhor q o claudin?_
qual

[21:38] **+55 11 97826-1508:** Esse novo gpt q lançou

[21:39] **+55 27 99694-0707:** man, depende do que voce quer fazer

[21:39] **+55 27 99694-0707:** igual claude e muito bom em tools

[21:39] **+55 27 99694-0707:** gpt complexidade

[21:39] **+55 27 99694-0707:** ta lgdo

[21:39] **+55 27 99694-0707:** em quisito complexidade gpt sai disparado na frente ne

[21:40] **+55 27 99694-0707:** longo tempo de programacao estruturas gigantes e complexas ghost

[21:40] **+55 27 99694-0707:** auditoria rigorosa e melhorias gpt, voa os tokens

[21:41] **+55 27 99694-0707:** to passando a visao pra voces e como eu trabalho aki meus amigo, transparencia total

[21:41] **+55 54 9658-5317:**
> _+55 27 99694-0707: auditoria rigorosa e melhorias gpt, voa os tokens_
Tem isso.

[21:41] **+55 54 9658-5317:** Ele vai os tokens rápido

[21:41] **+55 27 99694-0707:**
> _+55 54 9658-5317: Ele vai os tokens rápido_
muito

[21:41] **+55 54 9658-5317:** Mais se for bater de cara a cara com o claude 
Ele ainda fica mais barato

[21:41] **+55 27 99694-0707:** tenho 24 contas de gpt e uma auditoria longa come todas as 24

[21:42] **+55 11 97826-1508:**
> _+55 27 99694-0707: longo tempo de programacao estruturas gigantes e complexas ghost_
O meu é mais isso, sempre achei que o Claude era o melhor valeuson, ainda nao testei o codex

[21:43] **+55 27 99694-0707:** ai que qui acontece eu criei a audit-compact, faco uma pre-auditoria no ghost, pego a auditoria compactada, para, o gpt auditar o compactado, gastou metade das contas

[21:43] **+55 27 99694-0707:**
> _+55 11 97826-1508: O meu é mais isso, sempre achei que o Claude era o melhor valeuson, ainda nao testei o codex_
usa o codex que voce vai entender o q to falando

[21:43] **+55 27 99694-0707:** uso diariamente

[22:34] **@fortytwowill:** Testem o "Oh my pi" www.omp.sh e depois pode agradecer 😅

[23:14] **+55 51 9425-4975:**
> _+55 27 99694-0707: em quisito complexidade gpt sai disparado na frente ne_
Poise, peguei pra testar o fable, ele ta se peidando todo em umas atividades, fiquei bem decepcionado

[23:21] **+55 48 9101-5225:**
> _+55 51 9425-4975: Poise, peguei pra testar o fable, ele ta se peidando todo em umas atividades, fiquei bem decepcionado_
Igualmente

[23:21] **+55 83 8798-9954:**
> _+55 51 9425-4975: Poise, peguei pra testar o fable, ele ta se peidando todo em umas atividades, fiquei bem decepcionado_
Tbm

[23:31] **Jk Cli:**
> _+55 51 9425-4975: Poise, peguei pra testar o fable, ele ta se peidando todo em umas atividades, fiquei bem decepcionado_
Questão da própria Anthropic mas acredito que eles vão melhorar mais ainda

[23:31] **Jk Cli:** Questão da interferência do gov pesou um pouco em cima deles

[23:31] **+55 27 99694-0707:**
> _+55 51 9425-4975: Poise, peguei pra testar o fable, ele ta se peidando todo em umas atividades, fiquei bem decepcionado_
quais por exemplo

[23:38] **+55 51 9425-4975:** Algumas atividades de dev mesmo, com lógicas um pouco mais complexas, eu digo pq eu montei um harness com open code que tranquilamente da o mesmo resultado com modelos muito mais baratos, tipo deepseek

[23:39] **+55 51 9425-4975:** Questão só foi ver o pessoal falando como se o fable fosse outro nível, só fui com mt expectativa

[23:39] **+55 27 99694-0707:**
> _+55 51 9425-4975: Algumas atividades de dev mesmo, com lógicas um pouco mais complexas, eu digo pq eu montei um harness com open code que tranquilamente da o mesmo resultado com modelos muito mais baratos, tipo deepseek_
ainda nao entendi o que voce fez amigo

[23:39] **+55 27 99694-0707:** e muito relativo

[23:39] **+55 27 99694-0707:** contexto

[23:39] **+55 27 99694-0707:** prompt

[23:39] **+55 27 99694-0707:** prompt bem montado

[23:40] **+55 27 99694-0707:** sao muitas variaveis

[23:51] **+55 51 9425-4975:** [Mensagem de voz]

[23:52] **+55 51 9425-4975:** [Mensagem de voz]

---

## 5 de setembro de 2026

[0:03] **+55 62 9243-4018:** [Mensagem de voz]

[0:15] **+55 27 99694-0707:**
> _+55 51 9425-4975: Mensagem de voz_
depende do que voce vai construir

[0:15] **+55 27 99694-0707:** ou pequenas e medias alteracoes

[2:04] **+55 62 9243-4018:** Alguém tem alguma extensão do Github para o claude desktop? (Igual tem na versão web?) Quero fazer alterações e já 'comitar' de forma automática.

[2:05] **+55 21 98102-9583:** [Imagem] manutenção, galera?

[2:05] **+55 11 94057-2122:**
> _+55 62 9243-4018: Alguém tem alguma extensão do Github para o claude desktop? (Igual tem na versão web?) Quero fazer alterações e já 'comitar' de forma automática._
Ué, é só passar esse contexto e conectar o repositório via terminal, não? 

Aqui toda alteração já vem com commit

[2:06] **+55 62 9243-4018:**
> _+55 21 98102-9583: Imagem: manutenção, galera?_
Acho que sim, aqui também caiu

[2:07] **+55 11 94057-2122:**
> _+55 62 9243-4018: Acho que sim, aqui também caiu_
Caiu aqui tbm

[2:07] **+55 62 9243-4018:**
> _+55 11 94057-2122: Ué, é só passar esse contexto e conectar o repositório via terminal, não? 

Aqui toda alteração já vem com commit_
Sim, faço isso e também tenho Github Desktop

[2:07] **+55 62 9243-4018:** [Mensagem de voz]

[2:08] **+55 62 9243-4018:**
> _+55 21 98102-9583: Imagem: manutenção, galera?_
API Error: 502 Bad Gateway. This is a server-side issue, usually temporary — try again in a moment. If it persists, check your inference gateway

[2:08] **+55 11 94057-2122:**
> _+55 62 9243-4018: API Error: 502 Bad Gateway. This is a server-side issue, usually temporary — try again in a moment. If it persists, check your inference gateway_
Aqui já voltou kkk

[2:08] **+55 11 94057-2122:** Só dar um retry aí que vai

[2:09] **+55 21 98102-9583:**
> _+55 11 94057-2122: Só dar um retry aí que vai_
mandei uns "continue" mas não foi não 🥲

[2:10] **+55 11 94057-2122:**
> _+55 21 98102-9583: mandei uns "continue" mas não foi não 🥲_
Eita, aqui já tá rodando no talo de novo

[2:10] **+55 11 94057-2122:** Parou nem 2 minutos

[2:10] **+55 47 9618-4437:** Manutenção concluida. @all

[2:10] __[Notificação do sistema]__

[2:13] **+55 62 9243-4018:**
> _+55 47 9618-4437: Manutenção concluida. @all_
Parabéns equipe 👏🏻👏🏻👏🏻

[6:27] **+55 51 9425-4975:** Tem usa o gateway com o open code?

[7:28] **+55 49 9977-0032:** Bom dia!

[7:28] **+55 49 9977-0032:** ✻ Connection dropped (ECONNRESET) ·

Só ra apresentando esse erro. Alguém pode ajudar?

[7:29] **+55 49 9977-0032:** aApi error

[7:29] **+55 47 9618-4437:**
> _+55 49 9977-0032: ✻ Connection dropped (ECONNRESET) ·

Só ra apresentando esse erro. Alguém pode ajudar?_
estamos atualizando algumas coisas no site

[7:48] **+55 49 9977-0032:** Tem previsão?

[8:21] **+55 32 8817-1150:** Eh eu to com badgateway aqui l…

[8:24] **+20 10 01449601:** https://ghostcli.dev/v1/messages
502 err

[8:36] **+55 77 8811-7500:** também

[8:57] **+55 47 9618-4437:** Resolvido

[8:58] **+55 77 8811-7500:** aqui voltou!

[10:15] **+55 87 8805-8510:** Pessoal como vocês fazem para criar diversos saas … tô perguntando isso pq toda vez que vou criar um sistema novo eu tenho que criar cadastros, financeiro, logins, permissões e isso acaba perdendo muito tempo … existe uma de eu ter tipo uma base dessa já predefinida e depois eu só criar os
Mudulos específicos para cada projeto ?

[10:44] **+55 35 9946-8945:**
> _+55 87 8805-8510: Pessoal como vocês fazem para criar diversos saas … tô perguntando isso pq toda vez que vou criar um sistema novo eu tenho que criar cadastros, financeiro, logins, permissões e isso acaba perdendo muito tempo … existe uma de eu ter tipo uma base dessa já predefinida e depois eu só criar os
Mudulos específicos para cada projeto ?_
Vc já deu a solução para seus problemas

[10:58] **@fortytwowill:**
> _+55 87 8805-8510: Pessoal como vocês fazem para criar diversos saas … tô perguntando isso pq toda vez que vou criar um sistema novo eu tenho que criar cadastros, financeiro, logins, permissões e isso acaba perdendo muito tempo … existe uma de eu ter tipo uma base dessa já predefinida e depois eu só criar os
Mudulos específicos para cada projeto ?_
Pra custo benefício e fácil escalabilidade, usa uma VPS. Você pode usar PostgreSQL pra database, coolify pra fazer o deploy, better auth pra autenticação de usuários, e outros opensources. E você não fica preso a vercel e supabase. Mais barato pra escalar.

[11:08] **Jk Cli:** Comunidade dev muito boa

[11:08] **Jk Cli:** 🙏🙏🙏

[11:10] **+55 47 9618-4437:** [Imagem]

[11:14] **+55 51 9425-4975:** O claudio ta toda hora parando, ai pra vcs tbm ta assim?

[11:15] **+55 81 9398-4490:** Alguém tem link de comunidade dev?

[11:19] **@fortytwowill:**
> _+55 51 9425-4975: O claudio ta toda hora parando, ai pra vcs tbm ta assim?_
aconteceu comigo ontem algumas vezes

[11:20] **+55 51 9425-4975:** Poise, quando eu peço para buscar alguma info de um link, ele fica caindo

[11:20] **Jk Cli:**
> _+55 47 9618-4437: Imagem_
❤️❤️❤️

[11:20] **@fortytwowill:** Acho que eles estão atualizando alguma coisa

[11:21] **@fortytwowill:**
> _+55 47 9618-4437: estamos atualizando algumas coisas no site_
👆

[11:40] **+55 17 99722-5777:** @~João não sei se vc é da equipe do ghost, mais vlw pelas dicas q vc me deu a 3 dias atrás. Com elas consegui fazer conectar meu programa, como sou amador foi difícil mais deu certo. Vlw

[15:09] **+55 47 9618-4437:** [Imagem]

[15:10] **Jk Cli:**
> _+55 47 9618-4437: Imagem_
Mimau

[15:23] __+974 6009 4444 entraram usando o link de convite__

[15:24] **+974 6009 4444:** How’s the ghostcli

[15:24] **+974 6009 4444:** Is it any good

[15:24] **+974 6009 4444:** What does it do

[15:30] **+94 71 272 0516:** Buy and see yourself

[15:31] __+56 9 9311 7437 entraram usando o link de convite__

[15:32] **Jk Cli:** Ghost cli the best bro

[15:32] **Jk Cli:** [Imagem]

[17:36] **+974 6009 4444:** Wallah ?

[17:36] **+974 6009 4444:** It’s good ?

[17:38] **Jk Cli:** Yeah bro

[20:29] **+55 27 99694-0707:** [Imagem] codex on ghost api

[20:37] **+55 62 8152-0359:** Estou com oferta roí de 15x drop Global!

Quem tiver contato da Digistore24h ou Gateway que aceita drop salva eu aí!!! 


Coloco de coprodução na oferta em forma de agradecimento!🙏

[20:42] **Jk Cli:** [Imagem]

[20:42] **Jk Cli:** Code by ghost

[21:23] **+55 27 99694-0707:**
> _+55 62 8152-0359: Estou com oferta roí de 15x drop Global!

Quem tiver contato da Digistore24h ou Gateway que aceita drop salva eu aí!!! 


Coloco de coprodução na oferta em forma de agradecimento!🙏_
nossa senhora do roi

[21:23] **+55 27 99694-0707:** 15 de roi

[21:23] **+55 27 99694-0707:** ja quero ser seu amigo

[22:08] **+55 91 8400-8615:** [Imagem] Alguém sabe como resolver? Ele roda por um tempo e logo depois cai

[22:32] **@fortytwowill:**
> _+55 91 8400-8615: Imagem: Alguém sabe como resolver? Ele roda por um tempo e logo depois cai_
Manda um resume

[22:32] **+55 27 99694-0707:**
> _+55 91 8400-8615: Imagem: Alguém sabe como resolver? Ele roda por um tempo e logo depois cai_
se ta usando o claude?

[22:52] **+55 11 94321-3342:** Preciso de bms de disparo quem tiver compro preciso de 150 bms

---

## 6 de setembro de 2026

[0:18] **+55 62 9444-5039:** Esse novo modelo do GPT ta insano, podia colocar ele 🥲

[0:45] **+55 27 99694-0707:**
> _+55 62 9444-5039: Esse novo modelo do GPT ta insano, podia colocar ele 🥲_
qual pai

[1:12] **+967 775 460 162:** _Mensagem apagada por um admin (Jk Cli)_

[1:13] **+55 62 9444-5039:**
> _+55 27 99694-0707: qual pai_
Astra

[1:18] **+55 21 98102-9583:**
> _+55 62 9444-5039: Astra_
A gente tava conversando outro dia no grupo sobre ele

[1:18] **+55 21 98102-9583:** Alguns dizem que está melhor que o fable. Nunca testei, confesso

[2:04] __+675 7021 9995 entraram usando o link de convite__

[2:05] __+61 404 967 983 entraram usando o link de convite__

[2:06] __Jk Cli removeu +967 775 460 162__

[2:08] **+55 62 9444-5039:**
> _+55 21 98102-9583: Alguns dizem que está melhor que o fable. Nunca testei, confesso_
Eu testei hoje, e ta muito melhor

[2:08] **+55 62 9444-5039:** Trabalho com 3d, e ele no blender ou gerando objeto em threejs

[2:08] **+55 62 9444-5039:** Tá muito bom

[2:12] **+55 21 98102-9583:** Mas sabe como ele tá em termos de raciocínio? Trabalho com perícia contábil, então o "discernimento" da IA é muito importante pra minha área. O Claude viaja muito, mas ainda é o mais eficiente e, com uma LLM interna, ajuda muito a treinar

[2:52] **+55 27 99694-0707:**
> _+55 21 98102-9583: Mas sabe como ele tá em termos de raciocínio? Trabalho com perícia contábil, então o "discernimento" da IA é muito importante pra minha área. O Claude viaja muito, mas ainda é o mais eficiente e, com uma LLM interna, ajuda muito a treinar_
boa

[2:52] **+55 27 99694-0707:** e de acordo com o prompt que voce envia

[2:53] **+55 27 99694-0707:** mais contexto do seu promtp melhor

[3:51] **+55 48 9101-5225:** Po no meu claude code, contexto ta travado em 200k independente do modelo

[3:51] **+55 48 9101-5225:** Qual cli ta rolando pra vcs ai com contexto de 1 milhao?

[4:09] **+57 304 3533218:**
> _+55 48 9101-5225: Po no meu claude code, contexto ta travado em 200k independente do modelo_
Você está falando do ghostcli?

[4:56] **+55 48 9101-5225:**
> _+57 304 3533218: Você está falando do ghostcli?_
Ghostcli é o nosso provedor no caso, no caso da pergunta me refiro a ferramentas de cli como " claude cli" "codex cli" "opencode cli" entre outras do mercado

[5:10] **+57 304 3533218:**
> _+55 48 9101-5225: Ghostcli é o nosso provedor no caso, no caso da pergunta me refiro a ferramentas de cli como " claude cli" "codex cli" "opencode cli" entre outras do mercado_
Você precisa configurar a janela de contexto, pelo menos é assim que funciona no Claude Code. Mas eu gostaria de saber se os modelos oferecidos no Ghostcli têm a janela de 1 milhão disponível?

[5:13] **+55 91 8400-8615:**
> _+57 304 3533218: Você precisa configurar a janela de contexto, pelo menos é assim que funciona no Claude Code. Mas eu gostaria de saber se os modelos oferecidos no Ghostcli têm a janela de 1 milhão disponível?_
Tem sim mn

[5:13] **+55 91 8400-8615:** [Imagem]

[5:16] **+57 304 3533218:**
> _+55 91 8400-8615: Imagem_
Existe um limite de taxa de transferência ou é completamente ilimitado?

[5:18] **+55 91 8400-8615:** É totalmente ilimitado mn, até agora não tive nenhuma limitação

[5:18] **+55 91 8400-8615:** Só para quando tem alguma manutenção, update no site etc

[5:19] **@ziadhatem:**
> _+55 91 8400-8615: Imagem_
how can i make ghostcli work inside claude desktop ?

[9:26] **@ziadhatem:** guys is ghostcli claude support native search from claude or no ?

[10:23] **+55 27 99694-0707:** bom dia

[11:18] **+55 91 8400-8615:**
> _@ziadhatem: how can i make ghostcli work inside claude desktop ?_
Lá no docs da ghostcli tem um passo a passo, aí se mesmo com o vídeo pode vir aqui mas o vídeo dá pra desenrolar

[13:11] **+57 304 3533218:** O plano Max inclui o GLM 5.3?

[13:28] **@fortytwowill:** [Mensagem de album]

[13:28] **@fortytwowill:** [Imagem] Muitos erros hj

[13:28] **@fortytwowill:** [Imagem]

[13:29] **@fortytwowill:** Muito tool call error

[13:30] **+55 27 99694-0707:**
> _@fortytwowill: [album]_
boa tarde amigo

[13:30] **+55 27 99694-0707:** aonde esta usando?

[13:30] **Jk Cli:**
> _+57 304 3533218: O plano Max inclui o GLM 5.3?_
Sim

[13:33] **@fortytwowill:** Oh my pi

[13:34] **@fortytwowill:**
> _+55 27 99694-0707: aonde esta usando?_
OMP

[13:35] **+55 27 99694-0707:**
> _@fortytwowill: OMP_
entendi amigo

[13:35] **+55 27 99694-0707:** pq voce ta usando omp?

[13:35] **+55 27 99694-0707:** sendo que tem melhores mil anos luz ?

[13:35] **Jk Cli:** [Imagem] Bora que afiliado já pingou o dele hj

[13:35] **+55 27 99694-0707:** por curiosidade

[13:35] **Jk Cli:**
> _Jk Cli: Imagem: Bora que afiliado já pingou o dele hj_
@all

[13:36] **+55 27 99694-0707:**
> _Jk Cli: Imagem: Bora que afiliado já pingou o dele hj_
ja pedi 100 emprestado a ele do espetin

[13:36] **+55 27 99694-0707:** to duro slk

[13:36] **Jk Cli:** [Imagem]

[13:40] **+57 304 3533218:**
> _Jk Cli: Sim_
Ilimitado também?

[13:41] **+55 27 99694-0707:**
> _+57 304 3533218: Ilimitado também?_
sim

[13:51] **@fortytwowill:**
> _+55 27 99694-0707: pq voce ta usando omp?_
Pq eu gosto uai.. tipo qual?

[13:52] **@fortytwowill:** Depende do que vc chama de melhor

[13:53] **@fortytwowill:** E qual a relação disso com os erros de tool calling ? 😅

[13:59] **Jk Cli:** [Imagem]

[14:00] **+55 99 8487-3868:**
> _Jk Cli: Imagem: Bora que afiliado já pingou o dele hj_
🚀🚀🚀
O da assinatura e dos meus IPS já recuperou!!

Bom demais

[14:00] **Jk Cli:** Eita top eim

[14:01] **+55 99 8487-3868:** Vocês são foda! que estrutura top 🥇

[14:01] **Jk Cli:** Muito obrigado ☺️

[14:01] **+57 304 3533218:** Alguém pode me explicar como funciona o sistema de indicações?

[14:02] **+55 99 8487-3868:**
> _+57 304 3533218: Alguém pode me explicar como funciona o sistema de indicações?_
Sim

[14:03] **+55 99 8487-3868:** você gera um link 🔗 no painel de afiliado.

cada pessoa que acessar teu link e realizar uma compra no site você ganha 25% ✓

[14:05] **+55 99 8487-3868:** Eu como não sou bobo e nem nada, sei do potencial e da dificuldade que é achar uma estrutura dessa...

Eu fiz o seguinte, ao invés de só entregar o meu Link de afiliado pra galera, eu estou VENDENDO O ACESSO AO FORNECEDOR!! 😅🚀

Ganho ilimitado, o cara paga para ter acesso e quando ele faz a compra no site ganho a comissão.

[14:06] **Jk Cli:** Kkkkkkkkk

[14:06] **Jk Cli:** Esperto

[14:06] **+57 304 3533218:**
> _+55 99 8487-3868: Eu como não sou bobo e nem nada, sei do potencial e da dificuldade que é achar uma estrutura dessa...

Eu fiz o seguinte, ao invés de só entregar o meu Link de afiliado pra galera, eu estou VENDENDO O ACESSO AO FORNECEDOR!! 😅🚀

Ganho ilimitado, o cara paga para ter acesso e quando ele faz a compra no site ganho a comissão._
Qual é o número máximo de planos que preciso vender para conseguir pagar o meu plano com as indicações?

[14:10] **Jk Cli:** No link da ghost

[14:10] **Jk Cli:** Tem tudo

[14:11] **+55 99 8487-3868:**
> _+57 304 3533218: Qual é o número máximo de planos que preciso vender para conseguir pagar o meu plano com as indicações?_
[Mensagem de voz]

[14:14] **+57 304 3533218:**
> _+55 99 8487-3868: Mensagem de voz_
Muito obrigada. Você sabe qual método de pagamento eles usam para comissões de indicação? Eu não estou no Brasil.

[14:14] **+55 47 9618-4437:**
> _+57 304 3533218: Muito obrigada. Você sabe qual método de pagamento eles usam para comissões de indicação? Eu não estou no Brasil._
Crypto ou PIX

[14:25] __+55 11 96473-3118 entraram usando o link de convite__

[14:44] **+55 11 96473-3118:** Boa tarde a todos, gostaria de uma informação,  fiquei interessado e gostaria de saber como funciona onde posso utilizar com vscode e se não tem nenhum tipo de bloqueio?? Desde já agradeço

[15:27] __+352 661 775 760 entraram usando o link de convite__

[15:59] **Você:** tem como deixar aceitar edições automatico ? tanto por consolle como por ids ?

[15:59] **Você:** n e igual opencode ne que no cmd coloca so --auto

[16:00] **+55 83 8798-9954:** so da shift + tab ate ficar em auto mode on

[16:00] **Você:** pdcre vlw

[16:22] **+55 77 9917-7747:** Fala pessoal

[16:22] **+55 77 9917-7747:** Alguem com contato de disparos em massa?

[16:23] **+55 77 9917-7747:** Tá um caos parece que as estruturas BM balão estão todas off

[16:37] **+1 (650) 485-3084:** O pagamento com cartão não funciona.

[18:45] **+351 910 130 122:** alguém aqui possui claude code max x20?

[19:12] **+55 62 9368-4568:**
> _+351 910 130 122: alguém aqui possui claude code max x20?_
[Figurinha]

[19:14] **+351 910 130 122:** já comparou lado a lado o ghostcli com o claude code max x20 usando o mesmo modelo e? (mesmo modelo e effort)

[19:14] **+55 27 99694-0707:**
> _+351 910 130 122: já comparou lado a lado o ghostcli com o claude code max x20 usando o mesmo modelo e? (mesmo modelo e effort)_
Depende do que você quer fazer é muito relativo

[19:15] **+351 910 130 122:** estou apenas a perguntar se ja comparou.  exemplo: o mesmo website e pedir a ambos que resolvam um problema ou façam uma alteração.

[19:15] **+55 11 98099-6397:**
> _+351 910 130 122: já comparou lado a lado o ghostcli com o claude code max x20 usando o mesmo modelo e? (mesmo modelo e effort)_
Top demais, trabalho quase o dia todo sem me preocupar com limite

[19:16] **+351 910 130 122:** O que está em questão aqui é a inteligencia do mesmo / capacidade de resolver problemas ou adicionar novas features. Limites já se sabe que um é limitado e outro não.

[19:16] **+55 27 99694-0707:**
> _+351 910 130 122: estou apenas a perguntar se ja comparou.  exemplo: o mesmo website e pedir a ambos que resolvam um problema ou façam uma alteração._
a ghost em designe ta 1 cacete na claude sem duvidas

[19:17] **+55 27 99694-0707:** complexidade

[19:17] **+55 27 99694-0707:** tempo programando

[19:17] **+55 27 99694-0707:** e como te disse depende do que vai fazer

[19:17] **+55 27 99694-0707:** e muito relativo

[19:17] **+55 11 98099-6397:**
> _+351 910 130 122: O que está em questão aqui é a inteligencia do mesmo / capacidade de resolver problemas ou adicionar novas features. Limites já se sabe que um é limitado e outro não._
Tudo que eu quis eu consegui fazer, fiz uma plataforma completa de trackeamrnto e ele conseguiu lidar com tudo sem eu fazer nada.

[19:17] **+55 11 98099-6397:**
> _+55 27 99694-0707: a ghost em designe ta 1 cacete na claude sem duvidas_
Sim, sem duvidas

[19:17] **+55 27 99694-0707:** depende de como voce envia o prompt

[19:17] **+55 27 99694-0707:** exemplo

[19:17] **+55 11 98099-6397:** Ainda mais por não se preocupar com esses limites chatos do claude

[19:18] **+55 27 99694-0707:** eu faco prompt no gpt 6 e a ghost fais o resto do show

[19:18] **+55 11 98099-6397:**
> _+55 27 99694-0707: depende de como voce envia o prompt_
Sim, explicando melhor sempre vai ser melhor o resultado

[19:18] **+55 27 99694-0707:** o prompt fica muitoooooooooo avancado

[19:20] **+351 910 130 122:** mano, eu tenho comparado e o claude code max x20 opus 5 (max) com o ghost fable 5.1 (ultracode). O claude está rebentando completamente (embora esteja a usar um modelo inferior). Faz tudo de primeira. já o ghost só está fazendo asneira e nem sempre resolve o problema em varias tentativas.  daí a minha duvida se alguem já os testou realmente lado a lado. Provavelmente nnguém aqui o fez.

[19:20] **+55 27 99694-0707:** [Imagem] to terminando o ghostcord com ghost, como muitos sabem, a janja bloqueou o compartilhamento de tela do discord, to fazendo nosso discord da ghost

[19:21] **+55 27 99694-0707:**
> _+351 910 130 122: mano, eu tenho comparado e o claude code max x20 opus 5 (max) com o ghost fable 5.1 (ultracode). O claude está rebentando completamente (embora esteja a usar um modelo inferior). Faz tudo de primeira. já o ghost só está fazendo asneira e nem sempre resolve o problema em varias tentativas.  daí a minha duvida se alguem já os testou realmente lado a lado. Provavelmente nnguém aqui o fez._
depende da onde se ta usando api

[19:21] **+55 27 99694-0707:** exemplo, api e 1 canhao no codex

[19:27] **+55 87 9128-0580:**
> _+351 910 130 122: mano, eu tenho comparado e o claude code max x20 opus 5 (max) com o ghost fable 5.1 (ultracode). O claude está rebentando completamente (embora esteja a usar um modelo inferior). Faz tudo de primeira. já o ghost só está fazendo asneira e nem sempre resolve o problema em varias tentativas.  daí a minha duvida se alguem já os testou realmente lado a lado. Provavelmente nnguém aqui o fez._
Cara aqui na operação ele tá fazendo tudo certinho sem problemas. Utilizando vários agentes ao mesmo tempo com orquestrador e tudo mais e ainda não tive problema.

[19:29] **+55 27 99694-0707:** vou postar o teste de benchmark de agente da api que fiz ontem

[19:29] **+55 27 99694-0707:** chamei 25 agentes de uma vez

[19:29] **+55 27 99694-0707:** e resolveu tudo

[19:29] **+351 910 130 122:**
> _+55 87 9128-0580: Cara aqui na operação ele tá fazendo tudo certinho sem problemas. Utilizando vários agentes ao mesmo tempo com orquestrador e tudo mais e ainda não tive problema._
eu nao disse que o meu nao esta fazendo tudo.  eu perguntei se alguem já comparou lado a lado.  Porque fazer tudo, quase todas as AIs conhecidas fazem. Agora se o fazem de forma melhor ou pior, mais profissinal ou menos profissional, essa é a verdadeira questão.

[19:30] **+351 910 130 122:** se ninguém aqui comparou lado a lado, não pode de todo dizer se realmente entrega os resultados do claude code max da anthropic.  por isso é que eu gostaria de saber se mais pessoas fizeram o que eu fiz.

[19:30] **+55 27 99694-0707:**
> _+351 910 130 122: eu nao disse que o meu nao esta fazendo tudo.  eu perguntei se alguem já comparou lado a lado.  Porque fazer tudo, quase todas as AIs conhecidas fazem. Agora se o fazem de forma melhor ou pior, mais profissinal ou menos profissional, essa é a verdadeira questão._
ja disse depende do seu uso

[19:30] **+55 27 99694-0707:** como comparar 1 raciocinio

[19:32] **+55 87 9128-0580:** Não existe ia fazer menos ou mais profissional. 

Existe má orquestração!

Eu aqui trabalho com duas verificações sempre depois de terminar!

Ex:


Faça a config X e Y

(Fez)

Verifique o que foi feito

(Verificou)

Pode commitar

[19:32] **+55 87 9128-0580:** É assim que uso e nunca tive problema

[19:32] **+55 87 9128-0580:** Agora se você só sai pedindo de qualquer jeito sem um plano de arquitetura

[19:32] **+55 87 9128-0580:** A ia vai fazer de todo jeito mesmo

[19:32] **+55 87 9128-0580:** Qualquer uma

[19:34] **+55 27 99694-0707:** sabe a forma mais profissional de lhe dar com a ia?

[19:34] **+55 27 99694-0707:** o codex todo final de tarefa ele lanca 1 auto-revisor

[19:34] **+55 27 99694-0707:** o AR ele decidi se vai continuar codando ou nao

[19:35] **+55 27 99694-0707:** e eu sempre mando a i.a revisar

[19:35] **+55 27 99694-0707:** revisar existe 1000 formas de revisar

[19:35] **+55 27 99694-0707:** nao revisa simples

[19:35] **+55 27 99694-0707:** existe 1000 sentidos para revisar 1 codigo

[19:35] **+55 27 99694-0707:** se voce tem 1 codigo de 10mil linhas, vai toma no cu, modulariza para ficar rapido a revisao

[19:36] **+55 27 99694-0707:** entao como disse depende de como voce coda

[19:38] **+55 87 9128-0580:** [Mensagem de voz]

[19:40] **+55 87 9128-0580:** [Mensagem de voz]

[19:41] **+55 27 99694-0707:** nossa senhora do audio amigo, deixa eu sair do servico eu ouco os audio

[19:42] **+55 87 9128-0580:**
> _+55 27 99694-0707: nossa senhora do audio amigo, deixa eu sair do servico eu ouco os audio_
Ksksksksk em resumo eu falei que eu não falo para a IA revisar o código completo eu falo pra ela revisar e testar função por função.

[19:42] **+55 87 9128-0580:** Uma a uma

[19:42] **+55 87 9128-0580:** Demora

[19:42] **+55 87 9128-0580:** Mas não tem alucinações

[19:42] **+55 87 9128-0580:** E sempre se começa uma ferramenta pelo banco de dados

[19:43] **+351 910 130 122:** No meu caso nao estou fazendo nada. ja tenho tudo feito e propositalmente entreguei para ghost e para claude e enviei o mesmo prompt para resolver um determinado problema.  Outro caso por exemplo, tenho 2 websites, e quero colocar algumas features do website 1 no website 2. enviei para o ghost e para o claude com o mesmo prompt, o ghost nao passou nem 10% das features, o claude passou todas as features que pedi.  é nesse sentido que me refiro que notei bastantes diferenças.  nem sequer estou a trabalhar com codigo complexo, são apenas simples websites (php).  propositalmente para testar o desempenho / inteligencia dos dois em paralelo.

[19:43] **+55 87 9128-0580:** Testando cada GET, POST e utilizando o docker

[19:44] __+55 47 9618-4437 removeu +351 910 130 122__

[19:44] **+55 47 9618-4437:** bani logo

[19:44] **+55 47 9618-4437:** gringo chaaatodo diabo

[19:44] **+55 47 9618-4437:** sabe nem usar uma ia

[19:45] **+55 27 99694-0707:**
> _+351 910 130 122: No meu caso nao estou fazendo nada. ja tenho tudo feito e propositalmente entreguei para ghost e para claude e enviei o mesmo prompt para resolver um determinado problema.  Outro caso por exemplo, tenho 2 websites, e quero colocar algumas features do website 1 no website 2. enviei para o ghost e para o claude com o mesmo prompt, o ghost nao passou nem 10% das features, o claude passou todas as features que pedi.  é nesse sentido que me refiro que notei bastantes diferenças.  nem sequer estou a trabalhar com codigo complexo, são apenas simples websites (php).  propositalmente para testar o desempenho / inteligencia dos dois em paralelo._
cara duente kkkkk, literalemnte nao tem o que fazer

[19:45] **+55 27 99694-0707:** deve ser Vibe Code

[19:45] **+55 27 99694-0707:** raiiii prala vibe code do djhabo

[19:52] **+55 11 97826-1508:**
> _+55 87 9128-0580: Uma a uma_
Boa tbm faço isso, mas me irrita quando já mandei fazer isso 4 vezes em tudo e ainda acha bug kksksk

[19:55] **+55 87 9128-0580:**
> _+55 11 97826-1508: Boa tbm faço isso, mas me irrita quando já mandei fazer isso 4 vezes em tudo e ainda acha bug kksksk_
[Mensagem de voz]

[19:55] **+55 87 9128-0580:** [Mensagem de voz]

[19:56] **+55 87 9128-0580:** [Mensagem de voz]

[20:00] **Jk Cli:**
> _+55 47 9618-4437: gringo chaaatodo diabo_
Vibe code o cara

[20:01] **Jk Cli:** Nível máximo

[20:01] **Jk Cli:** Kkkk

[20:01] **Jk Cli:** Ele n aguento n

[20:01] **Jk Cli:** Kkkkkk

[20:01] **Jk Cli:** 🤣🤣🤣🤣

[20:04] **+55 27 99694-0707:** o cara ta tao perdido na vida que nao sabe nem programar, comparando i.a colocando a ia para conduzir ele para programar, nao e i.a que conduz o programador, e o programador que conduz a i.a rapasiada

[20:07] **+55 27 99694-0707:** voce manda na sua mulher, ou sua mulher manda em voce ?

[20:07] **+55 27 99694-0707:** tipo isso rapa

[20:07] **+55 27 99694-0707:** polemica

[20:13] **+55 11 97826-1508:** KKKKKKK

[20:13] **+55 61 9842-2891:**
> _+55 27 99694-0707: voce manda na sua mulher, ou sua mulher manda em voce ?_
A mulher manda

[20:13] **+55 61 9842-2891:** Quem falar que nao

[20:13] **+55 61 9842-2891:** É mentiroso ou corno

[20:13] **+55 61 9842-2891:** 🤣🤣

[20:13] **+55 11 97826-1508:** Sim se vc souber vários conceitos e principalmente prompt bom até ia bucha faz muita coisa, mas realmente tem os benchmarks dos modelos ne, o quanto que modelo X bate de score em raciocínio rapidez etc comparado a modelo Y

[20:15] **+55 27 99694-0707:** kkkkkkk

[20:20] **+595 981 144534:** Che, si alguno anda metido con el tema de plugins para Rust, prueben GhostCLI. Yo lo vengo usando a pleno y posta que te salva la vida. Te simplifica toda la parte pesada de la configuración, te arma la estructura al toque y te frena mil dolores de cabeza. Para desarrollo en Rust para mí es de lo mejor que hay hoy por hoy, recomendado. OS MELHORES 🤩

[20:29] **+55 27 99694-0707:**
> _+595 981 144534: Che, si alguno anda metido con el tema de plugins para Rust, prueben GhostCLI. Yo lo vengo usando a pleno y posta que te salva la vida. Te simplifica toda la parte pesada de la configuración, te arma la estructura al toque y te frena mil dolores de cabeza. Para desarrollo en Rust para mí es de lo mejor que hay hoy por hoy, recomendado. OS MELHORES 🤩_
voce e da bolivia?

[20:29] **+55 27 99694-0707:** _Mensagem apagada_

[20:30] **+55 27 99694-0707:**
> _+595 981 144534: Che, si alguno anda metido con el tema de plugins para Rust, prueben GhostCLI. Yo lo vengo usando a pleno y posta que te salva la vida. Te simplifica toda la parte pesada de la configuración, te arma la estructura al toque y te frena mil dolores de cabeza. Para desarrollo en Rust para mí es de lo mejor que hay hoy por hoy, recomendado. OS MELHORES 🤩_
verdade

[20:47] **+55 27 99694-0707:** botei a ia na pica agora kkkkk
PostgreSQL para SQLite

[20:47] **+55 27 99694-0707:** polemica on kkkkk

[20:47] **+55 27 99694-0707:** amosqlite e fo*-*

[20:48] **+57 304 3533218:** Ele estava insinuando que os modelos não são iguais?

[20:48] **+55 27 99694-0707:** igual o caba namora a feinha e ninguem entende kkk

[20:49] **+55 27 99694-0707:**
> _+57 304 3533218: Ele estava insinuando que os modelos não são iguais?_
nao

[20:49] **+55 27 99694-0707:** ele nao sabe programar

[20:54] **+57 304 3533218:** Ele provavelmente é novo na comunidade.

[20:54] **+55 27 99694-0707:**
> _+57 304 3533218: Ele provavelmente é novo na comunidade._
comunidade? como vossa senhoria esta sendo gente boa, ele deve ter ganhado 1 pc hoje!

[21:10] **@fortytwowill:**
> _+55 27 99694-0707: Imagem: to terminando o ghostcord com ghost, como muitos sabem, a janja bloqueou o compartilhamento de tela do discord, to fazendo nosso discord da ghost_
Usa telegram

[21:17] **+55 35 9946-8945:** Pessoal como vcs tem usado Codex? Plugins skills

[21:17] **+55 27 99694-0707:**
> _+55 35 9946-8945: Pessoal como vcs tem usado Codex? Plugins skills_
sempre

[21:18] **+55 27 99694-0707:** skill do codex e 300x mais avancado que no claude

[21:18] **+55 27 99694-0707:** para programacao pesada ne

[21:18] **+55 35 9946-8945:** Consegue me dar uma aula?

[21:18] **+55 27 99694-0707:**
> _+55 35 9946-8945: Consegue me dar uma aula?_
eu dar pra voce

[21:18] **+55 27 99694-0707:** aula

[21:18] **+55 27 99694-0707:** rapais

[21:18] **+55 27 99694-0707:** depende do que voce faz

[21:18] **+55 35 9946-8945:** Tô fazendo uns saas

[21:19] **+55 35 9946-8945:** Sou Dev back raiz

[21:19] **+55 35 9946-8945:** E front não pode ser tudo igual

[21:19] **+55 27 99694-0707:** entendi

[21:19] **+55 27 99694-0707:** skill e para voce economizar tempo, a propria ia faz skill e instala

[21:20] **+55 27 99694-0707:** aki economizo muito tempo com skill

[21:20] **+55 27 99694-0707:** mas skill e 1 campo gigantemente aberto

[21:20] **+55 27 99694-0707:** tem skill de tudo man, slk e assustador

[21:21] **+55 27 99694-0707:** igual na claude, skill da claude sao prompts parrudissimos

[21:21] **+55 27 99694-0707:** vo jogar uns aki pra voces verem

[21:21] **+55 27 99694-0707:** no codex nao, sao projetos estruturados as skills do codex e surreal

[21:22] **+55 11 97826-1508:**
> _+55 35 9946-8945: E front não pode ser tudo igual_
Tem skill pra UI nao ficar aquele padrão ia q todo mundo faz igual

[21:23] **+55 27 99694-0707:** ano que vem vo lanca 1 skill chamada Ultra-Skill e 1 tipo de skill mais avancada, pra usar no abracadabra

[21:24] **+55 35 9946-8945:** Agradeço demais

[21:24] **+55 35 9946-8945:** Codei MT tempo na mão tô aprendendo ainda

[21:26] **+55 27 99694-0707:** [Imagem] minha skill que puxa o quota

[21:26] **+55 27 99694-0707:** ai eu sou autista ne

[21:26] **+55 27 99694-0707:** ai o que fiz olhem a feiticaria que eu fiz com essa skill

[21:26] **+55 27 99694-0707:** kkkkkk

[21:27] **+55 11 97826-1508:** https://github.com/affaan-m/ECC

[21:27] **+55 27 99694-0707:** quando chega 3% o quota a propria skill chama o endpoint que chaveia a conta para outra conta

[21:27] **+55 11 97826-1508:**
> _+55 11 97826-1508: https://github.com/affaan-m/ECC_
Repo com uma porrada de skills pro claudo de um cara q ganhou um hackaton

[21:29] **+55 47 9618-4437:**
> _+55 11 97826-1508: https://github.com/affaan-m/ECC_
Eu vi isso

[21:29] **+55 47 9618-4437:** Tá em primeiro no Github

[21:29] **+55 27 99694-0707:**
> _+55 11 97826-1508: https://github.com/affaan-m/ECC_
q isso pai

[21:30] **+55 11 97826-1508:**
> _+55 11 97826-1508: Repo com uma porrada de skills pro claudo de um cara q ganhou um hackaton_
Isso

[21:32] **+55 27 99694-0707:**
> _+55 11 97826-1508: Repo com uma porrada de skills pro claudo de um cara q ganhou um hackaton_
garai pode cre

[21:39] **+595 981 144534:**
> _+55 27 99694-0707: voce e da bolivia?_
Para de faltar  merda ai

[21:39] **+595 981 144534:** Carentao

[21:40] **+55 27 99694-0707:**
> _+595 981 144534: Para de faltar  merda ai_
ta com siume pega na mao e assume

[21:41] **+55 27 99694-0707:**
> _+595 981 144534: Carentao_
o mijador dele e maior que o seu ctz

[21:43] **+595 981 144534:** Muita fome ne

[21:43] **+55 47 9618-4437:**
> _+55 27 99694-0707: o mijador dele e maior que o seu ctz_
Eieieiei calma ai

[21:43] **+55 27 99694-0707:**
> _+595 981 144534: Muita fome ne_
avemaria nem fala

[21:43] **+55 47 9618-4437:** É da equipe

[21:43] **+55 27 99694-0707:**
> _+55 47 9618-4437: É da equipe_
me perdi

[21:44] **+55 27 99694-0707:**
> _+595 981 144534: Muita fome ne_
sair daqui vo cumer 4 espetin

[21:44] **+55 27 99694-0707:** slk fome da misera

[21:47] **+55 27 99694-0707:** _Mensagem apagada_

[21:47] **+55 27 99694-0707:** _Mensagem apagada_

[21:53] **Jk Cli:** Chapou

[21:53] **Jk Cli:** Kkkkkk

[22:02] **+55 27 99694-0707:** [Figurinha]

[22:02] **+55 27 99694-0707:** [Figurinha]

[23:08] __+55 54 9620-1797 entraram usando o link de convite__

---

## 7 de setembro de 2026

[11:22] **+55 22 98111-9467:** Bom dia pessoal, tudo bem?
Me tirem uma dúvida por favor.
Eu liberei um IP pra minha chave, mas se por acaso eu conectar meu notebook em outra rede, eu posso excluir o IP liberado e conectar o outro sem precisar gerar novamente chave? E depois quando voltar pra minha rede normal, voltar para o IP normal?

[11:22] **+55 81 9575-5362:** Sim

[11:22] **+55 81 9575-5362:** [Figurinha]

[11:22] **+55 81 9575-5362:** Só excluir o IP e configurar o novo

[11:24] **+55 81 9575-5362:** Inclusive mesmo sendo simples  fico com preguiça de estar trocando, usei minha key do ghostcli pra construir um script em Python usando playwright via http request pra fazer isso por mim

[11:24] **+55 81 9575-5362:** Kkkkkkkk

[11:25] **+55 22 98111-9467:**
> _+55 81 9575-5362: Inclusive mesmo sendo simples  fico com preguiça de estar trocando, usei minha key do ghostcli pra construir um script em Python usando playwright via http request pra fazer isso por mim_
Ainda não tenho essa habilidade, senão faria tbm kkk

[11:25] **+55 22 98111-9467:** Obrigado

[11:26] **+55 87 9978-4968:** bom dia, conexao ta off? nao to conseguindo conectar aqui no claude

[11:26] **+55 27 99694-0707:**
> _+55 22 98111-9467: Bom dia pessoal, tudo bem?
Me tirem uma dúvida por favor.
Eu liberei um IP pra minha chave, mas se por acaso eu conectar meu notebook em outra rede, eu posso excluir o IP liberado e conectar o outro sem precisar gerar novamente chave? E depois quando voltar pra minha rede normal, voltar para o IP normal?_
MONTA UMA VPN COM WIRE AI FICA O MESMO IP

[11:26] **+55 87 9978-4968:** [Imagem] nao acha os modelos

[11:27] **+55 81 9575-5362:**
> _+55 27 99694-0707: MONTA UMA VPN COM WIRE AI FICA O MESMO IP_
Serve também

[11:27] **Você:**
> _+55 87 9978-4968: bom dia, conexao ta off? nao to conseguindo conectar aqui no claude_
[Imagem] aq ta de bpa

[11:27] **+55 81 9575-5362:**
> _+55 87 9978-4968: Imagem: nao acha os modelos_
Num é esse /v1 teu duplicado não?

[11:28] **+55 87 9978-4968:** _Mensagem apagada_

[11:28] **+55 27 99694-0707:** RAPA

[11:29] **+55 27 99694-0707:** SETA O GLM

[11:29] **+55 87 9978-4968:**
> _+55 87 9978-4968: Imagem_
foi nao

[11:29] **+55 27 99694-0707:** ELE TA ON

[11:29] **+55 81 9575-5362:**
> _+55 87 9978-4968: foi nao_
Tira esse v1 e testa, se ele tá lendo como open aí compatível, ele deve preencher esse v1 sozinho (acho)

[11:33] **+356 7737 9669:** Do you guys also facing  connection  problems?

[11:37] **+55 51 9425-4975:**
> _Você: Imagem: aq ta de bpa_
Que estrutura é essa?

[11:38] **+55 87 9978-4968:**
> _+55 81 9575-5362: Tira esse v1 e testa, se ele tá lendo como open aí compatível, ele deve preencher esse v1 sozinho (acho)_
foi nao

[11:38] **+55 87 9978-4968:** ja troquei api e tudo

[11:38] **+55 27 99694-0707:**
> _+55 87 9978-4968: foi nao_
POEN NA GLM

[11:40] **Você:**
> _+55 51 9425-4975: Que estrutura é essa?_
Orquestramento de agentes, mto foda da pra rodar em loop várias funções com diversos agentes, uns caçando bug outros resolvendo

[11:40] **+356 7737 9669:** I get provider  dont respond error are u guys also facing it?

[11:41] **+55 51 9425-4975:**
> _Você: Orquestramento de agentes, mto foda da pra rodar em loop várias funções com diversos agentes, uns caçando bug outros resolvendo_
Que toop, e oque vc usou pra montar? Passa os macetes

[11:52] **+55 27 99694-0707:** Rapasiada a ghost agradece a paciencia de voces ! Estamos com instabilidade! Continue usando!

Hey everyone, Ghost appreciates your patience! We're experiencing some instability, but please keep using it!

[11:52] __+20 10 01449601 adicionou Signor For Programming__

[11:52] **+20 10 01449601:** [Mensagem de message_history_notice]

[11:58] __[Notificação do sistema]__

[12:17] **@ziadhatem:** Hello Developers,

I’m Frontend Software engineer open for any projects or jobs and this my full portfolio link

https://www.ziadhatem.dev

[12:43] **+55 12 99662-3545:** advanced tracking on
https://www.instagram.com/reel/DN1Z47y2ptD/?stkn=MWtwcG9ia2g5N2xhOQ==

[12:49] **+55 47 9971-5265:** alguma promoção rolando ?

[13:18] **Jk Cli:** Tem o cupom

[13:18] **Jk Cli:** De primeira compra

[13:18] **Jk Cli:** MAXPELOPRO

[13:22] **+352 661 775 760:** Olá

Estou com dificuldade de fazer o pagamento, podem ajudar?

[13:23] **+55 47 9618-4437:**
> _+352 661 775 760: Olá

Estou com dificuldade de fazer o pagamento, podem ajudar?_
https://buy.stripe.com/4gM3cx4Wc1xy9WRg5g87K00

[13:24] **+352 661 775 760:** Esse é o plano top?

[14:02] **+55 47 9618-4437:** Pro

[15:27] **+55 47 9971-5265:** [Imagem] Pessoal, comprei acesso a 1 hora mais ou menos e não consegui usar ainda... a ia para no meio mesmo usando o sonnet, tentei abrir um ticket no discord mais não consegui também, se alguem poder me dar uma ajuda

[15:29] **+55 51 9425-4975:** Parece que ta fora, pra mim ta assim tbm, começou agora a tarde

[15:31] **Você:**
> _+55 51 9425-4975: Parece que ta fora, pra mim ta assim tbm, começou agora a tarde_
Caiu aq também

[15:40] **Jk Cli:** Vamo fazer att

[15:41] **+55 54 9620-1797:** Por favor

[15:41] **+55 54 9620-1797:** [Figurinha]

[15:49] **+55 51 9425-4975:** Notifiquem quando voltar por favor

[15:49] **+55 47 9618-4437:** ja voltou

[15:49] **+55 27 99694-0707:**
> _+55 51 9425-4975: Notifiquem quando voltar por favor_
on

[15:50] **+55 51 9425-4975:** [Figurinha]

[15:52] **Jk Cli:** Tudo on !

[16:09] **+55 27 99694-0707:**
> _Jk Cli: Tudo on !_
tudo on ? me interessa heinnnnnn

[16:23] **+55 47 9618-4437:** payments via card working again.

[16:23] __[Notificação do sistema]__

[16:51] **+55 35 9946-8945:**
> _+55 47 9971-5265: Imagem: Pessoal, comprei acesso a 1 hora mais ou menos e não consegui usar ainda... a ia para no meio mesmo usando o sonnet, tentei abrir um ticket no discord mais não consegui também, se alguem poder me dar uma ajuda_
Acontece isso CMG direto

[16:51] **+55 35 9946-8945:** Tô ficando triste

[16:51] **+55 47 9971-5265:** [Imagem] ta foda...

[16:51] **+55 35 9946-8945:** Falta de contexto não é, pq enviei 10k de caracteres explicando o que quero e pra onde ir

[16:54] **+55 11 98099-6397:**
> _+55 47 9971-5265: Imagem: Pessoal, comprei acesso a 1 hora mais ou menos e não consegui usar ainda... a ia para no meio mesmo usando o sonnet, tentei abrir um ticket no discord mais não consegui também, se alguem poder me dar uma ajuda_
Suporte no PV. Desse jeito não conseguimos saber.

[16:55] **+55 11 98099-6397:**
> _+55 35 9946-8945: Acontece isso CMG direto_
Você também

[16:55] **+55 11 98099-6397:** Manda o email junto ao horário aproximado da requisição que conseguimos entender

[16:55] **+55 27 99694-0707:**
> _+55 47 9971-5265: Imagem: Pessoal, comprei acesso a 1 hora mais ou menos e não consegui usar ainda... a ia para no meio mesmo usando o sonnet, tentei abrir um ticket no discord mais não consegui também, se alguem poder me dar uma ajuda_
ta config errado

[16:56] **+55 27 99694-0707:** se ta no DC?

[17:08] **+55 47 9971-5265:**
> _+55 27 99694-0707: se ta no DC?_
sim

[18:13] **+55 21 98102-9583:** [Imagem]

[18:13] **+55 21 98102-9583:** [Imagem]

[18:14] **+55 21 98102-9583:** Pessoal, boa noite. Alguém mais tá tendo problemas com SSH?

[18:17] **+55 21 98102-9583:** [Imagem] Talvez tenha ocorrido em virtude da atualização mais recente. Se puderem me ajudar agradeço bastante!

[18:21] **Jk Cli:** Olá

[18:22] **Jk Cli:** Posso te ajudar pelo sup do discord se possível crie ticket por lá

[18:22] **+55 21 98102-9583:** Ixi, não uso mais discord há séculos. Qual o link? Confesso que nunca fui fã do dc

[18:22] **Jk Cli:** @all  mande print de quantos tokens vcs ja usaram kkk

[18:23] **Jk Cli:** Interessante saber se a galera tá usando bastante

[18:23] **Jk Cli:** Teve um aqui que já usou + de 200 milhões rapidão

[18:23] **+55 21 98102-9583:** [Imagem] Fiquei um pouco pra trás, quis ter vida ontem rs

[18:23] **Jk Cli:** Meu Deus

[18:23] **Jk Cli:** Kkkkk

[18:24] **+55 35 9946-8945:** [Imagem]

[18:24] **Jk Cli:** Caralh

[18:24] **Jk Cli:** 200k

[18:25] **+55 21 98102-9583:** Tá me ajudando demais, eu tinha criado um sistema interno da minha empresa, então tô usando MUITO pra treinar, ainda mais por minha área ser muito nichada

[18:25] **+55 21 98102-9583:** Já indiquei pro meu sócio em outro projeto comprar também. Só me perco quando surgem essas paradas mais específicas, fico muito perdido por não ser dev

[18:27] **+55 21 98102-9583:**
> _Jk Cli: Caralh_
[Imagem] Irmão, consegue me passar o link do dc pra buscar ajuda? Tô cheio de sessão travada porque ele fica em looping ou morre por causa disso, tá foda

[18:28] **Jk Cli:** Claro

[18:34] **+55 51 9425-4975:** [Imagem]

[18:34] **+55 83 8798-9954:**
> _Jk Cli: @all  mande print de quantos tokens vcs ja usaram kkk_
[Imagem]

[18:35] **Jk Cli:** Caramba

[18:35] **+55 51 9425-4975:** Comecei a usar faz 4 dias kk

[19:45] **+55 11 94307-4349:** rapaziada, tenho uma dúvida, eu atendo um cliente aqui que roda black e os provedor de domínio derruba direto os domínios comprados né

recomendam um provedor ou conhecem uma forma de solucionar isso daq? uma forma de evitar derrubar os domínios

[19:45] **+55 11 94307-4349:** pq as paradas tão rodando, gastando ads pra caraio e cai

[19:46] **+55 47 9618-4437:**
> _+55 11 94307-4349: rapaziada, tenho uma dúvida, eu atendo um cliente aqui que roda black e os provedor de domínio derruba direto os domínios comprados né

recomendam um provedor ou conhecem uma forma de solucionar isso daq? uma forma de evitar derrubar os domínios_
A solução de não derrubar domínio e saber fazer a pagina sem fingerorint do site real que você clonou

[19:46] **+55 11 94307-4349:** n é clone

[19:46] **+55 47 9618-4437:** Se não cai por phishing mesmo

[19:46] **+55 11 94307-4349:** é ofertas no geral

[19:46] **+55 11 94307-4349:** tem uma q eu fiz do zero aqui pra ele e caiu

[19:46] **+55 47 9618-4437:**
> _+55 11 94307-4349: é ofertas no geral_
Site de que

[19:46] **+55 11 94307-4349:** venda de roupa

[19:47] **+55 11 94307-4349:** comprei domínio novo, caiu em 3 dias

[19:47] **+55 47 9618-4437:** E algo que tá copiando alguma loja conhecida aí aciona phising

[19:47] **+55 11 94307-4349:** nn, nada de loja conhecida

[19:47] **+55 47 9618-4437:** Então deve tar tomando report

[19:48] **+55 47 9618-4437:** Tenta comprar domínio bullet proof

[19:48] **+55 47 9618-4437:** Bem mais caro mas acontece isso nunca

[19:48] **+55 11 94307-4349:** como faz isso?

[19:49] **+55 47 9618-4437:** Tem q ver um provedor bulletproof confiável

[19:49] **+55 47 9618-4437:** E a prova de balas o domínio

[19:50] __Jk Cli adicionou +55 86 9520-8558__

[21:15] **+55 11 94057-2122:**
> _Jk Cli: @all  mande print de quantos tokens vcs ja usaram kkk_
Pelo painel da ghost ou pela aba de uso do Claude?

[21:32] **+55 27 99694-0707:** [Imagem] me sugiram ui/ux

[21:36] **+55 47 9763-4367:** [Imagem]

[21:36] **+55 47 9763-4367:**
> _+55 27 99694-0707: Imagem: me sugiram ui/ux_
Eita

[21:36] **+55 27 99694-0707:**
> _+55 47 9763-4367: Imagem_
seu perfil e empresarial ne

[21:37] **+55 27 99694-0707:** quase 4bi

[21:37] **+55 47 9763-4367:** Esse o da ghost.

O empresarial, ja bateu uns 10B kkkk

[21:38] **+55 27 99694-0707:**
> _+55 47 9763-4367: Esse o da ghost.

O empresarial, ja bateu uns 10B kkkk_
carai se revende?

[21:38] **+55 47 9763-4367:** Nop, usa dentro da empresa, e dela não meu

[21:38] **+55 47 9763-4367:** Ai tenho acesso tbm, la e taks quase 24h kkkk

[21:39] __+1 (857) 346-7537 entraram usando o link de convite__

[21:44] **+55 27 99694-0707:** _Mensagem apagada_

[21:44] **+55 27 99694-0707:** _Mensagem apagada_

[21:44] **+55 47 9763-4367:** Eu vi

[21:45] **+55 47 9763-4367:** Ta ficando legal

[21:45] **+55 27 99694-0707:** _Mensagem apagada_

[21:45] **+55 27 99694-0707:** _Mensagem apagada_

[21:45] **+55 27 99694-0707:** _Mensagem apagada_

[21:46] **+55 27 99694-0707:** _Mensagem apagada_

[21:46] **+55 27 99694-0707:** _Mensagem apagada_

[21:46] **+55 27 99694-0707:** _Mensagem apagada_

[21:47] **+55 27 99694-0707:** _Mensagem apagada_

[21:47] **+55 27 99694-0707:** _Mensagem apagada_

[22:16] **+55 47 9763-4367:**
> _+55 27 99694-0707: ate outubro vai ter claude implementado, e toda estrutura do whatsapp, para a ia comandar de acordo com o que voce pedir_
[Imagem] Eu fiz um discord para usar com os amigos kkk

[22:16] **+55 47 9618-4437:**
> _+55 47 9763-4367: Imagem: Eu fiz um discord para usar com os amigos kkk_
Ficou top

[22:17] **+55 47 9763-4367:** Ja coloquei 70% do que queria

[22:18] **Jk Cli:**
> _+55 47 9763-4367: Imagem: Eu fiz um discord para usar com os amigos kkk_
Manda esse aí

[22:18] **Jk Cli:** Kkkk

[22:18] **Jk Cli:** Xô ver

[22:35] **+55 27 99694-0707:** _Mensagem apagada_

[22:35] **+55 27 99694-0707:** _Mensagem apagada_

[22:36] **+55 35 9946-8945:**
> _+55 27 99694-0707: Imagem: openai, me perdoe, seu c* e meu, copiei, e lindo essa porra tnc_
Tá fazendo um agente de ia?

[22:36] **+55 27 99694-0707:** _Mensagem apagada_

[22:37] **+55 27 99694-0707:** _Mensagem apagada_

[22:37] **+55 27 99694-0707:** _Mensagem apagada_

[22:38] **+55 27 99694-0707:** _Mensagem apagada_

[22:38] **Signor For Programming:** I have an internal server azure gpt

[22:38] **+55 27 99694-0707:** to fazendo isso aki pra ficar insanooo insanooooo algo nunca visto

[22:38] **Signor For Programming:** Need someone to get a key 😅

[22:38] **+55 27 99694-0707:**
> _Signor For Programming: I have an internal server azure gpt_
calma gringo

[22:38] **+55 27 99694-0707:** n sou gay ta ja vo avisando

[22:39] **+55 27 99694-0707:** se for rico meu nome e catarina

[22:39] **+55 27 99694-0707:** _Mensagem apagada_

[22:39] **+55 27 99694-0707:** _Mensagem apagada_

[22:39] **+55 27 99694-0707:** _Mensagem apagada_

[22:40] **+55 27 99694-0707:** _Mensagem apagada_

[22:43] **+55 51 9425-4975:** E ela já ta no ar pra gente testar?

[22:43] **+55 27 99694-0707:**
> _+55 51 9425-4975: E ela já ta no ar pra gente testar?_
25-12 save date abracadabra programando falando

[22:44] **+55 27 99694-0707:** Do espaco sideral para o seu vscode

[22:45] **+55 51 9425-4975:** E a questão da memória dos agentes? Ta arquitetando como? To começando a trampar com isso

[22:48] **+55 27 99694-0707:** _Mensagem apagada_

[22:48] **+55 27 99694-0707:** _Mensagem apagada_

[22:48] **+55 51 9425-4975:** Pode crer

[22:48] **+55 27 99694-0707:** _Mensagem apagada_

[22:49] **+55 51 9425-4975:** É o mais difícil de acertar na memória da IA é a extração de conteúdo relevante, e usar ele no momento certo, pra n ficar estourando orçamento

[22:49] **+55 27 99694-0707:** _Mensagem apagada_

[22:49] **Jk Cli:** Caraca papo aqui tá de alto nível

[22:50] **Jk Cli:** Graças a Deus meus clientes são os melhores devs

[22:50] **Jk Cli:** Só tubarão aqui 🦈🦈🦈

[22:50] **+55 51 9425-4975:**
> _+55 27 99694-0707: ai que vem a compactacao de contexto meu man_
Depende, pra conversas mt longas sim, mas n vale a pena sair compactando tudo

[22:51] **+55 27 99694-0707:** _Mensagem apagada_

[22:51] **+55 27 99694-0707:** _Mensagem apagada_

[22:51] **+55 51 9425-4975:** Ah sim, pro seu caso sim

[22:51] **+55 27 99694-0707:** _Mensagem apagada_

[22:52] **+55 27 99694-0707:** _Mensagem apagada_

[22:52] **+55 27 99694-0707:** _Mensagem apagada_

[22:52] **+55 27 99694-0707:** _Mensagem apagada_

[22:53] **+55 51 9425-4975:** Mas tu ta com ele ilimitado tbm? Ou ta pagando os tokens normal?

[22:53] **+55 27 99694-0707:** _Mensagem apagada_

[22:53] **+55 27 99694-0707:** _Mensagem apagada_

[22:53] **+55 27 99694-0707:** _Mensagem apagada_

[22:53] **+55 27 99694-0707:** _Mensagem apagada_

[22:53] **+55 27 99694-0707:** _Mensagem apagada_

[22:53] **+55 51 9425-4975:** To precisando de uns amigos assim kkkkkkkk

[22:54] **+55 27 99694-0707:** _Mensagem apagada_

[22:54] **+55 27 99694-0707:** _Mensagem apagada_

[22:54] **+55 27 99694-0707:** _Mensagem apagada_

[22:54] **+55 27 99694-0707:** _Mensagem apagada_

[22:54] **+55 27 99694-0707:** _Mensagem apagada_

[22:54] **+55 51 9425-4975:** Bah, pior que to integrando um sistema com home assistent

[22:54] **+55 51 9425-4975:** Ta ficando massa

[22:55] **+55 27 99694-0707:** pode

[22:55] **+55 27 99694-0707:** podecre

[22:55] **+55 27 99694-0707:** da para insanizar maninho

[22:58] **Jk Cli:** Astra 6 is coming’s 👀👀👀👀👀👀👀

[22:58] **Jk Cli:** 👀👀☠️

[22:58] **+55 51 9425-4975:** Na ghost?

[22:58] **+55 27 99694-0707:**
> _Jk Cli: Astra 6 is coming’s 👀👀👀👀👀👀👀_
rapais

[22:59] **+55 27 99694-0707:** eu lembro do meu astra 2.0

[22:59] **+55 27 99694-0707:** o bixo era um canhao

[22:59] **+55 27 99694-0707:** ta mlx

[22:59] **+55 27 99694-0707:**
> _+55 51 9425-4975: Na ghost?_
yep

[22:59] **+55 27 99694-0707:** acha que a ghost vai ficar pra tras

[22:59] **Jk Cli:** 👀👀👀👀👀👀

[22:59] **+55 51 9425-4975:** Huul ai sim em, quero ver

[22:59] **Jk Cli:** Será que os cara vai pular da ponte ?

[22:59] **Jk Cli:** Os anti

[22:59] **Jk Cli:** Eita

[23:00] **Jk Cli:** Os inimigo já compra caixão já que vão se matar tudin

[23:00] **Jk Cli:** Kkkkkkk

[23:00] **+55 27 99694-0707:**
> _Jk Cli: Será que os cara vai pular da ponte ?_
se tiver $ pula duma ponte aki pertin de casa

[23:00] **Jk Cli:** Kkkkkkkk

[23:00] **Jk Cli:** Oiá o cara

[23:00] **+55 51 9425-4975:** Mas assim, pelo que eu vi, funciona pq os tokens não são enviados, mas os cara vão arrumar isso, nao?

[23:00] **+55 27 99694-0707:** boto ate cochao e cafesin

[23:01] **Jk Cli:** Irmão vamo trazer novidades

[23:01] **Jk Cli:** Bastante

[23:01] **Jk Cli:** Investindo em infra

[23:01] **Jk Cli:** Hoje somos acredito que maior fornecedora de tokens eu falo venda

[23:01] **Jk Cli:** Fico feliz que estão construindo várias coisas

[23:16] **+55 47 9763-4367:** GPT astra?

[23:16] **+55 47 9763-4367:** PERIGO

[23:16] **+55 47 9763-4367:** vou derrubar o gorverno com ele

[23:16] **+55 47 9763-4367:** e expor toda a corrupção

[23:17] **+55 27 99694-0707:**
> _+55 47 9763-4367: e expor toda a corrupção_
calma thinkwink

[23:17] **+55 47 9763-4367:** kkkkkkkk

[23:21] **+55 27 99694-0707:**
> _+55 47 9763-4367: kkkkkkkk_
nem sexta e ja quer ir pra esquina com o 38 e o facao na cinta mofi

[23:21] **+55 27 99694-0707:** sexta xera ja ja vem

[23:21] **+55 47 9763-4367:** Bom que para sexta e so 4 dias de trabalho

[23:22] **+55 47 9763-4367:** VIVA independência

[23:22] **Jk Cli:** [Imagem]

[23:22] **+55 47 9763-4367:** [Imagem] TURURU

[23:22] **+55 27 99694-0707:**
> _Jk Cli: Imagem_
ta no motel mofi?

[23:22] **Jk Cli:** Modo ghost

[23:22] **Jk Cli:** To n

[23:22] **Jk Cli:** Deixei tudo azul

[23:22] **Jk Cli:** Combinar com a empresa né

[23:23] **+55 27 99694-0707:** quem se ta comendo

[23:23] **+55 27 99694-0707:** h ou m

[23:23] **Jk Cli:** Vou deixar luz até na piscina da minha casa

[23:23] **+55 27 99694-0707:** garai pai

[23:23] **Jk Cli:** Luz azul

[23:23] **+55 27 99694-0707:** se n perde tempo

[23:23] **+55 27 99694-0707:** ata e sua casa

[23:23] **+55 27 99694-0707:** perdoa

[23:23] **+55 47 9763-4367:** kkkkkkkkkkk

[23:23] **Jk Cli:** E a pow

[23:23] **Jk Cli:** Kkkkkk

[23:23] **Jk Cli:** Cara pensa q é mote

[23:24] **Jk Cli:** Porr é ess

[23:24] **Jk Cli:** Motel e cor vermelho

[23:24] **Jk Cli:** Motel com pc gamer

[23:25] **+55 27 99694-0707:** ja fui em cabare com luz azul

[23:25] **+55 27 99694-0707:** tava vazio ne

[23:25] **+55 27 99694-0707:** mas era cabare

[23:25] **+55 27 99694-0707:** eu axo

[23:25] **+55 27 99694-0707:** la no ceara

[23:26] **+55 27 99694-0707:** povo desanimado tnc

[23:26] **Jk Cli:** Taporra

[23:26] **+55 27 99694-0707:** peugei a puta so falava do filho dela viado

[23:26] **+55 27 99694-0707:** mandei caga no amto

[23:27] **+55 27 99694-0707:** ela queria ir junto

[23:27] **+55 27 99694-0707:** ai fui por a carteira no carro

[23:27] **+55 27 99694-0707:** do nada sumiu a chave do carro

[23:27] **+55 27 99694-0707:** mo djhabo eu arr no dia viado

[23:28] **+55 27 99694-0707:** [Imagem]

[23:28] **+55 27 99694-0707:** q gracinha

[23:30] **+55 47 9763-4367:** Vcs usando o sem limite

[23:30] **+55 47 9763-4367:** eu tendo que usar o 20X e acabei com o limite agora

[23:30] **+55 47 9763-4367:** e não ajustei o bug em produção

[23:30] **+55 47 9763-4367:** Vou ter que ir no modo raiz

[23:30] **+55 47 9763-4367:** e dar bash em tudo

[23:32] **+55 27 99694-0707:**
> _+55 47 9763-4367: e não ajustei o bug em produção_
mofi else{ alert(Índisponivel, tente novamente amanha'); }. e vai deita pai kkkk

[23:32] **+55 47 9763-4367:** kkkkkkkkkkkkkkkkkkk

[23:32] **+55 27 99694-0707:** ou mete 1 carregando

[23:32] **+55 27 99694-0707:** e ja era kkkk

[23:32] **+55 27 99694-0707:** kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk

[23:32] **+55 27 99694-0707:** sacanagem o carregando kkkk

[23:32] **+55 47 9763-4367:** [Imagem] Pai, e foda, sem o claude, ajustei.

"dei um run.sh" no que ele ja tinha feito antes de cair

[23:33] **+55 27 99694-0707:**
> _+55 47 9763-4367: Imagem: Pai, e foda, sem o claude, ajustei.

"dei um run.sh" no que ele ja tinha feito antes de cair_
ai sim

[23:33] **+55 27 99694-0707:** [Figurinha]

[23:37] **+55 27 99694-0707:** _Mensagem apagada_

[23:37] **+55 27 99694-0707:** nunca mais eu vo durmi

[23:37] **+55 27 99694-0707:** vtnc

[23:37] **+55 27 99694-0707:** cade meu gardenal

[23:39] **+55 47 9763-4367:** Lançaram o GPT?

[23:42] **+55 27 99694-0707:**
> _+55 47 9763-4367: Lançaram o GPT?_
xove

[23:43] **+55 27 99694-0707:** ainda n

[23:44] **+55 47 9763-4367:**
> _+55 27 99694-0707: Imagem: meu deus cara_
Achei que tinha, vi aqui kkkkkk

[23:45] **+55 27 99694-0707:** _Mensagem apagada_

[23:47] **+55 47 9763-4367:** Ahh ta

[23:47] **+55 47 9763-4367:** e da propia openai

[23:47] **+55 47 9763-4367:** Tinha entendido que era pelo ghost

[23:47] **+55 47 9763-4367:** kkkk

[23:48] **+55 27 99694-0707:** _Mensagem apagada_

[23:49] **+55 27 99694-0707:** to fazendo uma extensao para webwhatsapp para gravar falando e escrever, igual do iphone, muito pratico

[23:53] **+55 47 9763-4367:** Entendi

[23:58] **+55 47 9618-4437:** [Mensagem de album]

[23:58] **+55 47 9618-4437:** [Imagem] Nem o gpt 6 ultrapassa o fabio

[23:58] **+55 47 9618-4437:** [Imagem]

[23:59] **+55 27 99694-0707:** _Mensagem apagada_

[23:59] **+55 27 99694-0707:**
> _+55 47 9618-4437: [album]_
vdd

---

## 8 de setembro de 2026

[0:04] **+55 27 99694-0707:** _Mensagem apagada_

[0:08] **+55 27 99694-0707:** _Mensagem apagada_

[0:12] **+55 47 9763-4367:**
> _+55 27 99694-0707: Astra nao modulariza projeto, fabin aspirador de po ja modulariza, que modularizar projeto e obrigatorio qualquer fdp programador fazer para facilitar passear pelo projeto resolver as treta mais rapido, falo isso pq vivencio programacao 24 por 48_
Eu fiz uma skill só para isso, tenho que seguir padrão :/

[0:12] **+55 47 9763-4367:** Pq botam correntes em nós devs?

[0:13] **+55 27 99694-0707:** _Mensagem apagada_

[0:13] **+55 47 9763-4367:** Kkkkkk

[0:13] **+55 47 9763-4367:** O claude lá é compartilhado

[0:13] **+55 47 9763-4367:** Não é só eu não

[0:14] **+55 47 9763-4367:** Essa vps que deu o b.o tem um claude só pra ela

[0:14] **+55 27 99694-0707:**
> _+55 47 9763-4367: O claude lá é compartilhado_
kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk mintira irmao kkkkkkkkk

[0:14] **+55 47 9763-4367:** Kkkk

[0:14] **+55 27 99694-0707:** quando acaba os token o primeiro que queima os token vai lava o banheiro

[0:14] **+55 47 9763-4367:** Sim kkkk

[0:15] **+55 47 9763-4367:** Mas temos uma pessoal tbm, essa lá tem uma pra ela sla pq

[0:15] **+55 47 9763-4367:** Acho que deve rodar coisas sozinho

[0:15] **+55 47 9763-4367:** Não sou da infra, eles que respondam essa

[0:15] **+55 47 9763-4367:** 🤣

[0:15] **+55 27 99694-0707:** kkkkk

[0:35] **+55 21 99960-2516:** [Figurinha]

[0:39] **+55 27 99694-0707:**
> _+55 21 99960-2516: Figurinha_
ja ja tomei golpe do thiago finch ele pediu 400 no pix e eu mandei

[0:39] **+55 27 99694-0707:** kkkk

[0:39] **+55 21 99960-2516:** Kkkkkkk

[0:47] **+55 47 9763-4367:** Kkkkk

[0:47] **+55 47 9763-4367:** Ai não

[1:04] **+55 54 9620-1797:** [Imagem]

[1:04] **+55 54 9620-1797:** Começando os trabalhos por aqui

[5:48] __+55 21 98373-0727 entraram usando o link de convite__

[6:48] __+55 49 8873-8953 entraram usando o link de convite__

[7:42] __+55 44 9839-3639 entraram usando o link de convite__

[8:37] **+55 51 9425-4975:** Bom dia, ta com instabilidade?

[8:38] **+55 51 9184-0532:** Se está usando o app do Claude sim

[8:39] **+55 51 9184-0532:** Eu iniciei pelo terminal e segue

[8:40] **+55 51 9425-4975:** Vou testar

[9:05] **+55 51 9425-4975:** Na cli, depois da configuração inicial, se ou troquei o token, como atualizo?

[9:09] **+55 47 9763-4367:**
> _+55 51 9425-4975: Na cli, depois da configuração inicial, se ou troquei o token, como atualizo?_
Tu diz atualiza o proprio CLI para versão nova?

[9:10] **+55 51 9425-4975:** Não, atualizar o token da ghost

[9:15] **+55 47 9763-4367:** no settings do .claude

[9:15] **+55 47 9763-4367:** no windows fica dentro da pasta do seu nome

[9:15] **+55 51 9425-4975:** Blz

[9:48] **+55 51 9425-4975:** [Imagem] Como faz pra aparecer o fable?

[10:46] **+55 47 9763-4367:** digita /model claude-fable-5.1

[10:46] **+55 47 9763-4367:** ele ja seta como defaut na sequencia

[10:48] **+55 51 9425-4975:** Valeuu

[10:59] **+63 926 268 4844:** [Imagem] site down?

[11:00] **Jk Cli:** [Imagem]

[11:00] **Jk Cli:** No

[11:05] **+63 926 268 4844:** Weird 🤔 I think its dns issue?

[11:41] **+55 54 9620-1797:** Bom dia galera, vi uma coisa aqui nas conversas que achei interessante

[11:42] **+55 54 9620-1797:** Pelo powershell é mais 'estavel' do que pelo code?

[11:42] **+55 51 9425-4975:** Cara, hoje pelo app ta demorando demais

[11:42] **+55 51 9425-4975:** Pela cli do terminal ta indo de boa

[11:43] **+55 51 9425-4975:** Mas nos outros dias o app tava de boa tbm

[11:44] **+55 54 9620-1797:** Saquei

[11:58] **+55 35 9946-8945:** Alguém do suporte on?

[11:59] **Jk Cli:** Opa

[11:59] **Jk Cli:** Diga

[12:05] **+55 27 99898-8510:**
> _+55 54 9620-1797: Pelo powershell é mais 'estavel' do que pelo code?_
e questao de costume, mais como colega falou, de fato pelo app do claude está demorando bastante.
agora so uso claude cod cli

[12:05] **+55 27 99898-8510:** tem um colega que recomendou maestri, e cara que ferramenta fantástica

[12:06] **+55 54 9620-1797:** Tem o link pra mim? Quero dar uma olhada

[12:07] **+55 27 99898-8510:**
> _+55 54 9620-1797: Tem o link pra mim? Quero dar uma olhada_
do maestri?

[12:07] **+55 54 9620-1797:** Isso

[12:07] **+55 27 99898-8510:**
> _+55 54 9620-1797: Isso_
https://www.themaestri.app/en

[12:08] **+55 54 9620-1797:** Obrigado

[13:25] __+971 50 175 5022 entraram usando o link de convite__

[15:50] **Jk Cli:** Quem quiser plano empresarial só ir pv oferecemos melhor proposta possível

[15:50] **Jk Cli:** 🫡

[17:05] **Signor For Programming:** fable 5.1 have tool calling issue ?

[17:05] **Signor For Programming:** [Client tool call ID: "toolu_1788897400001_1"]

[17:17] **Signor For Programming:** ??

[17:30] **+55 47 9763-4367:** I did’t see this before

[18:11] **+55 27 99694-0707:**
> _Signor For Programming: fable 5.1 have tool calling issue ?_
xo testa aki

[18:11] **+55 27 99694-0707:** boa tarde

[18:11] **Signor For Programming:**
> _+55 47 9763-4367: I did’t see this before_
which tool u are using ?

[18:12] **+55 47 9763-4367:**
> _Signor For Programming: which tool u are using ?_
Claude code IDE

[18:13] **+55 27 99694-0707:**
> _Signor For Programming: fable 5.1 have tool calling issue ?_
voce e programador ? se for programador, recomendo o codex!

[18:14] **+55 47 9618-4437:**
> _Signor For Programming: [Client tool call ID: "toolu_1788897400001_1"]_
Fixed

[18:14] **+55 27 99694-0707:**
> _+55 47 9618-4437: Fixed_
me da adm pai

[18:14] **+55 27 99694-0707:** suporte fdp e esse q n tem adm kkkk

[18:14] **+55 51 9425-4975:**
> _+55 27 99694-0707: voce e programador ? se for programador, recomendo o codex!_
Eu to usando no claude deskotp e opencode onde eu tenho meu harness, pq o codex é melhor que o claude deskotp?

[18:17] **+55 62 9497-3773:**
> _+55 51 9425-4975: Eu to usando no claude deskotp e opencode onde eu tenho meu harness, pq o codex é melhor que o claude deskotp?_
fiquei com a mesma duvida

[18:17] **+55 27 99694-0707:**
> _+55 51 9425-4975: Eu to usando no claude deskotp e opencode onde eu tenho meu harness, pq o codex é melhor que o claude deskotp?_
depende do que voce faz

[18:17] **+55 27 99694-0707:** codex = programacao b.e pesada

[18:18] **+55 27 99694-0707:** claudio programacao mais leve

[18:18] **+55 48 9101-5225:**
> _+55 27 99694-0707: claudio programacao mais leve_
Nnada po,

[18:18] **+55 48 9101-5225:** Ta viajando

[18:18] **+55 27 99694-0707:** abracadabra minha extensao, uso para coisas absurdamente complexas

[18:18] **+55 48 9101-5225:** Claude no 20x melhor coisa q tem

[18:18] **+55 27 99694-0707:** pq posso delegar ate 30 agentes

[18:19] **+55 27 99694-0707:** e eles ficam pesquisando estudando

[18:19] **+55 27 99694-0707:** meu note fica como pegando fogo kkkkk

[18:19] **+55 54 9620-1797:** [Mensagem de voz]

[18:19] **+55 27 99694-0707:**
> _+55 48 9101-5225: Claude no 20x melhor coisa q tem_
depende do que voce faz

[18:19] **+55 54 9620-1797:** [Mensagem de voz]

[18:19] **+55 27 99694-0707:**
> _+55 54 9620-1797: Mensagem de voz_
o fabio e bom

[18:19] **+55 48 9101-5225:**
> _+55 27 99694-0707: depende do que voce faz_
Pra tudo men, mas eu digo claude pago 20x e nao o da ghost

[18:20] **+55 51 9425-4975:** [Mensagem de voz]

[18:20] **+55 48 9101-5225:** Se for comparar com da ghost é codex

[18:20] **+55 27 99694-0707:**
> _+55 54 9620-1797: Mensagem de voz_
quando eu usava claudio antropica, eu usava no codex

[18:20] **+55 48 9101-5225:**
> _+55 51 9425-4975: Mensagem de voz_
Não, o harness muda

[18:20] **+55 51 9425-4975:** Saquei

[18:20] **+55 27 99694-0707:**
> _+55 51 9425-4975: Mensagem de voz_
inteligencia e complexidade = codex

[18:20] **+55 48 9101-5225:** O harness do clau cli no plano 20x é doideira de bom

[18:20] **+55 54 9620-1797:**
> _+55 27 99694-0707: quando eu usava claudio antropica, eu usava no codex_
Eu no caso, to usando o GPT 6 agora

[18:21] **+55 51 9425-4975:** Faz sentido

[18:21] **+55 27 99694-0707:** planner do codex e absurdo de evoluido

[18:21] **+55 48 9101-5225:**
> _+55 48 9101-5225: O harness do clau cli no plano 20x é doideira de bom_
Mas com api do ghost n funfa

[18:21] **+55 51 9425-4975:** Vou testar

[18:21] **+55 27 99694-0707:**
> _+55 54 9620-1797: Eu no caso, to usando o GPT 6 agora_
de ontem pra hoje o gpt6 ficou podre n sei pq so fazendo merda kkkk

[18:21] **+55 27 99898-8510:**
> _+55 27 99694-0707: planner do codex e absurdo de evoluido_
isso tem que concordar

[18:21] **+55 48 9101-5225:**
> _+55 27 99694-0707: de ontem pra hoje o gpt6 ficou podre n sei pq so fazendo merda kkkk_
Muita gente usando, ele emburrece kkkk

[18:21] **+55 54 9620-1797:**
> _+55 27 99694-0707: de ontem pra hoje o gpt6 ficou podre n sei pq so fazendo merda kkkk_
Aqui ta voando

[18:22] **+55 27 99898-8510:**
> _+55 48 9101-5225: O harness do clau cli no plano 20x é doideira de bom_
vc tem claude 20x?

[18:22] **Signor For Programming:**
> _+55 47 9618-4437: Fixed_
[Client tool call ID: "toolu_1788902530001_1"] 
still getting it

[18:22] **+55 51 9425-4975:** [Mensagem de voz]

[18:23] **+55 51 9425-4975:** [Mensagem de voz]

[18:23] **+55 27 99694-0707:** [Imagem] aqui eu chaveio o claude para o codex bom demais o meu chaveiro

[18:24] **+55 54 9620-1797:**
> _+55 51 9425-4975: Mensagem de voz_
[Mensagem de voz]

[18:24] **+55 54 9620-1797:** [Mensagem de voz]

[18:25] **+55 51 9425-4975:** Poise

[18:26] **Signor For Programming:**
> _Signor For Programming: [Client tool call ID: "toolu_1788902530001_1"] 
still getting it_
Im using claude cli

[18:26] **+55 54 9620-1797:** [Mensagem de voz]

[18:26] **+55 81 9398-4490:**
> _+55 48 9101-5225: Claude no 20x melhor coisa q tem_
Problema é comprar

[18:27] **@fortytwowill:**
> _Signor For Programming: Im using claude cli_
I had some tool call issues as well, using Pi

[18:27] **+55 51 9425-4975:** [Mensagem de voz]

[18:28] **+55 51 9425-4975:** [Mensagem de voz]

[18:28] **+55 54 9620-1797:**
> _+55 51 9425-4975: Mensagem de voz_
Sim...

[18:38] **+55 48 9101-5225:**
> _+55 27 99898-8510: vc tem claude 20x?_
Sim, por isso opinei sobre

[20:44] **Jk Cli:** @all marquem a gente no Instagram vamos repostar todos 🫡

[20:44] **Jk Cli:** @ghost.cli

[22:29] **+55 87 9128-0580:** [Imagem]

[22:29] **+55 87 9128-0580:** [Figurinha]

[22:29] **+55 87 9128-0580:** [Figurinha]

[22:30] **+55 87 9128-0580:** Montando a próxima máquina de imprimir dinheiro

[22:31] **Jk Cli:** 🤑🤑🤑🤑🤑

[22:32] **+55 51 9184-0532:** Rola teste com link de indicação?

[22:33] **+63 926 268 4844:** [Imagem] Why I can't access ghostcli.dev? 🤔

[22:33] **+63 926 268 4844:** Then mobile data look working 🤔

[22:43] **+55 87 9128-0580:** [Imagem] It might work.

[22:44] **+55 87 9128-0580:** [Imagem]

[23:06] **+63 926 268 4844:**
> _+55 87 9128-0580: Imagem: It might work._
Ok I try

[23:07] **+63 926 268 4844:** Not working.

[23:08] **+63 926 268 4844:** [Imagem]

[23:10] **Jk Cli:** [Imagem]

[23:26] **+63 926 268 4844:** Is my internet blocked?

[23:27] **+63 926 268 4844:** Or I will try change dns

[23:27] **+55 47 9618-4437:**
> _+63 926 268 4844: Is my internet blocked?_
Yes maybe your provider

[23:27] **+55 47 9618-4437:**
> _+63 926 268 4844: Or I will try change dns_
Should work

[23:49] **+55 11 94307-4349:** algum suporte on?

[23:50] **+55 27 99694-0707:**
> _+55 11 94307-4349: algum suporte on?_
aoba

[23:50] **+55 27 99694-0707:** sou eu

[23:50] **+55 27 99694-0707:** tiririca da ghost

[23:50] **+55 11 94307-4349:** n acredito q vc tá on, o mais bonito de todos

[23:50] **+55 27 99694-0707:**
> _+55 11 94307-4349: n acredito q vc tá on, o mais bonito de todos_
ainnnn cara

[23:50] **+55 27 99694-0707:** se sabe ne meu nome e amanda

[23:51] **+55 27 99694-0707:** se voce nao tiver $ meu nome e galego xucrowWW

---

## 9 de setembro de 2026

[0:47] **+55 54 9620-1797:** [Imagem] Algumas tarefas rodando só... rs

[0:48] **+55 27 99694-0707:**
> _+55 54 9620-1797: Imagem: Algumas tarefas rodando só... rs_
nossa senhora amigo

[0:48] **+55 54 9620-1797:** [Figurinha]

[0:48] **+55 27 99694-0707:**
> _+55 54 9620-1797: Imagem: Algumas tarefas rodando só... rs_
isso e info produto seu ?

[0:49] **+55 54 9620-1797:** Nao. Isso ai sao plugins e mods para minecraft. Estou criando agora um ecosistema inteiro, desde o launcher ate animações em 3d e etc.
Objetivo é lançar em dezembro ou perto dessa data.

[0:50] **+55 27 99694-0707:**
> _+55 54 9620-1797: Nao. Isso ai sao plugins e mods para minecraft. Estou criando agora um ecosistema inteiro, desde o launcher ate animações em 3d e etc.
Objetivo é lançar em dezembro ou perto dessa data._
parabens pela ideia

[0:50] **+55 27 99694-0707:** ideia + vontade = $$$$

[0:50] **+55 54 9620-1797:** Bem isso! Botei trabalhar e vou dormir

[0:50] **+55 54 9620-1797:** VIVA A IA!! ❤️

[0:51] **+55 27 99694-0707:** viva!

[0:51] **+55 27 99694-0707:** to implementando ia no meu cs kkkk

[0:51] **+55 27 99694-0707:** deixar os bots vivo

[0:51] **+55 54 9620-1797:** Caralho, que massa

[0:51] **+55 27 99694-0707:** o bot hackeia minha arma eu perco minha arma

[0:51] **+55 27 99694-0707:** tenho que ir atras

[0:51] **+55 54 9620-1797:** Tu diz, mexer na inteligencia deles?

[0:51] **+55 27 99694-0707:** 1 inferno

[0:51] **+55 54 9620-1797:**
> _+55 27 99694-0707: o bot hackeia minha arma eu perco minha arma_
Oloco

[0:52] **+55 27 99694-0707:** mas o bot tem que roubar meu hdexterno ou note

[0:52] **+55 27 99694-0707:** e tenho que proteger

[0:52] **+55 27 99694-0707:** se n fodeu

[0:52] **+55 27 99694-0707:** kkkkk

[0:53] **+55 54 9620-1797:** Carai, que loucura

[0:54] **+55 54 9620-1797:** Nunca vi nada disso no CS

[0:54] **+55 54 9620-1797:** Voce ta falando de qual CS? GO? ou 1.6

[0:57] **+55 27 99694-0707:** viagem ne ta ficando legal kkk

[0:57] **+55 27 99694-0707:**
> _+55 54 9620-1797: Tu diz, mexer na inteligencia deles?_
isso

[0:59] **+55 27 99694-0707:**
> _+55 54 9620-1797: Voce ta falando de qual CS? GO? ou 1.6_
sim

[0:59] **+55 27 99694-0707:** tipo cs go

[0:59] **+55 27 99694-0707:** so q e grafico que a ia fez

[1:00] **+55 54 9620-1797:** Hmmm

[1:00] **+55 54 9620-1797:** Entendi

[1:00] **+55 54 9620-1797:** Ta fazendo pelo fable da ghost?

[1:00] **+55 27 99694-0707:** mas to melhorando o jogo, to fazendo a forma que o boneco monta na moto

[1:00] **+55 27 99694-0707:** pra ter o efeito de montar na moto

[1:00] **+55 27 99694-0707:** saca

[1:00] **+55 27 99694-0707:**
> _+55 54 9620-1797: Ta fazendo pelo fable da ghost?_
sim

[1:00] **+55 27 99694-0707:** tem carro

[1:00] **+55 27 99694-0707:** moto

[1:00] **+55 27 99694-0707:** e patinete

[1:00] **+55 27 99694-0707:** e sistema de hackear as armas 1 do outro

[1:01] **+55 54 9620-1797:** Caralho kkkkk que massa

[1:01] **+55 27 99694-0707:** roubou o hdexterno

[1:01] **+55 27 99694-0707:** tomo no cu

[1:01] **+55 54 9620-1797:** Massa mesmo...

[1:01] **+55 54 9620-1797:** Amanha voce me mostra? Fiquei curioso

[1:01] **+55 27 99694-0707:** um infernin legal kkkk

[1:01] **+55 27 99694-0707:**
> _+55 54 9620-1797: Amanha voce me mostra? Fiquei curioso_
claro

[1:01] **+55 54 9620-1797:** Fecho

[1:01] **+55 54 9620-1797:** Vou nessa, tmj

[1:01] **+55 27 99694-0707:** e nois

[6:13] **+55 51 9425-4975:** Vcs sabem de tem como usar a API da ghost no cursor?

[7:03] **+55 27 99694-0707:** suporte on a partir das 9 hj

[7:22] **+55 47 9763-4367:**
> _+55 51 9425-4975: Vcs sabem de tem como usar a API da ghost no cursor?_
Nunca usei o cursor, mas ele aceita endpoint personalizado?

[7:25] **+55 27 99694-0707:**
> _+55 51 9425-4975: Vcs sabem de tem como usar a API da ghost no cursor?_
Rlx deixa da 9 hrs

[7:46] **+55 51 9425-4975:**
> _+55 47 9763-4367: Nunca usei o cursor, mas ele aceita endpoint personalizado?_
Pelo que eu vi da open ia

[7:46] **+55 51 9425-4975:**
> _+55 47 9763-4367: Nunca usei o cursor, mas ele aceita endpoint personalizado?_
É muito bom, melhor ide pra programar

[7:46] **+55 51 9425-4975:** O harness de ia deles funciona muito bem

[9:05] **+55 27 99694-0707:** suporte on mozamigo

[9:05] **+55 27 99694-0707:** mandem as bombas  kkk

[9:06] **+55 35 9946-8945:**
> _+55 27 99694-0707: mandem as bombas  kkk_
[Imagem]

[9:07] **+55 27 99694-0707:**
> _+55 35 9946-8945: Imagem_
qual se ta usando meu bom

[9:07] **+55 27 99694-0707:** xo testa aki pra ve como ta o endpoint

[9:07] **+55 27 99694-0707:** so 1 seg

[9:07] **+55 35 9946-8945:**
> _+55 27 99694-0707: qual se ta usando meu bom_
Fable 5.1

[9:08] **+55 27 99694-0707:**
> _+55 35 9946-8945: Fable 5.1_
ta no wifi?

[9:10] **+55 51 9425-4975:**
> _+55 51 9425-4975: Vcs sabem de tem como usar a API da ghost no cursor?_
@~Eduardo sabe me dizer?

[9:11] **+55 27 99694-0707:**
> _+55 51 9425-4975: @~Eduardo sabe me dizer?_
tem sim meu bom

[9:11] **+55 27 99694-0707:** tenho q ver como e pq n uso o cursor

[9:11] **+55 27 99694-0707:** se me falhe a memoria

[9:11] **+55 27 99694-0707:** voce tem que ser pro do cursor

[9:11] **+55 27 99694-0707:** pq o cursor nao libera inferencia sem ser pro

[9:12] **+55 27 99694-0707:** bao a ultima vez q usei cursor foi assim

[9:12] **+55 51 9425-4975:** Pode crer, eu sou, mas não achei, vou pesquisar aqui de novo

[9:12] **+55 27 99694-0707:** e na openai

[9:12] **+55 27 99694-0707:** e no campo da openai

[9:12] **+55 27 99694-0707:** que voce configura

[9:12] **+55 51 9425-4975:** Ah, isso eu testei

[9:13] **+55 51 9425-4975:** Não bombou

[9:13] **+55 27 99694-0707:** entao cursor e maluco por causa disso

[9:13] **+55 27 99694-0707:** coloca o endpoint nao funciona

[9:13] **+55 27 99694-0707:** e eu pesquisei e pq o cursor nao deixa

[9:13] **+55 27 99694-0707:** nao chega nem fazer request

[9:14] **+55 27 99694-0707:** nao sei pq cursor tem esse preconceito com outras apis

[9:14] **+55 27 99694-0707:** pq n pula pro vscode amigo

[9:15] **+55 27 99694-0707:** muito mais facil e mais completo

[9:16] **+55 35 9946-8945:**
> _+55 27 99694-0707: ta no wifi?_
Cabo

[9:18] **+55 51 9425-4975:**
> _+55 27 99694-0707: pq n pula pro vscode amigo_
Pq acho a memória deles ferrada de boa

[9:19] **+55 27 99694-0707:**
> _+55 51 9425-4975: Pq acho a memória deles ferrada de boa_
entendi

[9:19] **+55 27 99694-0707:** esperimenta o codex do vscode

[9:19] **+55 27 99694-0707:** vai se surpreender

[9:19] **+55 27 99694-0707:**
> _+55 35 9946-8945: Cabo_
normalizou ae ?

[9:20] **+55 35 9946-8945:**
> _+55 27 99694-0707: normalizou ae ?_
Ainda não Jovi

[9:28] **+55 27 99694-0707:**
> _+55 35 9946-8945: Ainda não Jovi_
se ta usando o fabinho ne

[9:28] **+55 27 99694-0707:** eu testei oopus

[9:28] **+55 27 99694-0707:** pera

[9:29] **+55 27 99694-0707:** [Imagem] fabinho ta resp

[9:30] **+55 27 99694-0707:** @~Pedro Camargo  pedrao quer tenta o vscode codex n ?

[9:30] **+55 27 99694-0707:** e facim de config

[9:30] **+55 27 99694-0707:** ele e pika demais

[9:30] **+55 35 9946-8945:**
> _+55 27 99694-0707: se ta usando o fabinho ne_
Siim

[9:30] **+55 35 9946-8945:**
> _+55 27 99694-0707: @~Pedro Camargo  pedrao quer tenta o vscode codex n ?_
Tô no Codex cli diretão

[9:31] **+55 27 99694-0707:** qual seu s.o amigo?

[9:31] **+55 35 9946-8945:**
> _+55 27 99694-0707: @~Pedro Camargo  pedrao quer tenta o vscode codex n ?_
Vou ver aqui

[9:31] **+55 35 9946-8945:**
> _+55 27 99694-0707: qual seu s.o amigo?_
Mac

[9:31] **+55 27 99694-0707:** oxe

[9:31] **+55 27 99694-0707:** avemaria

[9:31] **+55 27 99694-0707:** ta em casa

[9:31] **+55 27 99694-0707:** uso no meu air aki

[9:31] **+55 27 99694-0707:** de buenas

[9:31] **+55 27 99694-0707:** o seu e o applesilicone ?

[9:31] **+55 27 99694-0707:** silicon

[9:32] **+55 27 99694-0707:** kkkkkkkkkkkkkkkkkkkkkkkk silicone kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk

[9:32] **+55 35 9946-8945:** Kkkkkk não é Intel

[9:33] **+55 35 9946-8945:** Mac pro

[9:33] **+55 27 99694-0707:** a e o antigo

[9:33] **+55 27 99694-0707:** e ai ja n sei meu patrao

[9:33] **+55 27 99694-0707:** mas deve funfa sim

[9:33] **+55 27 99694-0707:** baixa vscode

[9:33] **+55 27 99694-0707:** usa o codex

[9:34] **+55 27 99694-0707:** se vai sentir la ele uma grande la ele diferenca

[9:34] **+55 27 99694-0707:**
> _+55 35 9946-8945: Kkkkkk não é Intel_
se voce tiver a $ de dubai troca por 1 appple silicon

[9:34] **+55 27 99694-0707:** memoria unificada e vida top demais slk

[9:37] **+55 35 9946-8945:** Siim, já tive um, aqui no Braza é triste...

[10:29] **+55 35 9946-8945:** Reestartei o Codex e voltou!

[11:14] __+55 47 9966-5224 entraram usando o link de convite__

[12:28] **+55 12 99662-3545:** _Mensagem apagada por um admin (Jk Cli)_

[12:28] **+55 12 99662-3545:** _Mensagem apagada por um admin (Jk Cli)_

[15:29] __+55 62 9364-7674 entraram usando o link de convite__

[15:34] **+55 62 9364-7674:** Boa tarde. 

Vim por indicação e queria confirmar duas coisas antes: 

- Está com acesso ao GPT-Astra? 
- ⁠Trabalho em 8 projetos ao mesmo tempo, teria problema? (Ou no meu laptop ou no meu pc)

[15:52] **Jk Cli:** Oii

[15:52] __Jk Cli adicionou +55 12 98710-3175__

[15:53] **Jk Cli:**
> _+55 62 9364-7674: Boa tarde. 

Vim por indicação e queria confirmar duas coisas antes: 

- Está com acesso ao GPT-Astra? 
- ⁠Trabalho em 8 projetos ao mesmo tempo, teria problema? (Ou no meu laptop ou no meu pc)_
Nenhum problema ,por enquanto n temos gpt Astra

[15:53] **Jk Cli:** Astra

[15:54] **Jk Cli:**
> _+55 62 9364-7674: Boa tarde. 

Vim por indicação e queria confirmar duas coisas antes: 

- Está com acesso ao GPT-Astra? 
- ⁠Trabalho em 8 projetos ao mesmo tempo, teria problema? (Ou no meu laptop ou no meu pc)_
Agora se a sua volumetria tiver bem alta recomendo empresarial

[15:55] **+55 62 9364-7674:** Ah, nao tem o astra ? Nem no empresarial? 

Eu estava vindo justamente para poder trocar entre 5.1 e Astra

[15:55] **+55 62 9364-7674:** Tem previsao de disponibilidade?

[15:55] **+55 21 98102-9583:**
> _+55 62 9364-7674: Ah, nao tem o astra ? Nem no empresarial? 

Eu estava vindo justamente para poder trocar entre 5.1 e Astra_
Ih João, foi mal, confundi algum print aqui no grupo então

[15:57] **Jk Cli:** Vamos trazer o Astra em breve

[15:57] **Jk Cli:** Estamos negociando

[15:57] **Jk Cli:** Precisa de algumas autorizações

[15:58] **+55 62 9364-7674:**
> _+55 21 98102-9583: Ih João, foi mal, confundi algum print aqui no grupo então_
Nah, andei pensando e aqui já pagamos 2 planos 20x e 4 planos PRO pro time. 

E eu ainda peguei o astra pra minha esposa ontem, entao vai ficar mais em conta de qualquer jeito trazer tudo pra cá.

Pegar o empresarial e vida que segue. 

Agradeço a indicação mesmo sem o Astra ainda.

[15:59] **+55 21 98102-9583:**
> _+55 62 9364-7674: Nah, andei pensando e aqui já pagamos 2 planos 20x e 4 planos PRO pro time. 

E eu ainda peguei o astra pra minha esposa ontem, entao vai ficar mais em conta de qualquer jeito trazer tudo pra cá.

Pegar o empresarial e vida que segue. 

Agradeço a indicação mesmo sem o Astra ainda._
Foi o que estávamos conversando, ainda mais que a liberação é por IP

[15:59] **+55 21 98102-9583:** Acho que pra rapaziada de vcs vai compensar demais

[15:59] **+55 62 9364-7674:** No caso seria uma assinatura por IP?

[16:00] **+55 62 9364-7674:** (A verdade é que ainda assim sai mais barato kkkkk)

[16:00] **+55 21 98102-9583:** Foi o que entendi, se eu tiver errado a galera vai me corrigir aí rapidinho na boa

[16:00] **+55 47 9966-5224:** Na assinatura vc consegue liberar mais de 1 IP

[16:00] **+55 12 99662-3545:** tracking real on

[16:00] **+55 47 9966-5224:** O enterprise é caso você tenha um fluxo mto alto de requisição

[16:00] **Jk Cli:** Pagando 25 reais a+

[16:00] **Jk Cli:** Na primeira compra

[16:01] **+55 21 98102-9583:**
> _Jk Cli: Pagando 25 reais a+_
Aí salga 🥲 hahahah

[16:01] **Jk Cli:** Mas é

[16:01] **Jk Cli:** Se eu liberar ip em tudo os cara faz serviço na minhas costas

[16:01] **Jk Cli:** Igual uns gringo fizeram aí

[16:01] **Jk Cli:** E olha que era ip único eim

[16:03] **+55 62 9364-7674:** Entao.

Minha assinatura eu preciso de:

Meu laptop 1
Meu laptop 2
Meu pc em casa.

Laptop do meu lider de marketing e vendas.

Laptop do meu sócio. 

Preciso pagar quanto a mais pra liberar isso? Queria usar na mesma conta se possivel. Tem como ajustar a fatura pelo site de vcs? 
Na hora do pagamento eu nao vi essa opcao

[16:03] **+55 62 9364-7674:** 6 locais diferentes

[16:03] **Jk Cli:**
> _+55 62 9364-7674: Entao.

Minha assinatura eu preciso de:

Meu laptop 1
Meu laptop 2
Meu pc em casa.

Laptop do meu lider de marketing e vendas.

Laptop do meu sócio. 

Preciso pagar quanto a mais pra liberar isso? Queria usar na mesma conta se possivel. Tem como ajustar a fatura pelo site de vcs? 
Na hora do pagamento eu nao vi essa opcao_
Recomendo empresarial

[16:03] **Jk Cli:** Vai por mim

[16:03] **Jk Cli:** Melhor

[16:03] **Jk Cli:** Já vamos adicionar esse plano

[16:03] **+55 21 98102-9583:** Uma dúvida, precisa da conta 20x?

[16:03] **+55 62 9364-7674:** Posso só pegar o empresarial que nao vou ter problema de logar os 6?

[16:04] **Jk Cli:**
> _+55 21 98102-9583: Uma dúvida, precisa da conta 20x?_
Não precisa

[16:04] **Jk Cli:**
> _+55 62 9364-7674: Posso só pegar o empresarial que nao vou ter problema de logar os 6?_
Nada no empresarial ,te damos + flexibilidade

[16:04] **+55 62 9364-7674:** Ok entao. Vou usar esse

[16:04] **Jk Cli:** Chama o @~João no pv

[16:09] **+55 21 98102-9583:** [Imagem] Só pra atualizar pra vcs... rumo aos 1kk 😂

[16:12] **Jk Cli:** Meu Deus

[16:12] **Jk Cli:** Kkkkkkkkkkkkkkkkk

[16:12] **+55 47 9966-5224:**
> _Jk Cli: Meu Deus_
Se eu quiser assinar pra conectar o pc em casa e o note no trabalho preciso pagar extra por conta do IP?

[16:19] **Jk Cli:** No empresarial te damos + flexibilidade

[16:19] **Jk Cli:** Sem ser empresarial e +25

[16:25] **+55 47 9966-5224:** Não preciso do empresarial agora, quero testar no Max pq minha demanda não é alta

[16:25] **+55 47 9966-5224:** Aí eu pago na assinatura os 25 a mais? Como funciona?

[16:28] **Jk Cli:** Paga 25 reais A + na primeira assinatura por um 1 adicional

[16:28] **Jk Cli:** 1 ip

[16:29] **Jk Cli:**
> _+55 47 9966-5224: Não preciso do empresarial agora, quero testar no Max pq minha demanda não é alta_
Pega assinatura +1 ip adicional para você utilizar em dois lugares diferentes

[16:29] **Jk Cli:** Sem ser na mesma rede

[16:30] **+55 47 9966-5224:**
> _Jk Cli: Sem ser na mesma rede_
Uma dúvida, se eu configuro no meu note, mas eu vou utilizar em outro lugar, em viagem e tal…preciso liberar tbm? Como fica?

[16:39] **Jk Cli:**
> _+55 47 9966-5224: Uma dúvida, se eu configuro no meu note, mas eu vou utilizar em outro lugar, em viagem e tal…preciso liberar tbm? Como fica?_
E só excluir o ip que estava logado adicionar o ip onde você está

[17:01] **+55 47 9966-5224:** Ah blzz

[17:40] **Você:** _Mensagem apagada_

[17:40] **Você:** _Mensagem apagada_

[17:51] **+55 99 8487-3868:** [Imagem] BOA TARDE DEVS! Como funciona? Algum admin pode me dar mais detalhes sobre o novo plano?

[17:53] **+55 47 9618-4437:**
> _+55 99 8487-3868: Imagem: BOA TARDE DEVS! Como funciona? Algum admin pode me dar mais detalhes sobre o novo plano?_
Maxima velocidade, prioridade nas filas nas horas de pico, 1000 requisições por minutos permitida e revenda/Proxy em cima do serviço autorizada sem banimento e até 50 ips simultâneos na mesma chave, suporte prioritário

[17:54] **Jk Cli:**
> _+55 99 8487-3868: Imagem: BOA TARDE DEVS! Como funciona? Algum admin pode me dar mais detalhes sobre o novo plano?_
Esse é o plano + top que temos

[17:54] **Jk Cli:** E a gt3 rs

[17:54] **Jk Cli:** Kkkkk

[17:54] **Jk Cli:** Linha premium da ghost

[17:55] **Jk Cli:**
> _+55 99 8487-3868: Imagem: BOA TARDE DEVS! Como funciona? Algum admin pode me dar mais detalhes sobre o novo plano?_
50 ips 👻👻👻👻

[17:55] **+55 99 8487-3868:**
> _+55 47 9618-4437: Maxima velocidade, prioridade nas filas nas horas de pico, 1000 requisições por minutos permitida e revenda/Proxy em cima do serviço autorizada sem banimento e até 50 ips simultâneos na mesma chave, suporte prioritário_
Tenho interesse sobre a revenda, eu posso gerar ips? tipo isso?

[17:56] **+55 47 9618-4437:**
> _+55 99 8487-3868: Tenho interesse sobre a revenda, eu posso gerar ips? tipo isso?_
Pode liberar para usar até 50 ips simultâneos na mesma chave

[17:56] **+55 47 9618-4437:** E pra revender é permitido fazer uma Proxy em cima do serviço para sua própria gatewat

[17:56] **+55 47 9618-4437:** Sem banimento

[18:01] **+55 99 8487-3868:** Anteriormente eu imaginei o seguinte, vender acessos pagando R$25 por IP e o restante sendo lucro kkkk
Mais não implementei porque estou focando em outros projetos!

Mais provavelmente proximo mes ja pegarei nesse plano novo

[18:02] **+55 47 9966-5224:**
> _+55 99 8487-3868: Anteriormente eu imaginei o seguinte, vender acessos pagando R$25 por IP e o restante sendo lucro kkkk
Mais não implementei porque estou focando em outros projetos!

Mais provavelmente proximo mes ja pegarei nesse plano novo_
25,00 pra IP adicional é só nos primeiros 30 dias. Depois se quiser continuar paga mensalidade cheia

[18:04] **+55 99 8487-3868:**
> _+55 47 9966-5224: 25,00 pra IP adicional é só nos primeiros 30 dias. Depois se quiser continuar paga mensalidade cheia_
Via discord fui informado que ao pagar R$25 no ip adcional eu não precisaria mais pagar pelo IP nas proximas mensalidades.
Fui informado sobre isso quando iniciei

[18:06] **+55 47 9966-5224:**
> _+55 99 8487-3868: Via discord fui informado que ao pagar R$25 no ip adcional eu não precisaria mais pagar pelo IP nas proximas mensalidades.
Fui informado sobre isso quando iniciei_
Me informaram diferente

[18:07] **+55 47 9966-5224:** [Figurinha]

[18:07] **Jk Cli:** 25 reais e dps paga assinatura normal

[18:07] **Jk Cli:** No prx mês

[18:07] **Jk Cli:**
> _+55 99 8487-3868: Via discord fui informado que ao pagar R$25 no ip adcional eu não precisaria mais pagar pelo IP nas proximas mensalidades.
Fui informado sobre isso quando iniciei_
Quem informou ?

[18:08] **Jk Cli:** Mas se você quer muito ip

[18:08] **Jk Cli:** Empresarial tá aí

[18:08] **Jk Cli:** ☺️☺️

[18:09] **+55 99 8487-3868:**
> _Jk Cli: Quem informou ?_
Quando iniciei não tinha esse plano, acho que é algo recente.
Foi um dos responsaveis que me atenderam no ticket la

[18:09] **Jk Cli:** Ah sim

[18:09] **Jk Cli:** Ta tudo bem

[18:33] **+55 62 9444-5039:** podia meter logo o astra, to tendo que assinar 2 contas do gpt a mais pra usar no codex conectado com mcp no blender kkkkkkk

[18:34] **+55 47 9618-4437:** Astra vai ser adicionado no plano Enterprise nós próximos dias

[18:34] **+55 47 9618-4437:** Estamos tentando conseguir o licenciamento

[18:35] **+55 62 9444-5039:**
> _+55 47 9618-4437: Astra vai ser adicionado no plano Enterprise nós próximos dias_
já sabe o $ da brincadeira pra gente ? klkkk

[18:35] **+55 62 9444-5039:** vou orar todo dia pra ser rapido

[18:41] **+55 47 9618-4437:**
> _+55 62 9444-5039: já sabe o $ da brincadeira pra gente ? klkkk_
Já tá la no site

[18:41] **+55 47 9618-4437:** [Imagem]

[18:42] **+57 304 3533218:** Olá equipe, tenho algumas perguntas. Como podemos ter certeza de que os modelos que vocês oferecem são realmente do Claude?

[18:42] **+57 304 3533218:** Existe alguma maneira de medir isso?

[18:43] **+55 62 9444-5039:**
> _+55 47 9618-4437: Já tá la no site_
Vi lá

[18:43] **+55 47 9618-4437:**
> _+57 304 3533218: Olá equipe, tenho algumas perguntas. Como podemos ter certeza de que os modelos que vocês oferecem são realmente do Claude?_
[Imagem]

[18:43] **+55 47 9618-4437:** [Imagem]

[18:45] **Jk Cli:**
> _+57 304 3533218: Olá equipe, tenho algumas perguntas. Como podemos ter certeza de que os modelos que vocês oferecem são realmente do Claude?_
Claro

[18:47] __+55 83 9105-0660 entraram usando o link de convite__

[18:47] **+55 83 9105-0660:** [Figurinha]

[18:47] **+55 83 9105-0660:** [Vídeo]

[18:49] **Jk Cli:**
> _+57 304 3533218: Olá equipe, tenho algumas perguntas. Como podemos ter certeza de que os modelos que vocês oferecem são realmente do Claude?_
.

[18:51] **+55 83 9105-0660:** Modelos comuns não efetuam tarefas complexas e pesadas por muito tempo, como DeepSeek, Kimi, não aguentam trabalho pesado e tarefas complexas, já a ghostcli providência os modelos oficiais de maneira terceirizada, basta adquirir e ver a qualidade por conta própria, vai te surpreender. E vale lembrar, é ilimitado

[18:52] **+55 83 9105-0660:** Você percebe a diferença principalmente pelos erros comuns que essas IAs fracas cometem, é escancarado.

[18:53] **+57 304 3533218:** A questão é que eu já uso o Claude, mas estou cansado das limitações. E queria saber se vou obter o mesmo desempenho ou algum tipo de quantização.

[18:53] **+55 83 9105-0660:** Com certeza vai obter o mesmo desempenho eu mesmo utilizo 30/40 cmds simultaneamente

[19:39] **+55 47 9966-5224:** Alguém que está usando no terminal?
Está usando com Fable 5?

[19:48] **@fortytwowill:**
> _+55 47 9966-5224: Alguém que está usando no terminal?
Está usando com Fable 5?_
Só uso cli, to usando com o OMP

[19:49] **+55 47 9618-4437:**
> _+55 47 9966-5224: Alguém que está usando no terminal?
Está usando com Fable 5?_
especifica o modelo na inicialização o claude

[19:49] **+55 47 9966-5224:**
> _@fortytwowill: Só uso cli, to usando com o OMP_
OMP?

[19:49] **+55 47 9966-5224:** No meu não aparece opção do Fable

[19:50] **+55 47 9618-4437:** exemplo claude --model claude-fable-5-1

[19:50] **+55 83 9105-0660:** Claude --model fable

[19:51] **+55 47 9966-5224:** Usando no terminal do Mac

[19:51] **+55 47 9966-5224:** Eu uso /model

[19:51] **+55 83 9105-0660:**
> _+55 83 9105-0660: Claude --model fable_
Inicia o Claude com essa função

[19:51] **+55 83 9105-0660:** Ele inicia com o modelo fable

[19:51] **+55 83 9105-0660:** O modelo fable ainda não está disponível pra alteração dentro do Claude

[19:52] **+55 83 9105-0660:** Mesma coisa o glm

[19:53] **+55 47 9966-5224:** Deu certo

[19:53] **+55 47 9966-5224:** Obrigado irmão

[19:53] **+55 83 9105-0660:** Claude --model z.ai/glm-5.3

[19:53] **+55 83 9105-0660:**
> _+55 47 9966-5224: Obrigado irmão_
[Figurinha]

[19:56] **Jk Cli:** Obg Carneiro

[19:56] **Jk Cli:** 🫡🫡🫡🫡💙

[19:56] **+55 87 8805-8510:** Pessoal
Existe alguns
Vídeos sobre o ghostcli para configuração e saber manusear ?

[19:56] **+55 83 9105-0660:**
> _Jk Cli: Obg Carneiro_
Tmjj

[19:56] **+55 87 8805-8510:** Tutoriais

[19:57] **+55 83 9105-0660:**
> _+55 87 8805-8510: Pessoal
Existe alguns
Vídeos sobre o ghostcli para configuração e saber manusear ?_
Você fala de configurações e agentes de skills?

[19:57] **+55 47 9618-4437:**
> _+55 87 8805-8510: Pessoal
Existe alguns
Vídeos sobre o ghostcli para configuração e saber manusear ?_
https://GhostCLI.dev/guia

[19:57] **+55 87 8805-8510:**
> _+55 83 9105-0660: Você fala de configurações e agentes de skills?_
Sim

[19:58] **+55 87 8805-8510:** Top

[19:58] **+55 87 8805-8510:** Eu ainda não fechei mais to muito propício a fechar o grupo
Aqui eh top

[20:01] **+55 83 9105-0660:** Vou te passar um site de skills que uso aq

[20:02] **+55 83 9105-0660:** HTTPS://skills.sh

[20:18] **@fortytwowill:**
> _+55 47 9966-5224: OMP?_
Oh my pi

[20:29] **+57 304 3533218:** Estou tendo dificuldades com o provedor; eles demoram muito para responder, ou às vezes simplesmente não respondem. Há alguma interrupção generalizada no serviço?

[20:29] **+55 54 9620-1797:** Eu vi aqui que o Fable da Ghost nao gera imagens, pelo menos não ate ante-ontem e gostaria de saber se há uma explicação para isso, ou ate mesmo se há uma previsão de implementar isso futuramente.

[20:40] **+55 62 9444-5039:**
> _+55 54 9620-1797: Eu vi aqui que o Fable da Ghost nao gera imagens, pelo menos não ate ante-ontem e gostaria de saber se há uma explicação para isso, ou ate mesmo se há uma previsão de implementar isso futuramente._
Mas a claude até aonde eu sei, n possui um modelo de geração de imagem

[20:41] **+55 47 9618-4437:**
> _+55 54 9620-1797: Eu vi aqui que o Fable da Ghost nao gera imagens, pelo menos não ate ante-ontem e gostaria de saber se há uma explicação para isso, ou ate mesmo se há uma previsão de implementar isso futuramente._
Modelos da Claude não gera imagem amigo

[20:43] **+55 54 9620-1797:** A

[20:43] **+55 54 9620-1797:** Caralho, nao sabia disso

[20:43] **+55 54 9620-1797:** Achei que todas geravam

[20:44] **+55 54 9620-1797:** Que estranho saber disso kkk, mas obrigado pela resposta.

[21:53] __+55 91 8744-7174 entraram usando o link de convite__

[22:57] **+55 62 9497-3773:**
> _@fortytwowill: Só uso cli, to usando com o OMP_
como esta usando com a api do ghostcli?

[23:00] **@fortytwowill:**
> _+55 62 9497-3773: como esta usando com a api do ghostcli?_
So adicionar a API

[23:01] **+55 91 8744-7174:** Boa noite!
Alguém usa com o OpenClaw?

[23:05] **+55 35 9946-8945:** [Imagem] Os meninos trabalhando

[23:05] **+57 304 3533218:**
> _+55 35 9946-8945: Imagem: Os meninos trabalhando_
Ultracode?

[23:12] **+55 35 9946-8945:** Sim

[23:13] **+55 62 9497-3773:**
> _@fortytwowill: So adicionar a API_
poise, mas nao achei como aqui

---

## 10 de setembro de 2026

[0:36] **@fortytwowill:**
> _+55 91 8744-7174: Boa noite!
Alguém usa com o OpenClaw?_
Uso no Hermes

[0:37] **@fortytwowill:**
> _+55 62 9497-3773: poise, mas nao achei como aqui_
Usa alguma outra LLM, da o endpoint e API e pede pra adicionar

[6:41] __+55 11 96664-6945 entraram usando o link de convite__

[6:50] __+55 22 98140-7236 entraram usando o link de convite__

[7:36] __+55 11 97614-4825 entraram usando o link de convite__

[7:37] **+55 11 97614-4825:** Ola, bom dia. Gostaria de saber mais sobre plano ilimitado para Fable 5.1

[7:38] **+55 83 9105-0660:**
> _+55 11 97614-4825: Ola, bom dia. Gostaria de saber mais sobre plano ilimitado para Fable 5.1_
É uso ilimitado mano bom demais

[7:38] **+55 83 9105-0660:** Uso o dia inteiro

[7:38] **+55 83 9105-0660:** [Figurinha]

[7:38] **+55 11 97614-4825:** Da para usar ele no co-work do app desktop? Ou só via api?

[7:39] **+55 11 97614-4825:** A chave é privada?

[7:39] **+55 83 9105-0660:** Cara eu só uso no terminal mal uso o chat

[7:39] **+55 83 9105-0660:**
> _+55 11 97614-4825: A chave é privada?_
É sim mn

[7:39] **+55 11 97614-4825:** Boa!

[7:39] **+55 83 9105-0660:** _Aguardando mensagem. Essa ação pode levar alguns instantes._

[7:40] **+55 11 97614-4825:** Obrigado! :)

[7:40] **+55 83 9105-0660:** Nada mano tamo aqui o dia inteiro pra ajudar

[7:41] **+55 11 97614-4825:** @~Daniel com quem eu falo aqui sobre o pagamento? Queria assinar

[7:41] **+55 83 9105-0660:** HTTPS://ghostcli.dev

[7:41] **+55 83 9105-0660:** Faz sua conta lá e assina aí lá libera

[7:50] **+55 22 98111-9467:** Apareceu um novo plano enterprise, o plano Max agora não é mais ilimitado?

[7:51] **+55 11 97614-4825:** Então aqui pra mim está cobrando em dolar, alguem tem o link para pagamento em cartão de credito em reais? quero o plano max

[7:53] **+55 83 9105-0660:**
> _+55 22 98111-9467: Apareceu um novo plano enterprise, o plano Max agora não é mais ilimitado?_
É sim, todos são, o enterprise é pra empresas que precisam colocar o serviço em várias máquinas

[7:53] **+55 83 9105-0660:**
> _+55 11 97614-4825: Então aqui pra mim está cobrando em dolar, alguem tem o link para pagamento em cartão de credito em reais? quero o plano max_
Volta pra página e troca a bandeirinha dos EUA pra o Brasil

[7:55] **+55 11 97614-4825:**
> _+55 83 9105-0660: Volta pra página e troca a bandeirinha dos EUA pra o Brasil_
Entao, eu troquei a bandeira, os textos ficam em português mas a cobrança continua em dólar

[7:57] **+55 11 97614-4825:** Diferença de valor é muito alta, em reais o Max com API está 189, na versão em dólar a conversão fica em  290 reais

[8:01] **+55 83 9105-0660:** @Jk Cli @~João o Tiago está com problemas no site

[8:04] **+55 11 97614-4825:** Ola @Jk Cli  @~João bom dia. Quando der podem me chamar? Queria fazer o pagamento do plano Max via cartão de crédito em reais.

[8:18] **+55 87 9128-0580:** Até onde eu sei não tem essa opção de cartão no BR

[8:38] **Jk Cli:** Sim n temos opção cartão disponível

[8:49] __+55 83 8782-8287 entraram usando o link de convite__

[8:58] **@ziadhatem:** is there Thinking Stream in anthropic models ?

[8:58] **@ziadhatem:** it's only in glm 5.3

[9:15] **+55 51 9425-4975:** Pq pela interface, tanto do claude quanto do codex, é muito mais instavel que pela cli? Quase n da pra usar de tão lento

[9:19] **Signor For Programming:**
> _@ziadhatem: it's only in glm 5.3_
I agree

[9:49] __+54 9 3834 53-1638 entraram usando o link de convite__

[10:58] __+55 63 9294-1384 entraram usando o link de convite__

[11:02] **+55 62 8152-0359:** Alguém tem extensão da Lovable ? 
Precisando urgente 🚨

[11:16] **+55 27 99694-0707:** _Mensagem apagada_

[11:39] __+55 67 8210-0717 entraram usando o link de convite__

[11:43] __+55 61 9148-6214 entraram usando o link de convite__

[11:46] **+55 91 9301-8410:**
> _+55 62 8152-0359: Alguém tem extensão da Lovable ? 
Precisando urgente 🚨_
Tenho recarga de créditos mano

[11:47] **Jk Cli:** Iai galera quantos tokens vcs ja usaram

[11:48] **Signor For Programming:** does any one need api usage , if admin agree that message we have api for production

[11:48] **Jk Cli:** 20
Milhões já

[11:48] **Jk Cli:** Vamo atualizar hoje quem é o top1 em uso

[11:52] **Jk Cli:** Cupom de primeira compra MAXPELOPRO @all

[11:52] **Jk Cli:** [Imagem] Marcha

[11:56] **Signor For Programming:**
> _Jk Cli: 20
Milhões já_
are u admin here ?

[11:56] **Jk Cli:** Yeah

[11:56] **+55 35 9946-8945:**
> _Jk Cli: Cupom de primeira compra MAXPELOPRO @all_
Vou criar outra conta

[11:56] **+55 35 9946-8945:** 😶‍🌫️

[11:58] **Signor For Programming:**
> _Jk Cli: Yeah_
lets talk private

[11:58] **Jk Cli:**
> _+55 35 9946-8945: Vou criar outra conta_
🤣🤣🤣🤣

[11:58] **+55 35 9946-8945:**
> _Jk Cli: 🤣🤣🤣🤣_
Bem na minha vez

[11:58] **+55 35 9946-8945:** Sempre assim

[11:58] **+55 35 9946-8945:** Libera pra gente aí que já tem

[11:58] **Jk Cli:** Já usou quantos tokens já

[11:59] **+55 35 9946-8945:**
> _Jk Cli: Já usou quantos tokens já_
Pouquinho 624M, tá dando economia de 32K

[11:59] **+55 35 9946-8945:** [Imagem] Só hj

[12:00] **Jk Cli:** ☠️☠️☠️

[12:00] **Jk Cli:** Meu Deus

[12:02] **+55 62 9364-7674:** [Imagem] usei assim

[12:02] **+55 62 9364-7674:** com x-api-key

[12:02] **+55 62 9364-7674:** e tb com bearer

[12:02] **+55 62 9364-7674:** e ambos nao estão dando certo

[12:02] **+55 62 9364-7674:** [Imagem]

[12:02] **+55 62 9364-7674:** aparece essa mensagem aqui para mim.

[12:02] **+55 62 9364-7674:** [Imagem] eu tb autorizei o ip

[12:02] **+55 62 9364-7674:** alguem pode me ajudar com isso?

[12:02] **Jk Cli:** Não é x

[12:03] **+55 62 9364-7674:** vou voltar pro bearer

[12:03] **+55 35 9946-8945:**
> _Jk Cli: ☠️☠️☠️_
Exatoo kkk moeu a noite toda, na próxima assinatura poderia vir com cupom em

[12:03] **+55 62 9364-7674:**
> _Jk Cli: Não é x_
mesmo erro com bearer

[12:04] **Jk Cli:** Opa

[12:04] **Jk Cli:** Já vamos te ajudar

[12:05] **+55 27 99694-0707:** _Mensagem apagada_

[12:05] **+55 27 99694-0707:** _Mensagem apagada_

[12:05] **+55 27 99694-0707:** _Mensagem apagada_

[12:06] **+55 27 99694-0707:** _Mensagem apagada_

[12:07] **+55 62 9364-7674:** [Vídeo]

[12:08] **+55 62 9364-7674:**
> _+55 27 99694-0707: Qual seu s.o_
S.O ?

[12:08] **+55 27 99694-0707:** _Mensagem apagada_

[12:08] **+55 62 9364-7674:** win 10

[12:09] **+55 27 99694-0707:** _Mensagem apagada_

[12:09] **+55 62 9364-7674:** sim, mas nao está ligada

[12:11] **+55 62 9364-7674:** só pra deixar informado tb, eu desliguei a vpn antes de validar o ip no site

[12:12] **+55 35 9946-8945:**
> _+55 62 9364-7674: Vídeo_
Te chamei no PV, o problema está no auth schema nas configurações

[12:20] **+55 83 8782-8287:** Boa tarde

[12:20] **+55 83 8782-8287:** É só no meu ou as requisições tipo “oi” demoram mais de 30s?

[12:21] **+55 35 9946-8945:**
> _+55 83 8782-8287: É só no meu ou as requisições tipo “oi” demoram mais de 30s?_
Funcionamento por chave de API precisa de refinamento

[12:27] **+55 62 9364-7674:** Bom, quando tiver alguma solucao me avise pf.

Estou com as minhas contas de 20x do claude ainda aqui, então nao tem problema. vou ir usando normal até que a minha conta da ghost funcione.

pf me da um @ quando resolver. obrigado

[12:29] **+55 47 9618-4437:**
> _+55 62 9364-7674: Imagem: usei assim_
Usa no base URL https://ghostcli.dev/v1

[12:30] **+55 62 9364-7674:** um momento que vou voltar pro outro computador

[12:31] **+55 62 9364-7674:** [Imagem] novo erro

[12:31] **+55 62 9364-7674:** [Imagem] como ficou

[12:32] **@ziadhatem:**
> _+55 62 9364-7674: Imagem: como ficou_
remove /v1

[12:45] __+55 11 94293-8475 entraram usando o link de convite__

[12:45] **+55 62 9364-7674:**
> _+55 47 9618-4437: Usa no base URL https://ghostcli.dev/v1_
aguardo suas orientações.

[12:52] **+55 62 9497-3773:** [Imagem] pode-se dizer que usei somente essa madrugada

[12:55] **+55 21 98102-9583:**
> _+55 62 9497-3773: Imagem: pode-se dizer que usei somente essa madrugada_
[Imagem] Achbo que somos do mesmo time então rs

[12:56] **+55 83 8782-8287:**
> _+55 35 9946-8945: Funcionamento por chave de API precisa de refinamento_
No caso preciso abrir chamado? Para o ajuste

[13:01] __+55 82 8737-4323 entraram usando o link de convite__

[13:06] **+55 62 9364-7674:**
> _+55 47 9618-4437: Usa no base URL https://ghostcli.dev/v1_
devo abrir um ticket no discord para resolver isso?

[13:06] **+55 35 9946-8945:**
> _+55 83 8782-8287: No caso preciso abrir chamado? Para o ajuste_
nn é configuração de vc e a IA

[13:07] **+55 35 9946-8945:** E assim 190 conta pra ver quanto tempo ela demora pra responder oi, é complicado

[13:09] **+55 35 9946-8945:**
> _+55 62 9364-7674: Bom, quando tiver alguma solucao me avise pf.

Estou com as minhas contas de 20x do claude ainda aqui, então nao tem problema. vou ir usando normal até que a minha conta da ghost funcione.

pf me da um @ quando resolver. obrigado_
Vai ser alguma configuração ai, aqui está funcionando normal, faz o teste pelo CLI

[13:12] **+55 62 9444-5039:**
> _+55 35 9946-8945: E assim 190 conta pra ver quanto tempo ela demora pra responder oi, é complicado_
Aqui funciona de boa amigo

[13:14] **+55 35 9946-8945:**
> _+55 62 9444-5039: Aqui funciona de boa amigo_
Sim sim, mas sla estranho kkk ficar medindo o que a IA pode fazer com Oi

[13:15] **+55 47 9618-4437:**
> _+55 35 9946-8945: Sim sim, mas sla estranho kkk ficar medindo o que a IA pode fazer com Oi_
Oque?

[13:15] **+55 51 9425-4975:** Acho que não é esse o ponto, medir um oi, mas que realmente ta lento

[13:15] **+55 47 9618-4437:** Tem que pensar que o modelo raciocínia antes de emitir a resposta

[13:15] **+55 47 9618-4437:** Dependendo do modelo pode várias ainda mais o tempo de resposta

[13:16] **+55 47 9618-4437:** E o plano Enterprise que lançamos tem prioridade na fila e máxima velocidade

[13:16] **+55 51 9425-4975:** Eu pedi uma atividade, que tava 21min processando, depois joguei a msm coisa com outros modelos que eu tenho, 2 min tava resolvido

[13:16] **+55 51 9425-4975:** N tem raciocínio que explique isso kkk

[13:17] **+55 62 9444-5039:**
> _+55 51 9425-4975: Eu pedi uma atividade, que tava 21min processando, depois joguei a msm coisa com outros modelos que eu tenho, 2 min tava resolvido_
Uai amigo, o Gemini responde super rápido, mas é uma bosta kkkk, tenta diminuir o nível de raciocínio

[13:17] **+57 304 3533218:**
> _+55 51 9425-4975: N tem raciocínio que explique isso kkk_
Talvez com o lançamento do plano Enterprise haja menos espaço para os outros planos.

[13:17] **+55 81 9398-4490:**
> _+55 51 9425-4975: Eu pedi uma atividade, que tava 21min processando, depois joguei a msm coisa com outros modelos que eu tenho, 2 min tava resolvido_
Foda mermo

[13:18] **+55 51 9425-4975:**
> _+55 62 9444-5039: Uai amigo, o Gemini responde super rápido, mas é uma bosta kkkk, tenta diminuir o nível de raciocínio_
Acredito que n seja isso, vários no gp e no discord sinalizando isso

[13:18] **+55 35 9946-8945:**
> _+55 47 9618-4437: Tem que pensar que o modelo raciocínia antes de emitir a resposta_
acho que algumas pessoas não sabem usar de fato IA... pq não em coisa que explique isso

[13:18] **+55 47 9618-4437:**
> _+55 35 9946-8945: acho que algumas pessoas não sabem usar de fato IA... pq não em coisa que explique isso_
Sim

[13:20] **Signor For Programming:**
> _+55 51 9425-4975: Acredito que n seja isso, vários no gp e no discord sinalizando isso_
yes it is correct , it is realy slow

[13:22] **+55 62 9497-3773:** para quem usa o claude code, funcionou de forma facil o uso do Fable5.1? no meu mesmo usando o claude --model claude-fable-5.1 ou add a env, continua sem funcionar

[13:23] **+55 47 9618-4437:**
> _+55 62 9497-3773: para quem usa o claude code, funcionou de forma facil o uso do Fable5.1? no meu mesmo usando o claude --model claude-fable-5.1 ou add a env, continua sem funcionar_
claude --model claude-fable-5-1

[13:23] **+55 51 9425-4975:**
> _+55 35 9946-8945: acho que algumas pessoas não sabem usar de fato IA... pq não em coisa que explique isso_
Não entendi

[13:24] **+55 62 9497-3773:** @~João então, coloquei ate na minha pergunta que usei e nao funcionou

[13:24] **+55 62 9497-3773:** [Imagem] tambem nem aparece aqui

[13:24] **+55 47 9618-4437:**
> _+55 62 9497-3773: @~João então, coloquei ate na minha pergunta que usei e nao funcionou_
Tá errado na pergunta

[13:24] **+55 47 9618-4437:**
> _+55 62 9497-3773: Imagem: tambem nem aparece aqui_
Tem que atualizar

[13:24] **+55 47 9618-4437:** O claude

[13:25] **+55 62 9497-3773:** hmm

[13:25] **+55 62 9497-3773:** vou ver aqui entao

[13:25] **+55 62 9497-3773:** engraçado que na documentaçao da ghost esta 5.1 e nao 5-1

[13:25] **+55 62 9497-3773:** vou testar aqui

[13:25] **+55 35 9946-8945:** Doc no site ta errado não?

[13:25] **+55 35 9946-8945:** no site ta 5.1 não 5-1

[13:25] **+55 62 9497-3773:** vlw @~João

[13:26] **+55 62 9497-3773:** pois é

[13:27] **+55 62 9497-3773:** e lembro que quando lançou aqui, deixaram claro que na api da ghost era com . e não -

[13:32] **+55 62 9497-3773:** deu certo com 5-1

[13:33] **+55 47 9618-4437:**
> _+55 35 9946-8945: Doc no site ta errado não?_
Sim

[13:44] **Jk Cli:**
> _+55 21 98102-9583: Imagem: Achbo que somos do mesmo time então rs_
😍😍

[13:44] **Jk Cli:** N estou respondendo agr pv direito que estou no almoço já vlt pro sup

[13:44] **Jk Cli:** 🙏

[14:49] **+55 48 9101-5225:**
> _+55 51 9425-4975: N tem raciocínio que explique isso kkk_
De fato a api do ghost é mais lenta

[14:49] **+55 48 9101-5225:** Mas é ilimitado

[14:49] **+55 48 9101-5225:** Nao existe almoço gratis ne pai

[14:52] __+55 32 8818-9440 entraram usando o link de convite__

[14:56] **+55 51 9425-4975:** To ligado, mas o pessoal fala como se fosse culpa do cara kkkkk

[14:57] **+55 35 9946-8945:**
> _+55 48 9101-5225: De fato a api do ghost é mais lenta_
Tenho o 20x e não fica muito atrás não, a empresa que trabalho, usamos o 20x

[14:57] **+55 35 9946-8945:** To defendo pq eu uso as 2 no meu dia a dia

[14:57] **+55 32 8818-9440:** Boa tarde pessoal, novo por aqui e já peço desculpas se tiver perguntabdo fora do contexto aqui 


Duvida e, tem limite de token no ghost?

Limite reset de tempos em tempos?

[14:57] **+55 35 9946-8945:**
> _+55 32 8818-9440: Boa tarde pessoal, novo por aqui e já peço desculpas se tiver perguntabdo fora do contexto aqui 


Duvida e, tem limite de token no ghost?

Limite reset de tempos em tempos?_
0 limite

[14:58] **+55 35 9946-8945:** So tem limite no ip, tem que ter sempre o mesmo ip de saida

[14:58] **+55 35 9946-8945:** Unico limite que existe

[14:58] **+55 32 8818-9440:** Entendi, mas conseguimos trocar caso provedor mude?

[14:59] **+55 35 9946-8945:**
> _+55 32 8818-9440: Entendi, mas conseguimos trocar caso provedor mude?_
SIm sim, por segurança sempre vai pedir um codigo no seu email

[14:59] **+55 35 9946-8945:** esse limite de IP é mais pra autenticação de fato que você é você de fato

[15:00] **+55 32 8818-9440:** usando um aqui mas ta foda

[15:01] **+55 35 9946-8945:** To usando em uns 5 projetos simultaneos e 2 maquinas na mesma rede

[15:04] **+57 304 3533218:**
> _+55 35 9946-8945: To usando em uns 5 projetos simultaneos e 2 maquinas na mesma rede_
É você quem está deixando o Ghost em modo lento para nós.

[15:04] **+57 304 3533218:** 😔

[15:08] **+55 35 9946-8945:**
> _+57 304 3533218: É você quem está deixando o Ghost em modo lento para nós._
kkkkkk acho que não em, os cara é brabo!

[15:09] **+57 304 3533218:**
> _+55 35 9946-8945: kkkkkk acho que não em, os cara é brabo!_
Tudo no máximo hahaha

[15:09] **+55 48 9101-5225:**
> _+55 35 9946-8945: Tenho o 20x e não fica muito atrás não, a empresa que trabalho, usamos o 20x_
Entao voce nao sabe usar amigo, ou teu 20x ta bugado

[15:10] **+55 35 9946-8945:**
> _+57 304 3533218: Tudo no máximo hahaha_
Ele ta escolhendo

[15:10] **+55 35 9946-8945:**
> _+55 48 9101-5225: Entao voce nao sabe usar amigo, ou teu 20x ta bugado_
Certeza que não sei usar, to aprendendo constantemente

[15:10] **+55 35 9946-8945:** E nem é meme

[15:11] **+55 48 9101-5225:** Ah ok, isso justifica ent, porq ele é muito rapido po

[15:11] **+55 48 9101-5225:** Inclusive to em 89% do semanal , e sem crises

[15:12] **+55 35 9946-8945:**
> _+55 48 9101-5225: Ah ok, isso justifica ent, porq ele é muito rapido po_
Quando comecei a usar o ghost, tava ruim, mas ai aprendi que quando falamos de acessos via api ele precisa de dados para levar para o modelo ficar bom, depois que treinei bastante ele, fiz memorias, ficou brabo

[15:12] **+55 35 9946-8945:** o 20x trabalha dentro do contexto da empresa

[15:12] **+55 48 9101-5225:** Mas é o contraponto né, tem token infinito, nao da de querer velocidade maxima

[15:12] **+55 48 9101-5225:** Pelo preco da assinatura normal

[15:13] **+55 35 9946-8945:** Sim sim

[15:45] **+55 32 8818-9440:** Então o ghost seria sem limite diario/semanal
sem reset

[15:45] **+55 32 8818-9440:** e funciona no vscode de boa?

[15:50] **+55 35 9946-8945:** Siim de boa

[16:04] __+55 21 99424-7321 entraram usando o link de convite__

[16:46] **Jk Cli:**
> _+55 32 8818-9440: Então o ghost seria sem limite diario/semanal
sem reset_
Dr é só usar e ser feliz

[17:14] __+55 11 95238-0283 entraram usando o link de convite__

[17:21] **+55 35 9946-8945:**
> _+55 32 8818-9440: Então o ghost seria sem limite diario/semanal
sem reset_
[Imagem]

[17:33] **+55 11 96654-2013:** Galera. Eu sou novo nisso. 
Uma dúvida. 
(Desculpe se parecer idiota a pergunta)

Mas qual a dif do ghost para o comum?
Eu uso o Claude pro lá no vscode. 

Oq isso mudaria pra mim ?

[17:34] **+55 87 9128-0580:**
> _+55 11 96654-2013: Galera. Eu sou novo nisso. 
Uma dúvida. 
(Desculpe se parecer idiota a pergunta)

Mas qual a dif do ghost para o comum?
Eu uso o Claude pro lá no vscode. 

Oq isso mudaria pra mim ?_
Ghost não sem limite

[17:34] **+55 87 9128-0580:** De horas

[17:34] **+55 87 9128-0580:** Sem de semana

[17:34] **+55 87 9128-0580:** Se você quiser colocar pra rodar 24/7

[17:34] **+55 87 9128-0580:** Você pode deixar

[17:35] **+55 11 96654-2013:** Certo. 
Como comecei a me aventurar agora nisso. 
Acho q n tenho tanta coisa que consuma tudo isso. 

Mas queria já começar a tentar algo mais pesado rs
Obg pela resposta

[17:35] **+55 11 96654-2013:** Aí eu conseguiria usar no meu projeto ?

[17:36] **+55 87 9128-0580:** [Mensagem de voz]

[17:46] **+55 84 9114-1337:** Boa tarde pessoal como eu saco a comissão ?

[17:46] **+55 84 9114-1337:** Fiz minha primeira venda ontem 🥹🥹🥹🥹

[17:55] **+55 47 9618-4437:**
> _+55 84 9114-1337: Boa tarde pessoal como eu saco a comissão ?_
Me chama no PV pra sacar

[17:59] **@fortytwowill:** Pq meus LLM metem um Portuguese do nada 🤣

[18:00] **@fortytwowill:** Devem estar compartilhando a memória

[18:14] **+55 35 9946-8945:**
> _@fortytwowill: Pq meus LLM metem um Portuguese do nada 🤣_
Tenho uma skill que eu mando em pt-br -> ingles, ia entende em ingles e retorna pra mim em pt-br

[18:17] **+55 11 96654-2013:**
> _+55 87 9128-0580: Mensagem de voz_
Show! Vou ver se assino então... Vou procurar um tutorial de vcs, aí vou assinar.

[18:25] **+55 48 9101-5225:**
> _+55 35 9946-8945: Tenho uma skill que eu mando em pt-br -> ingles, ia entende em ingles e retorna pra mim em pt-br_
Sabe q n precisa de skill pra isso ne ? Na pratica a ia ja faz isso sozinha

[18:26] **@fortytwowill:**
> _+55 35 9946-8945: Tenho uma skill que eu mando em pt-br -> ingles, ia entende em ingles e retorna pra mim em pt-br_
Os LLM devem estar compartilhando memória pq eu só do comando e só recebia em inglês 😅

[18:26] **+55 35 9946-8945:**
> _+55 48 9101-5225: Sabe q n precisa de skill pra isso ne ? Na pratica a ia ja faz isso sozinha_
É mesmo? Pq tem hora que retorna em pt-br? outras em ingles? Ou as vezes se pergunto em ingles retorno é melhor que se fosse pt-br?

[18:28] **+55 48 9101-5225:**
> _+55 35 9946-8945: É mesmo? Pq tem hora que retorna em pt-br? outras em ingles? Ou as vezes se pergunto em ingles retorno é melhor que se fosse pt-br?_
Se ta usando a api da ghost ta ai o motivo

[18:31] **+55 47 9618-4437:**
> _+55 35 9946-8945: É mesmo? Pq tem hora que retorna em pt-br? outras em ingles? Ou as vezes se pergunto em ingles retorno é melhor que se fosse pt-br?_
Ele sempre fala com o idioma falado inicialmente

[18:32] **+55 47 9618-4437:** [Imagem]

[18:34] **+55 21 98102-9583:**
> _+55 35 9946-8945: É mesmo? Pq tem hora que retorna em pt-br? outras em ingles? Ou as vezes se pergunto em ingles retorno é melhor que se fosse pt-br?_
Brother, eu achei que era culpa do ponytail, até desativei ele por isso

[18:34] **@fortytwowill:**
> _+55 48 9101-5225: Se ta usando a api da ghost ta ai o motivo_
A API vê mais português eu acho 😅

[18:34] **+55 21 98102-9583:** Também tá rolando comigo DIRETO, fico puto

[18:34] **+55 35 9946-8945:**
> _+55 48 9101-5225: Se ta usando a api da ghost ta ai o motivo_
nao é so ghost

[18:35] **+55 35 9946-8945:**
> _+55 21 98102-9583: Também tá rolando comigo DIRETO, fico puto_
Exatamente

[18:35] **@fortytwowill:**
> _+55 47 9618-4437: Ele sempre fala com o idioma falado inicialmente_
Eu só falo com llms em inglês

[18:35] **+55 35 9946-8945:** as skill que tinha no do serviço movi para o da ghost pra ficar igual

[18:37] **+55 21 98102-9583:**
> _@fortytwowill: Eu só falo com llms em inglês_
Meu cérebro já ferve o dia todo com a minha área, inviável trocar ideia em inglês rs

[18:38] **+55 35 9946-8945:**
> _+55 21 98102-9583: Meu cérebro já ferve o dia todo com a minha área, inviável trocar ideia em inglês rs_
Trabalha um dia com sustentação de empresa kkkk, vai ver o que é sofrer

[18:38] **+55 21 98102-9583:**
> _+55 35 9946-8945: Trabalha um dia com sustentação de empresa kkkk, vai ver o que é sofrer_
Trabalho com perícia contábil, pô 😂

[18:38] **+55 21 98102-9583:** Já me fodo muito, chega de me fuder mais. Já já mudo meu nome pra Elisa Sanches

[18:38] **+55 35 9946-8945:**
> _+55 21 98102-9583: Trabalho com perícia contábil, pô 😂_
KKKKK

[18:39] **+55 35 9946-8945:**
> _+55 21 98102-9583: Já me fodo muito, chega de me fuder mais. Já já mudo meu nome pra Elisa Sanches_
KKKKKKK

[18:39] **@fortytwowill:**
> _+55 21 98102-9583: Meu cérebro já ferve o dia todo com a minha área, inviável trocar ideia em inglês rs_
Eu moro no Canadá a 8 anos 😅

[18:41] **+55 21 98102-9583:**
> _@fortytwowill: Eu moro no Canadá a 8 anos 😅_
Ah caralho, então tu tá errado em falar em pt pô hahahahah

[18:41] **+55 21 98102-9583:** Pra vc faz sentido, pra mim seria queimar cérebro

[18:45] **+55 35 9946-8945:**
> _@fortytwowill: Eu moro no Canadá a 8 anos 😅_
Me leva junto, aqui no br da mais não

[18:47] **+55 22 98140-7236:**
> _+55 35 9946-8945: Me leva junto, aqui no br da mais não_
quiser adota uma criança de 30 anos, me leva também, uso chupeta e faço gluglu yeye

[18:47] **+55 35 9946-8945:** Sou mais novo e dev raiz

[18:48] **+55 22 98140-7236:**
> _+55 35 9946-8945: Sou mais novo e dev raiz_
ai, mais pro teu curriculo, fala que desenvolveu um app que vai pro futuro fez um filho e voltou pro passado, agora seu filho é mais velho que vc, vencemo, já chega lá trabalhando na apple

[18:50] **+55 21 98102-9583:**
> _+55 22 98140-7236: quiser adota uma criança de 30 anos, me leva também, uso chupeta e faço gluglu yeye_
Danadinho

[18:52] **+55 35 9946-8945:**
> _+55 22 98140-7236: ai, mais pro teu curriculo, fala que desenvolveu um app que vai pro futuro fez um filho e voltou pro passado, agora seu filho é mais velho que vc, vencemo, já chega lá trabalhando na apple_
O cara transcendeu

[19:04] **+55 54 9620-1797:** Uma duvida aqui galera, no meu Claude Code utilizando o Fable 5.1 eu percebi que se um chat está usando a internet pra fazer pesquisas na WEB e outro chat for tentar usar, ele trava e cai os 2, ou cai só um. Isso é normal no claude? Será que isso é do Gateway ou alguma configuração? No meu plano 20x do Codex eu consigo fazer isso com vários chats ao mesmo tempo.

[19:16] **@fortytwowill:**
> _+55 35 9946-8945: Me leva junto, aqui no br da mais não_
Agora só casando, a porta fechou

[19:41] __+1 (647) 335-0704 entraram usando o link de convite__

[20:38] __+55 27 99975-2212 entraram usando o link de convite__

[20:47] **+55 11 94307-4349:** tem algum suporte on?

[20:47] **Jk Cli:** Opa

[20:47] **Jk Cli:** Claro

[20:48] **Jk Cli:** Discord

[20:51] **@webgradee:** Hey is this real?

[20:58] **Jk Cli:** Yeahh

[20:58] **Jk Cli:** It’s real bro

[20:59] **@TomasDploy:**
> _Jk Cli: Imagem: Marcha_
Spanish support ?

[20:59] **Jk Cli:** [Mensagem de voz]

[21:00] **+55 11 94307-4349:** bri suporte no discord e assim que eu abri, fecharam kkkkk

[21:00] **+55 11 94307-4349:** alguém consegue me ajudar?

[21:00] **Jk Cli:** Opa

[21:00] **Jk Cli:** Abre lá dnv

[21:00] **Jk Cli:** Lá ele

[21:01] **+55 11 94307-4349:** po eu escrevi mó texto do caraio e perdi o texto

[21:04] **@webgradee:**
> _Jk Cli: It’s real bro_
Do we have any demo/trial for a week? 

Today I purchased cloude pro for 20 bucks. 

I would like to test it..

[21:05] **+55 12 99662-3545:** Real tracking on!

[21:05] **+55 12 99662-3545:** [Figurinha]

[21:06] **+55 13 98201-7087:** https://www.instagram.com/p/DdHIEK6lTK4/?stkn=MTExejBzZnpqMm51Yw==

[21:06] **+55 13 98201-7087:** E aí será que o MUSE vai superar o claude?

[21:06] **Jk Cli:** N sei

[21:07] **Jk Cli:** Claude ta com infra absurda de h100

[21:07] **Jk Cli:** E gb 200

[21:09] __+57 314 5070327 entraram usando o link de convite__

[21:30] **+55 11 96654-2013:** Para assinar, eu preciso ter algum plano do claude?
Estou na duvida de como instalar aqui.

[21:35] **+55 32 8818-9440:** Pessoal boa noite!
Contratei, to usando aqui mas tenho observado duas coisas!
1 - Muito lento
2 - Creio que deve ser alguma llm por trás, pois antes usando o claude aqui tava de boa, agora com essa ele não consegue o mesmo desempenho de implementação que tava o claude, faz muita coisa "errada"

alguma dica sobre esses pontos?

[21:43] **Jk Cli:**
> _+55 11 96654-2013: Para assinar, eu preciso ter algum plano do claude?
Estou na duvida de como instalar aqui._
No site em docs tem o vídeo

[21:43] **+55 11 96654-2013:** Ok, vou procurar, obg

[21:44] __Jk Cli adicionou +55 11 95194-1749__

[21:44] **Jk Cli:**
> _+55 32 8818-9440: Pessoal boa noite!
Contratei, to usando aqui mas tenho observado duas coisas!
1 - Muito lento
2 - Creio que deve ser alguma llm por trás, pois antes usando o claude aqui tava de boa, agora com essa ele não consegue o mesmo desempenho de implementação que tava o claude, faz muita coisa "errada"

alguma dica sobre esses pontos?_
Boa noite

[21:45] **+55 11 95194-1749:**
> _Jk Cli: Boa noite_
Comprei faz umas horas por enquanto está perfeito

[21:45] **+55 11 95194-1749:** Muito bom

[21:45] **+55 11 95194-1749:** Ótimo!

[21:45] **+55 32 8818-9440:**
> _Jk Cli: Boa noite_
boa noite

[21:45] **+55 11 95194-1749:** Peguei plano enterprise

[21:45] **+55 11 95194-1749:** Me sinto satisfeito ❤️ parabéns ao pessoal da ghost

[21:46] **+55 11 95194-1749:** Acredito que deve ser muito clientes   Por isso questão demora um pouco mas por aqui tá de boa

[21:48] **Jk Cli:**
> _+55 32 8818-9440: Pessoal boa noite!
Contratei, to usando aqui mas tenho observado duas coisas!
1 - Muito lento
2 - Creio que deve ser alguma llm por trás, pois antes usando o claude aqui tava de boa, agora com essa ele não consegue o mesmo desempenho de implementação que tava o claude, faz muita coisa "errada"

alguma dica sobre esses pontos?_
Cria ticket no discord e manda os prompts

[21:56] **+55 83 8798-9954:**
> _+55 32 8818-9440: Pessoal boa noite!
Contratei, to usando aqui mas tenho observado duas coisas!
1 - Muito lento
2 - Creio que deve ser alguma llm por trás, pois antes usando o claude aqui tava de boa, agora com essa ele não consegue o mesmo desempenho de implementação que tava o claude, faz muita coisa "errada"

alguma dica sobre esses pontos?_
aqui tbm, a velocidade melhora se tu usar no terminal, mas desempenho e resolução de problemas ta num nivel medio, isso se for outra llm. mas continua valendo a pena pra quem quer agentes pra fzr loop, usar subagentes com tasks repetitivas e que demoram bastante tempo

[21:57] **+55 47 9767-6672:** Alguem do suporte pode me ajudar? fui orientado a abri um ticket no discord, eu abri mas foi fechado sem a solução

[21:57] **Jk Cli:**
> _+55 47 9767-6672: Alguem do suporte pode me ajudar? fui orientado a abri um ticket no discord, eu abri mas foi fechado sem a solução_
Abra lá novamente

[22:39] **+55 11 94321-3342:** Vcs tem alguma assinatura diária ?

[22:40] **+55 47 9618-4437:**
> _+55 11 94321-3342: Vcs tem alguma assinatura diária ?_
Somente assinaturas mensais por enquanto

[22:40] **+55 11 96654-2013:** Não estou achando onde ensina a por no vs code, mas vou ver com calma amanha.
Não entendo mt, mas dps vejo com calma como fazer e pego o plano

[22:41] **+55 47 9618-4437:**
> _+55 11 96654-2013: Não estou achando onde ensina a por no vs code, mas vou ver com calma amanha.
Não entendo mt, mas dps vejo com calma como fazer e pego o plano_
É só baixar a extensão do Claude no vscode

[22:41] **+55 47 9618-4437:** Ou do roocde

[22:41] **+55 47 9618-4437:** Bem fácil

[22:41] **+55 11 96654-2013:** sim sim, eu ja uso la, digo pra trocar pelo ghost, pq eu tenho a assinatura pro do normal.

ai vou parar de pagar la pra assinar essa.

[22:43] **+55 47 9618-4437:**
> _+55 11 96654-2013: sim sim, eu ja uso la, digo pra trocar pelo ghost, pq eu tenho a assinatura pro do normal.

ai vou parar de pagar la pra assinar essa._
Só trocar a gateway

[22:43] **+55 47 9618-4437:** Tem tutorial no site

[22:46] **+55 83 8782-8287:** Acabei de pegar um plano personalizado com o @Jk Cli , cara totalmente transparente e realmente o cara é diferenciado o plano nao tem nem no site e é extremamente rapido, to gostando bastante paguei R$ 1.500!!

[22:48] **+55 12 99662-3545:** [Figurinha]

[22:50] **+55 54 9620-1797:**
> _+55 32 8818-9440: Pessoal boa noite!
Contratei, to usando aqui mas tenho observado duas coisas!
1 - Muito lento
2 - Creio que deve ser alguma llm por trás, pois antes usando o claude aqui tava de boa, agora com essa ele não consegue o mesmo desempenho de implementação que tava o claude, faz muita coisa "errada"

alguma dica sobre esses pontos?_
Sim, ele tem esse defeito ai. Eu estou criando uma 'IDE' e estou concentrando informações dentro dela para o meu foco que é desenvolver plugins e mods para os jogos.

Nao sei se vai dar certo, mas vou tentar. Mas um fato é que ela nao é igual ao original, tem alguma coisa ali que eu nao entendi oq é....

[22:58] **Jk Cli:** Obrigado pela confiança @~Rennyson Cavalcante

[22:58] **Jk Cli:** Plano personalizado

[22:58] **Jk Cli:** 🫡

[23:03] **+55 11 98099-6397:**
> _+55 32 8818-9440: Pessoal boa noite!
Contratei, to usando aqui mas tenho observado duas coisas!
1 - Muito lento
2 - Creio que deve ser alguma llm por trás, pois antes usando o claude aqui tava de boa, agora com essa ele não consegue o mesmo desempenho de implementação que tava o claude, faz muita coisa "errada"

alguma dica sobre esses pontos?_
Plano Enterprise entrega máxima velocidade possível e prioridade na fila de processamento se você está incomodado com velocidade na resposta, a velocidade da resposta é muito aceitável mesmos na assinaturas Pro e Max considerando que não tem limite nenhum de uso, e para um raciocínio melhor recomendo usar um effort maior que o High exemplo: Extra High ou MAX - Ultracode também

[23:05] **+55 32 8818-9440:**
> _+55 11 98099-6397: Plano Enterprise entrega máxima velocidade possível e prioridade na fila de processamento se você está incomodado com velocidade na resposta, a velocidade da resposta é muito aceitável mesmos na assinaturas Pro e Max considerando que não tem limite nenhum de uso, e para um raciocínio melhor recomendo usar um effort maior que o High exemplo: Extra High ou MAX - Ultracode também_
sim, mas ainda sim tenho encontrando algumas respostas meio sem contexto ou logica
o bom de programar e isso, vai validar a implementaçao e ta igual meus codigos em epoca de faculdade kkk

[23:06] **+55 11 94321-3342:**
> _+55 47 9618-4437: Somente assinaturas mensais por enquanto_
[Mensagem de voz]

[23:45] __+55 19 98416-9825 entraram usando o link de convite__

[23:46] **+55 19 98416-9825:** Boa noite galera, essa API é confiável?

[23:46] **+55 19 98416-9825:** [Figurinha]

[23:47] **+55 11 95194-1749:** Muito

[23:47] **+55 11 95194-1749:** To com enterprise aqui

[23:48] **+55 11 95194-1749:** Feliz da vida

[23:48] **+55 11 95194-1749:** Amo esses caras

[23:48] **+55 11 95194-1749:** Lá ele

[23:48] **+55 11 95194-1749:** Obrigado ghost por existir @~João @Jk Cli

[23:48] **@fortytwowill:** [Figurinha]

[23:48] **+55 11 96654-2013:** Fiz alguma cagada no vscode tentando trocar. agora todo comando que envio vem essa msg
Prompt is too long · automatic compaction failed: Failed to authenticate. API Error: 401 Invalid or revoked API key

vou tentar descobrir aqui

[23:49] **+55 11 95194-1749:** Chama os cara no pv

[23:49] **+55 11 96654-2013:** sim, chamei, com ctz fiz merda hahaha

[23:49] **+55 11 95194-1749:**
> _+55 19 98416-9825: Boa noite galera, essa API é confiável?_
E top

[23:51] **+55 83 8782-8287:**
> _+55 19 98416-9825: Boa noite galera, essa API é confiável?_
Excelente

[23:51] **+55 83 8782-8287:** Acabei de assinar o plano personalizado

[23:51] **+55 11 95194-1749:**
> _+55 83 8782-8287: Acabei de assinar o plano personalizado_
Qual ?

[23:51] **+55 11 95194-1749:** Fiquei sabendo que eles vão trazer gpt 6 Astra

[23:56] **+55 19 98416-9825:** Top rapaziada, e assinatura é segregada né? 


Eu pago por cada AI ou a assinatura é um conjunto de APIs de diferentes IAs pra usar (Claude, GPT, Gemini, etc)?

[23:56] **+55 83 8782-8287:**
> _+55 11 95194-1749: Qual ?_
Não tem no catálogo, foi que eu solicitei algumas coisas a mais para o @Jk Cli e ele super atendeu

---

## 11 de setembro de 2026

[0:12] **+55 11 95194-1749:**
> _+55 19 98416-9825: Top rapaziada, e assinatura é segregada né? 


Eu pago por cada AI ou a assinatura é um conjunto de APIs de diferentes IAs pra usar (Claude, GPT, Gemini, etc)?_
Não é api segredada

[0:12] **+55 11 95194-1749:** E você e sua chave key privada

[0:13] **+55 11 95194-1749:** Não tem nada de compartilhamento

[0:13] **+55 11 95194-1749:** Complice dos caras e top

[0:21] **+55 98 8536-3798:** Contratei, começar a testar

[0:22] **+55 11 95194-1749:** Compensa muito

[0:22] **+55 11 96654-2013:** Mt obg pelo suporte @Jk Cli

[0:23] **Jk Cli:** Por nada 🫡☺️🙏

[0:23] **Jk Cli:** Sempre

[9:01] **+55 27 99694-0707:** _Mensagem apagada_

[9:01] **+55 27 99694-0707:** _Mensagem apagada_

[9:01] **+55 27 99694-0707:** _Mensagem apagada_

[9:01] **+55 11 95194-1749:** Opa

[9:01] **+55 27 99694-0707:** _Mensagem apagada_

[9:01] **@webgradee:** Guys can we talk in english?

[9:01] **+55 27 99694-0707:** _Mensagem apagada_

[9:01] **@webgradee:** Do we have any demo/trial for a week? 

Today I purchased cloude pro for 20 bucks. 

I would like to test it..

[9:01] **+55 27 99694-0707:** _Mensagem apagada_

[9:02] **+55 27 99694-0707:** _Mensagem apagada_

[9:02] **+55 27 99694-0707:** _Mensagem apagada_

[9:03] **+55 27 99694-0707:** _Mensagem apagada_

[9:04] **+55 27 99694-0707:** _Mensagem apagada_

[9:32] **+55 21 98102-9583:**
> _+55 27 99694-0707: fabio ou claudio_
Apoio

[9:40] __+55 51 8115-5575 entraram usando o link de convite__

[9:41] **+55 51 8115-5575:** Ola

[9:48] **+55 62 9364-7674:** [Imagem] Bom dia, 

se eu uso o mesmo laptop em dois lugares diferentes a única saída é eu ficar trocando a chave?

[9:50] **+55 51 8115-5575:** A API que vcs usam é oficial?

[9:50] **+55 51 8115-5575:** Vou conseguir colocar plugins, habilidades e conectores?

[9:52] **+55 11 95194-1749:**
> _+55 62 9364-7674: Imagem: Bom dia, 

se eu uso o mesmo laptop em dois lugares diferentes a única saída é eu ficar trocando a chave?_
Sim se n tem ip adicional

[9:52] **+55 11 95194-1749:** Tem que autorizar ip

[9:52] **+55 11 95194-1749:** Agr no enterprise n me preocupo tanto com isso

[9:57] **+55 62 9364-7674:** opa, eu sou enterprise lá.

[9:57] **+55 62 9364-7674:** como faria para nao ter que ficar trocando de chave?

[9:58] **+55 11 95194-1749:** Autorizar ip

[9:58] **+55 11 95194-1749:** De todos

[9:58] **+55 62 9364-7674:** ah, dai a mesma chave funcionaria em varios ips né. entendi. vou lá

[9:59] **+55 11 95194-1749:** Sim e isso que eu faço

[9:59] **+55 11 95194-1749:** Ai é top

[10:03] **+55 62 9364-7674:** [Imagem] fui testar e quase nao foi. mas de fato ele me respondeu no ip novo. obrigado.

[10:04] **+55 51 8115-5575:** Claude Cowork está com problema no windons depois da atualização do dia 8

[10:04] **+55 51 8115-5575:** Está dando bug

[10:05] **+55 51 8115-5575:** Microsoft está para liberar uma atualização

[10:07] **+55 11 96654-2013:** Isso de autorizar IP tem que fazer toda hora ?
Ou só qd ele para ?

[10:08] **+55 11 95194-1749:** Eu só faço isso quando para aqui

[10:10] **+55 47 9116-0751:**
> _@webgradee: Do we have any demo/trial for a week? 

Today I purchased cloude pro for 20 bucks. 

I would like to test it.._
We don’t have trial, but you can test it for 7 days and cancel anytime

[10:26] **+55 35 9946-8945:** Alguém tem alguma extensão pra conectar API de terceiros pra usar igual o Claude faz?

[10:26] **+55 35 9946-8945:** Extensão de browser

[10:42] **+55 98 8536-3798:** [Imagem]

[10:44] **+55 15 99700-3605:** bom dia! vi no site que o ASTRA ja esta disponivel para o plano MAX (que é oq assino)

mas qdo a gente chama o endpoint, o modelo n aparece.... alguem mais testou?

[10:44] **+55 15 99700-3605:** [Imagem]

[10:45] **+55 15 99700-3605:** mas qdo chama pela api, n retorna ele

[10:48] **Jk Cli:**
> _+55 15 99700-3605: bom dia! vi no site que o ASTRA ja esta disponivel para o plano MAX (que é oq assino)

mas qdo a gente chama o endpoint, o modelo n aparece.... alguem mais testou?_
Só no enterprise

[10:48] **Jk Cli:** Vai estar

[10:50] **+55 15 99700-3605:** ué... então pq la ta associado ao plano MAX?
ou no momento é so enterprise e logo vai estar no MAX?

[10:51] **Jk Cli:** Acredito que ele vai ver isso

[10:52] **+55 98 8536-3798:** Adiciona o 5.6 sol pra gente do MAX rsrsrsrs

[10:59] **+55 62 9444-5039:**
> _+55 15 99700-3605: bom dia! vi no site que o ASTRA ja esta disponivel para o plano MAX (que é oq assino)

mas qdo a gente chama o endpoint, o modelo n aparece.... alguem mais testou?_
Me iludi aqui achando q tinha no max 🥲

[10:59] **+55 15 99700-3605:** de acordo com o site o modelo entra no MAX... anuncio ta feito

[12:10] __+55 88 9490-6319 entraram usando o link de convite__

[12:11] **+55 88 9490-6319:** Bom dia, qual contato pra suporte pessoal?

[12:23] **+55 15 99700-3605:** _Mensagem apagada por um admin (+55 47 9618-4437)_

[12:24] **+55 15 99700-3605:** _Mensagem apagada por um admin (+55 47 9618-4437)_

[12:24] **+55 47 9618-4437:**
> _+55 88 9490-6319: Bom dia, qual contato pra suporte pessoal?_
Pv

[12:34] __+55 47 9618-4437 removeu +55 15 99700-3605__

[12:48] __+55 55 9186-0674 entraram usando o link de convite__

[12:59] __+55 47 9618-4437 removeu +55 32 8818-9440__

[13:11] **+55 11 95194-1749:** Qualidade aqui tá top

[13:11] **+55 11 95194-1749:** Usava outro aqui está bem melhor

[13:14] **+57 304 3533218:**
> _+55 11 95194-1749: Usava outro aqui está bem melhor_
Do que você está falando?

[13:15] **+55 11 95194-1749:**
> _+57 304 3533218: Do que você está falando?_
To falando dos tokens da ghost que são muito bons

[13:15] **+55 11 95194-1749:** Já caí em vários  anúncios aí que Claude duvidosos

[13:15] **+55 11 95194-1749:** Da ghost ta me servindo muito bem 💙

[13:16] **+57 304 3533218:**
> _+55 11 95194-1749: Da ghost ta me servindo muito bem 💙_
Com certeza, sim. O único problema que encontrei foi com a velocidade; às vezes, pode demorar vários minutos para responder.

[13:16] **+55 11 95194-1749:**
> _+57 304 3533218: Com certeza, sim. O único problema que encontrei foi com a velocidade; às vezes, pode demorar vários minutos para responder._
Por aqui tá de boa mas acredito que eles vão fazer algum update sobre isso

[13:16] **+55 11 95194-1749:** São muitos clientes tbm

[13:17] **+55 11 95194-1749:** Eu percebi isso

[13:17] **+55 11 95194-1749:** Mas na questão da qualidade de resolver no código tá absurdo

[13:17] **+55 11 95194-1749:** Muito bom

[13:17] **+55 11 95194-1749:** Eu usava um que era muito rápido so que era burro ou seja n adiantava muita coisa não

[13:18] **+57 304 3533218:**
> _+55 11 95194-1749: Mas na questão da qualidade de resolver no código tá absurdo_
Qual modelo você está usando e com que nível de esforço?

[13:19] **+55 11 95194-1749:** Fable 5.1

[13:20] **+55 11 95194-1749:** No ultra

[13:21] **+55 69 7400-7880:** A api usa modelos codex tbm? Ou só claude?

[13:22] **+55 11 95194-1749:** Só no claude

[13:22] **+55 47 9618-4437:**
> _+55 69 7400-7880: A api usa modelos codex tbm? Ou só claude?_
GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc

[13:22] **+55 11 95194-1749:**
> _+55 47 9618-4437: GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc_
Amo vcs

[13:22] **+55 11 95194-1749:** 💙💙💙💙💙💙💙

[13:23] **+55 51 9425-4975:**
> _+55 47 9618-4437: GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc_
Lança pro max tbm 😔

[13:23] **Jk Cli:**
> _+55 47 9618-4437: GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc_
👀👀

[13:24] **+55 11 95194-1749:**
> _+55 47 9618-4437: GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc_
Ainda bem que já garanti o meu enterprise

[13:24] **+55 11 95194-1749:** Kkkk

[13:24] **+55 11 95194-1749:** To ansioso

[13:32] **+55 62 9364-7674:**
> _+55 47 9618-4437: GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc_
@~Claudio Guimarães

[13:35] **@ziadhatem:**
> _+55 47 9618-4437: GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc_
when will be available for max ?

[13:38] **+55 11 95194-1749:**
> _@ziadhatem: when will be available for max ?_
From what I saw, it was only on the business plan, but I'm going to wait for more updates.

[13:38] **@ziadhatem:**
> _+55 11 95194-1749: From what I saw, it was only on the business plan, but I'm going to wait for more updates._
I'm subscribed to max before enterprise even available can they make exception for us ?

[13:40] **+55 11 95194-1749:** I’m not sure yet.it depends on them. My plan is the business-oriented one because it’s really worth it; the value for money is excellent. Ghost saved me about $2,000.

[13:41] **@ziadhatem:**
> _+55 11 95194-1749: I’m not sure yet.it depends on them. My plan is the business-oriented one because it’s really worth it; the value for money is excellent. Ghost saved me about $2,000._
yes Ghost CLI is GOAT

[13:42] **+55 11 95194-1749:** Yeah bro the Goat

[13:42] **+55 11 95194-1749:** By Brazil

[13:42] **+55 11 95194-1749:** 💙💙💙👻

[13:43] **+55 11 94321-3342:** Alguém que trabalha com recargas lovable ?

[13:44] **Signor For Programming:** Is astra available on enterprise ?

[13:44] **+55 11 95194-1749:**
> _Signor For Programming: Is astra available on enterprise ?_
Yes

[13:44] **Signor For Programming:** Realy !

[13:45] **Signor For Programming:** When it released ?

[13:50] **+55 54 9658-5317:**
> _+55 47 9618-4437: GPT-6 Astra lançará hoje no plano enterprise, só está em fase de teste e será liberado nas próximas horas. Máxima velocidade, capacidade da Ghost etc_
Bah q top aí sim

[13:51] **+55 54 9620-1797:** Coisa boa

[13:52] **Signor For Programming:** So it is not available yet

[14:21] **+55 63 9294-1384:** Boa tarde, uma dúvida.

Essa assinatura funciona com uma chave API para uso dentro da IDE de preferência é isso?

[15:08] **+55 55 9186-0674:** Da pra usar o Claude cowork?

[15:08] **+55 47 9618-4437:**
> _+55 55 9186-0674: Da pra usar o Claude cowork?_
sim

[15:08] **+55 47 9618-4437:**
> _+55 63 9294-1384: Boa tarde, uma dúvida.

Essa assinatura funciona com uma chave API para uso dentro da IDE de preferência é isso?_
isso

[15:37] **+55 22 98111-9467:** Pessoal... Dando um erro 
API Error: 400 inválido JSON

[15:37] **+55 22 98111-9467:** Alguém sabe o que é isso?

[15:37] **+55 51 9425-4975:** Sim

[15:38] **+55 51 9425-4975:** O claude retorna ```json

[15:38] **+55 51 9425-4975:** Essas "aspas" bugan

[15:38] **+55 51 9425-4975:** tem que padronizar um output format

[15:43] **+55 22 98111-9467:** Tava funcionado até a hora do almoço

[15:43] **+55 22 98111-9467:** Agora sumiu o Fable e dando esse erro

[15:43] **+55 22 98111-9467:** Sabe como resolvo?

[15:43] **Jk Cli:** Opa

[15:43] **Jk Cli:** Cria ticket

[15:43] **+55 47 9618-4437:**
> _+55 22 98111-9467: Sabe como resolvo?_
seu chat ta quebrado, abre um novo

[15:49] __+55 61 9273-2024 entraram usando o link de convite__

[15:49] **+55 61 9273-2024:** Boa tarde, pessoal! Tudo bem?

[15:49] **+55 61 9273-2024:** Tô querendo pegar. Roda no app do Claude Code, mesmo? Codex também? Já tem o gpt 6 astra?

[15:51] **+55 22 98111-9467:**
> _+55 47 9618-4437: seu chat ta quebrado, abre um novo_
Já fiz isso... E não aparece o Fable mais

[15:51] **+55 47 9618-4437:**
> _+55 22 98111-9467: Já fiz isso... E não aparece o Fable mais_
claude --model claude-fable-5-1

[15:51] **+55 47 9618-4437:** da esse comando

[15:51] **+55 47 9618-4437:** que vai usar o fable

[15:52] **+55 11 95194-1749:**
> _+55 61 9273-2024: Tô querendo pegar. Roda no app do Claude Code, mesmo? Codex também? Já tem o gpt 6 astra?_
Mano peguei melhor plano deles ta compensando muito

[15:52] **+55 47 9618-4437:**
> _+55 61 9273-2024: Tô querendo pegar. Roda no app do Claude Code, mesmo? Codex também? Já tem o gpt 6 astra?_
sim funciona no claude code e codex, sera adicionado o gpt-6 astra ainda hoje no plano enterprise

[15:53] **+55 61 9273-2024:** Somente no Enterprise?

[15:53] **+55 61 9273-2024:** Tô usando o gpt do plano pro de 525 reais e tá foda os tokens no gpt 6 astra...

[15:54] **+55 62 8630-8180:**
> _+55 61 9273-2024: Tô usando o gpt do plano pro de 525 reais e tá foda os tokens no gpt 6 astra..._
Nem no 5x aguenta?

[15:54] **+55 62 8630-8180:** To pensando em pegar o 20x

[15:54] **+55 61 9273-2024:**
> _+55 62 8630-8180: Nem no 5x aguenta?_
No gpt 6 astta

[15:54] **+55 61 9273-2024:** Astra

[15:54] **+55 61 9273-2024:** Dependendo do uso, vai muito rápido

[15:54] **+55 61 9273-2024:** Como sou dev solo no meu trampo, o Codex ajuda muito

[15:55] **+55 62 8630-8180:** Hmmmmm

[15:55] **+55 61 9273-2024:** A sorte que dou é que tá tendo atualização e as atualizações resetam meu limite

[16:00] **Jk Cli:** Vamos trazer gpt 6 Astra em breve

[16:01] **+55 47 9618-4437:**
> _Jk Cli: Vamos trazer gpt 6 Astra em breve_
hoje

[16:20] **+55 21 98102-9583:** [Imagem] fizeram alguma manutenção, pessoal? Do nada veio o pedido de login e tá dando erro

[16:39] **+55 98 8536-3798:**
> _+55 11 94321-3342: Alguém que trabalha com recargas lovable ?_
Caiu de novo já

[16:40] **+55 98 8536-3798:**
> _+55 61 9273-2024: Tô usando o gpt do plano pro de 525 reais e tá foda os tokens no gpt 6 astra..._
Ontem fui usar, atingiu a cota semanal rápido demais, tive que acionar um dos resets disponíveis de cota pra poder continuar usando

[16:55] **+55 88 9490-6319:**
> _Jk Cli: Vamos trazer gpt 6 Astra em breve_
Pra ter acesso vai ser outra compra ?

[16:58] **Jk Cli:** Quem é enterprise ou plano personalizado será adicionado já o gpt 6

[16:59] **+55 61 9273-2024:** Tem plano somente desse gpt 6?

[17:03] **+55 62 9444-5039:**
> _+55 61 9273-2024: Tem plano somente desse gpt 6?_
Seria uma boa msm

[17:33] __+55 43 9106-8122 entraram usando o link de convite__

[17:45] **+55 54 9620-1797:** To ansioso pra esse GPT 6... Se funcionar como funciona no Codex eu pago 3k/mes

[17:45] **+55 54 9620-1797:** Sem dó

[17:46] **+55 11 95194-1749:** 👀👀👀👀👀

[17:46] **+55 11 95194-1749:** Slk

[17:46] **+55 11 95194-1749:** To doido já

[17:46] **+55 54 9620-1797:** Porra eu tambem

[17:46] **+55 54 9620-1797:** Vsf

[17:47] **+55 54 9620-1797:** Lança logo essa bomba

[17:57] **+55 11 95194-1749:** E bom pegar enterprise logo

[17:59] **+55 88 9490-6319:** Eu peguei hj o plano Max, quando chegar o gpt 6, vai tá incluso ou pagar outro plano?? @~João

[18:00] **+55 51 8115-5575:** Consigo usar no Claude desktop?

[18:00] **+55 51 8115-5575:** Cowork?

[18:00] **+55 54 9620-1797:** Cowork pra mim nao funcionou

[18:00] **+55 54 9620-1797:** Bem burro

[18:00] **+55 54 9620-1797:** No code ja é melhor

[18:00] **+55 54 9620-1797:** Mas ainda é esquisito

[18:00] **+55 54 9620-1797:** Se esse gpt 6 vim monstro

[18:00] **+55 54 9620-1797:** Nossa

[18:01] **+55 51 8115-5575:** Api não é oficial então

[18:01] **+55 51 8115-5575:** [Figurinha]

[18:01] **+55 51 8115-5575:** Pra q serve então? Kkkk chat

[18:01] **+55 69 7400-7880:**
> _+55 88 9490-6319: Eu peguei hj o plano Max, quando chegar o gpt 6, vai tá incluso ou pagar outro plano?? @~João_
O 6 seria no enterprise

[18:02] **+55 11 95194-1749:**
> _+55 51 8115-5575: Api não é oficial então_
Só se for vozes da tua cabeça

[18:02] **+55 88 9490-6319:**
> _+55 69 7400-7880: O 6 seria no enterprise_
[Figurinha]

[18:02] **+55 11 95194-1749:** E n pow o cara faz teste de token

[18:02] **+55 51 8115-5575:** _Mensagem apagada por um admin (Jk Cli)_

[18:03] **+55 54 9620-1797:** Tipo, funciona

[18:03] **+55 54 9620-1797:** Mas se voce perguntar a mesma coisa em ambos

[18:03] **+55 11 95194-1749:** Tenho 6 contas do Claude aqui 20x mesma coisa

[18:03] **+55 51 8115-5575:** _Mensagem apagada por um admin (Jk Cli)_

[18:03] **+55 11 95194-1749:** Ta chapando mano

[18:03] **+55 51 8115-5575:** Me explica aí

[18:03] **+55 54 9620-1797:** As respostas sao bem diferentes

[18:04] **+55 51 8115-5575:** _Mensagem apagada por um admin (Jk Cli)_

[18:04] **+55 11 95194-1749:** Falando merda man

[18:04] **+55 51 8115-5575:** Tá bom...

[18:04] **+55 51 8115-5575:** Boa sorte

[18:04] **+55 11 96654-2013:** Vcs que já são bem experientes nisso. 

Eu uso o Claude no vscode. 
Tem algum outro app melhor ?
Ou o vscode para o básico já ajuda?

Ainda não tenho nada monstruoso igual vejo de vcs aqui haha

[18:04] **+55 51 8115-5575:** Pagar gato por lebre

[18:04] __Jk Cli removeu +55 51 8115-5575__

[18:11] **Jk Cli:** Cara tá desesperado já

[18:13] **+55 27 99694-0707:** _Mensagem apagada_

[18:13] **+55 27 99694-0707:** _Mensagem apagada_

[18:16] **+55 61 9148-6214:** Tá indisponível??? 502 aqui pra mim, nos endpoints e site tb.

[18:16] **+55 11 95194-1749:** Esses vibe coder

[18:16] **+55 27 99694-0707:** _Mensagem apagada_

[18:16] **+55 11 95194-1749:**
> _+55 61 9148-6214: Tá indisponível??? 502 aqui pra mim, nos endpoints e site tb._
Gpt6.

[18:16] **+55 11 95194-1749:** Vai trazer hoje

[18:16] **+55 27 99694-0707:** _Mensagem apagada por um admin (Jk Cli)_

[18:16] **+55 27 99694-0707:** _Mensagem apagada_

[18:16] **+55 11 95194-1749:**
> _+55 27 99694-0707: deve ser o nego xucro_
Tira esse nome

[18:16] **+55 27 99694-0707:** _Mensagem apagada_

[18:16] **+55 11 95194-1749:** Nome do diabo

[18:16] **+55 27 99694-0707:** _Mensagem apagada_

[18:16] **+55 51 9425-4975:** Nem vi qq rolou

[18:17] **+55 27 99694-0707:** _Mensagem apagada_

[18:17] **+55 27 99694-0707:** _Mensagem apagada_

[18:17] **+55 27 99694-0707:** _Mensagem apagada_

[18:17] **+55 11 95194-1749:** Mano assinei aqui e está muito bom n sei pq esses caras quer difamar trabalho do @~João

[18:18] **+55 11 95194-1749:** Sendo que economizei papo de muito dinheiro

[18:18] **+55 11 95194-1749:** Muito mesmo

[18:18] **+55 27 99694-0707:** _Mensagem apagada_

[18:18] **+55 11 95194-1749:** Tenho empresa com + de 12 devs tudo trabalhando com api da ghost

[18:18] **+55 27 99694-0707:** _Mensagem apagada_

[18:18] **+55 11 95194-1749:** Concorrência tá desesperada

[18:19] **+55 11 95194-1749:** Aqui só tem programador Raiz!!

[18:19] **+55 27 99694-0707:** _Mensagem apagada_

[18:19] **+55 61 9148-6214:**
> _+55 11 95194-1749: Gpt6._
Não entendi....

[18:19] **+55 27 99694-0707:** _Mensagem apagada_

[18:19] **+55 11 95194-1749:**
> _+55 61 9148-6214: Não entendi...._
Eles vão trazer

[18:19] **+55 61 9148-6214:**
> _+55 27 99694-0707: calaio, vo por meu curriculo (la ele)_
Vou por o meu tb (la ele)

[18:19] **+55 51 9425-4975:**
> _+55 27 99694-0707: quer falar 1 palavra e a i.a advinhe o resto kkk_
Tu é dev do projeto?

[18:19] **+55 11 95194-1749:** Avisaram hoje !!

[18:19] **+55 27 99694-0707:** _Mensagem apagada_

[18:20] **+55 27 99694-0707:** _Mensagem apagada_

[18:20] **+55 51 9425-4975:**
> _+55 27 99694-0707: qual?_
Da ghost

[18:20] **+55 11 95194-1749:** Os cara fala nada com nada

[18:20] **+55 27 99694-0707:** _Mensagem apagada_

[18:21] **+55 27 99694-0707:** _Mensagem apagada_

[18:21] **+55 51 9425-4975:** Pdc

[18:21] **+55 11 95194-1749:** E eu cliente deles recente do plano + top que eles tem

[18:21] **+55 11 95194-1749:** E fico puto com os cara desesperado

[18:21] **+55 11 95194-1749:** Pq gratidão que eu tenho aqui é eterna

[18:22] **+55 51 9425-4975:** Normal surgir duvidas

[18:26] __+55 21 97605-5544 entraram usando o link de convite__

[18:36] **+55 62 9364-7674:** boa noite.

estou com 4 funcionários usando minha chave da GhostCLI. Antes eles usavam o claude20x

os 4 me reportaram COMPORTAMENTO ESTRANHO. 

Onde o claude agora fala "vou fazer XXXX" mas nao faz e literalmente fica parado. isso aconteceu com os 4 funcionários em 4 projetos diferentes. e detalhe que eles NEM CONVERSAM ENTRE ELES kkkkkkkkkkkkkkk

[18:36] **+55 62 9364-7674:** [Imagem] ta vendo ali, ele fala "vou criar a nova versao ..."

[18:37] **+55 62 9364-7674:** mas parou logo em seguida

[18:37] **+55 62 9364-7674:** tem alguem com o mesmo problema?

[18:37] **+55 11 95194-1749:** Mano aqui tá de boa

[18:37] **+55 11 95194-1749:** Os cara vai fazer atualização agora

[18:37] **+55 11 95194-1749:** Eu acho

[18:37] **+55 11 95194-1749:** Do gpt 6

[18:37] **+55 11 95194-1749:** Então é melhor esperar

[18:37] **+55 11 95194-1749:** E ter paciência aí

[18:37] **+55 11 95194-1749:** Que vai ser papo de loucura mesmo coisa de outro mundo

[18:38] **+55 47 9618-4437:**
> _+55 62 9364-7674: Imagem: ta vendo ali, ele fala "vou criar a nova versao ..."_
A gente não consegue saber desse jeito

[18:38] **+55 47 9618-4437:** O motivo

[18:38] **+55 62 9364-7674:** o que vc precisa?

[18:38] **+55 47 9618-4437:** Tem que abrir ticket no Discord junto ao email do site e timestamp da requisição

[18:38] **+55 47 9618-4437:** E conseguimos ver

[18:38] **+55 11 95194-1749:**
> _+55 47 9618-4437: Tem que abrir ticket no Discord junto ao email do site e timestamp da requisição_
Geralmente eu faço isso vcs respondem rápido

[18:38] **+55 69 7400-7880:** Seria top tiver o gpt 6 no max

[18:38] **+55 21 97605-5544:** Vai incluir o codex ?

[18:38] **+55 11 95194-1749:** Eu sempre mano lá

[18:39] **+55 11 95194-1749:**
> _+55 21 97605-5544: Vai incluir o codex ?_
Isso eu n sei

[18:39] **+55 47 9618-4437:**
> _+55 69 7400-7880: Seria top tiver o gpt 6 no max_
Vai ter ainda hoje

[18:39] **+55 47 9618-4437:**
> _+55 21 97605-5544: Vai incluir o codex ?_
Sim

[18:39] **+55 62 9364-7674:**
> _+55 47 9618-4437: Tem que abrir ticket no Discord junto ao email do site e timestamp da requisição_
o timestamp da requisicao eu pego como pelo vscode?

[18:39] **+55 11 95194-1749:** To louco aqui pelo gpt 6

[18:39] **+55 47 9618-4437:**
> _+55 62 9364-7674: o timestamp da requisicao eu pego como pelo vscode?_
Abre um ticket la6

[18:39] **+55 11 95194-1749:** Ansiedade a mil

[18:40] **+55 69 7400-7880:**
> _+55 47 9618-4437: Vai ter ainda hoje_
Eita. Pensei q seria só no enterprise. Então vou assinar 😁

[18:40] **+55 47 9618-4437:** Vai tar no Max no primeiro dia

[18:40] **+55 47 9618-4437:** Depois só fazendo upgrade pro enterprise

[18:40] **+55 62 9364-7674:** vou abrir no discord entao

[18:40] **+55 47 9618-4437:** Só pra ter uma degustação do GPT 6 ilimitado

[18:40] **+55 11 95194-1749:** Caralh slk

[18:40] **+55 11 95194-1749:** 🥹🥹🥹🥹🥹🥹🥹🥹🥹

[18:41] **+55 11 95194-1749:** Vai  fazer minha sexta feliz

[18:41] **+55 11 95194-1749:** Deve ter sido caro
Para negociar com open ai

[18:41] **+55 69 7400-7880:**
> _+55 47 9618-4437: Vai tar no Max no primeiro dia_
Ah 😅

[18:41] **+55 11 95194-1749:** Acredito que os sócios aí tiveram que colocar o pataco no bolso

[18:41] **+55 11 95194-1749:** Pra

[18:41] **+55 11 95194-1749:** Lançar isso

[18:41] **+55 11 95194-1749:** Slk

[18:41] **+55 11 96654-2013:**
> _+55 11 95194-1749: Esses vibe coder_
Eu sou rs. 
Por isso q tô aqui pra tentar aprender. 

Sou novo nesse mundo doido.

Mas logo espero somar pra ajudar a galera

[18:42] **+55 11 95194-1749:** Aviso galera pega plano empresa compensa muito suporte dos cara responde mais rápido do q meu advg

[18:43] __+55 54 9368-5879 entraram usando o link de convite__

[18:43] **+55 21 97605-5544:** Caçando empresários que já tem experiência pra trocar figurinha

[18:44] **+55 54 9368-5879:** Boa tarde

[18:44] **+55 54 9368-5879:** Ta rodando liso o fable 5.1? E me diz uma coisa e imilitado os token no plano de 189?

[18:45] **+55 21 97605-5544:**
> _+55 54 9368-5879: Ta rodando liso o fable 5.1? E me diz uma coisa e imilitado os token no plano de 189?_
Sim

[18:45] **+55 11 95194-1749:**
> _+55 54 9368-5879: Ta rodando liso o fable 5.1? E me diz uma coisa e imilitado os token no plano de 189?_
Aqui ta top

[18:45] **+55 54 9368-5879:** Ai sim hem top

[18:46] **@fortytwowill:**
> _+55 11 96654-2013: Vcs que já são bem experientes nisso. 

Eu uso o Claude no vscode. 
Tem algum outro app melhor ?
Ou o vscode para o básico já ajuda?

Ainda não tenho nada monstruoso igual vejo de vcs aqui haha_
Pi CLI

[18:46] **+55 11 95194-1749:** Ghost e outro patamar

[18:46] **+55 87 9128-0580:**
> _+55 54 9368-5879: Ta rodando liso o fable 5.1? E me diz uma coisa e imilitado os token no plano de 189?_
Sim, pode colocar os agentes para rodar 24/7 em loop

[18:47] **+55 87 9128-0580:** [Figurinha]

[18:47] **+55 87 9128-0580:** [Figurinha]

[18:47] **+55 54 9368-5879:** Top

[18:47] **+55 87 9128-0580:** [Figurinha]

[18:47] **+55 54 9368-5879:** Eu to criando um jarvis mas ta dificil claude erra muito os codigo e erro em cima de erro e uma novela como ceis faz q sao mais experiente que eu

[18:48] **+55 54 9368-5879:** Na real ja ta criado 8 agentes work tudo certo mas a interface nao ta facil de acerta faz muito generico os trem

[18:49] **+55 47 9618-4437:**
> _+55 54 9368-5879: Eu to criando um jarvis mas ta dificil claude erra muito os codigo e erro em cima de erro e uma novela como ceis faz q sao mais experiente que eu_
Tem que usar a IA da maneira certa

[18:49] **+55 47 9618-4437:** @~Alexandre - Lovabase explica pra ele

[18:49] **+55 54 9368-5879:** E que eu comecei agora

[18:50] **+55 54 9368-5879:**
> _+55 47 9618-4437: @~Alexandre - Lovabase explica pra ele_
Muito obrigado

[18:52] **+55 87 9128-0580:** [Mensagem de voz]

[18:53] **+55 11 95194-1749:**
> _+55 87 9128-0580: Mensagem de voz_
Aula eim 💙

[18:53] **+55 11 95194-1749:** Mesma mentalidade que a minha

[18:53] **+55 54 9368-5879:** Top

[18:53] **+55 54 9368-5879:** Vo fz assim

[18:53] **+55 11 95194-1749:** Os cara tá dando mentoria de graça pow

[18:53] **+55 87 9128-0580:** [Mensagem de voz]

[18:54] **+55 87 9128-0580:** Vou mandar escrito aqui sobre o design

[18:54] **+55 87 9128-0580:** Calmae

[18:54] **+55 87 9128-0580:** Você tá criando no Claude algo

Vai no Pinterest procurar referências visuais 

Joga a referência para o claude 

Pede um prompt detalhado todo aquele design que você mandou e fala que é para o Gemini cria um html igual porém adaptado para o sistema que você tá criando no Claude 


Vai no Gemini ativa o pro e o canvas e manda o prompt 

Depois que ele gerar você baixa o HTML e manda para o claude e pede para ele adaptar para o seu sistema esse html

[18:55] **+55 11 95194-1749:** Mentoria de graça

[18:55] __+55 24 99950-4499 entraram usando o link de convite__

[18:55] **+55 11 95194-1749:** Essa comunidade é fd!!

[18:55] **+55 87 9128-0580:** [Vídeo]

[18:55] **+55 87 9128-0580:** Ativa essas opções

[18:55] **+55 87 9128-0580:** E manda a foto de ref e o prompt do Claude

[18:56] **+55 54 9368-5879:** Muito obrigado

[18:57] **+55 54 9368-5879:** Vo te manda foto da interface que tenho agora mas nao funciona 100% os comandos ainda precisa ajustar muita coisa vo usa oq tu me falo meu amigo

[19:04] **Jk Cli:** [Imagem]

[19:05] **+57 314 5070327:** Buen día espero que estés bien, quiero comprar Claude soy nuevo quien me asesora

[19:05] **Jk Cli:**
> _Jk Cli: Imagem_
@all  feedback positivo

[19:05] **Jk Cli:**
> _+57 314 5070327: Buen día espero que estés bien, quiero comprar Claude soy nuevo quien me asesora_
Dale

[19:05] **Jk Cli:** Estoy aquí

[19:06] **+55 27 99694-0707:** _Mensagem apagada_

[19:08] **+55 11 95194-1749:** Eu acho muito bom a ghost pois suporte deles é muito bom ,qualidade de tokens dos caras é nível absurdo ,e tbm na questão de ajuda em qualquer situação alguém me responde em 5 minutos muito rápido

[19:08] **+55 11 95194-1749:** Os cara n me vê apenas como só cliente realmente tratamento e diferente

[19:08] **+55 11 95194-1749:** Experiência e muito boa

[19:09] **+55 11 95194-1749:** Se preocupam muito com a sua operação eu falo como você está trabalhando e utilizando serviços deles ,pós venda e algo de outro mundo

[19:09] **+55 11 95194-1749:** Sou cliente Honda a 10 anos nem os cara me trata assim

[19:09] **+55 27 99694-0707:** _Mensagem apagada_

[19:09] **+55 27 99694-0707:** _Mensagem apagada_

[19:09] **+55 27 99694-0707:** _Mensagem apagada_

[19:09] **+55 27 99694-0707:** _Mensagem apagada_

[19:10] **+55 27 99694-0707:** _Mensagem apagada_

[19:10] **+55 27 99694-0707:** _Mensagem apagada_

[19:10] **+55 27 99694-0707:** _Mensagem apagada_

[19:10] **+55 11 95194-1749:** Tenho civic dos Mais novos

[19:10] **+55 27 99694-0707:** _Mensagem apagada_

[19:11] **+55 12 99662-3545:** [Figurinha]

[19:11] **+55 83 8782-8287:**
> _+55 27 99694-0707: PESSOAL, QUEM TIVER 1 TEMPINHO, FALEM O QUANTO A GHOST ESTA SENDO UTIL E AJUDANDO O SEU DIA DIA_
[Imagem] Números falam mais que palavras

[19:11] **Jk Cli:**
> _+55 11 95194-1749: Eu acho muito bom a ghost pois suporte deles é muito bom ,qualidade de tokens dos caras é nível absurdo ,e tbm na questão de ajuda em qualquer situação alguém me responde em 5 minutos muito rápido_
E sobre isso 🥹🥹🥹

[19:11] **+55 83 8782-8287:**
> _+55 83 8782-8287: Imagem: Números falam mais que palavras_
Sou assinante de um plano personalizado então é até mais que enterprise

[19:11] **+55 83 8782-8287:** Kkkkkk

[19:12] **+55 27 99694-0707:** _Mensagem apagada_

[19:12] **+55 27 99694-0707:** _Mensagem apagada_

[19:13] **+55 27 99694-0707:** _Mensagem apagada_

[19:13] **+55 47 9971-5265:** [Imagem] a api é top, o suporte mais ainda, só oq precisa melhorar é estabilidade!

[19:14] **+57 314 5070327:** Y cuál plan me recomienda para programar, cómo sería el pago y la adquisición, sería cuenta o plataforma háblenme un poco

[19:14] **+55 27 99694-0707:** _Mensagem apagada_

[19:15] **+55 27 99694-0707:** _Mensagem apagada_

[19:15] **+55 27 99694-0707:** _Mensagem apagada_

[19:16] **+55 27 99694-0707:** _Mensagem apagada_

[19:18] **Jk Cli:**
> _+55 83 8782-8287: Sou assinante de um plano personalizado então é até mais que enterprise_
Nosso patrocinador master !!

[19:19] __+94 77 861 3600 entraram usando o link de convite__

[19:20] **+57 314 5070327:** O pagamento para a plataforma eu envio captura você me envia conta me aconselha por favor

[19:21] **Você:**
> _+55 47 9971-5265: Imagem: a api é top, o suporte mais ainda, só oq precisa melhorar é estabilidade!_
[Imagem] aq é 8 agente rodando o tempo todo em paralelo

[19:21] **Você:** ghost e foda!

[19:22] **+55 27 99694-0707:** _Mensagem apagada_

[19:22] **+55 35 9946-8945:**
> _Você: Imagem: aq é 8 agente rodando o tempo todo em paralelo_
Tô chegando nos 60k

[19:23] **+55 11 96654-2013:** Ainda chego nesse nível. 
Meus projetos são invisíveis perto disso hahahah

[19:23] **+55 35 9946-8945:** Cheguei

[19:23] **+55 35 9946-8945:** [Imagem]

[19:31] **Jk Cli:** Fico muito feliz a galera economizando firme

[19:33] **+55 35 9946-8945:**
> _Jk Cli: Fico muito feliz a galera economizando firme_
Tá virando quase uma competição

[19:36] **+55 21 98102-9583:** [Imagem] Um feedback honesto (e construtivo): sobre a ferramenta, nada a reclamar, está me ajudando DEMAIS nesses 10 ou 11 dias de uso, apenas ainda não consegui acesso ao suporte quando precisei, não peguei o fluxo por talvez, em virtude do alto volume de demanda, é diferente das outras que usei em outras IAs (ainda mais que não sou dev). Mas aqui a galera sempre ajudou quando possível

[19:38] **+55 21 98102-9583:** Inclusive por isso venho indicando, quando tenho empecilhos vou tentando me virar, mas sem dúvida alguma a ferramenta me ajuda DEMAIS

[19:39] __[Notificação do sistema]__

[19:39] **+55 98 8536-3798:** Qual o RPM da conta MAX?

[19:44] **+55 47 9618-4437:**
> _+55 98 8536-3798: Qual o RPM da conta MAX?_
125

[20:19] __+55 21 98321-2828 entraram usando o link de convite__

[20:19] **+55 21 98321-2828:** Funciona?

[20:20] **+55 21 98321-2828:** Ou é mais um delay que coloca o Kimi como fable? 😬

[20:20] **+55 11 95194-1749:**
> _+55 21 98321-2828: Ou é mais um delay que coloca o Kimi como fable? 😬_
Meu Deus

[20:21] **+55 11 95194-1749:**
> _+55 21 98321-2828: Ou é mais um delay que coloca o Kimi como fable? 😬_
Acho que você é cliente de outro cara aí pq aqui é Claude mesmo

[20:21] **+55 11 95194-1749:** Oficial

[20:21] **+55 21 98321-2828:** Diz que não é por favor

[20:21] **+55 11 95194-1749:** Tenho 3 planos 20x

[20:21] **+55 11 95194-1749:** Claude dos Cara aqui mesma coisa

[20:21] **+55 21 98321-2828:** Eu quero muito ser cliente

[20:21] **+55 11 95194-1749:** Até melhor

[20:21] **+55 11 95194-1749:** E muito bom ótimo suporte

[20:21] **+55 11 95194-1749:** Olha feedbacks da galera aí

[20:22] **+55 21 98321-2828:** Tudo que eu testei até hoje era mentira

[20:22] **+55 21 98321-2828:** Ai fico com o pé atrás

[20:25] **+55 21 98321-2828:** Vou testar

[20:37] **+55 21 98321-2828:** Falha ao autenticar no provedor PIX.

[20:37] **+55 21 98321-2828:** :(

[20:37] **+55 21 98321-2828:** Não gera o pix

[20:53] **@fortytwowill:** Alguém tendo problema com o fable

[20:53] **+57 304 3533218:**
> _@fortytwowill: Alguém tendo problema com o fable_
Segundo todos, ninguém tem problema nenhum, só você e eu que não temos acesso.

[20:55] **+55 21 98102-9583:**
> _@fortytwowill: Alguém tendo problema com o fable_
Irmão, realmente não tô tendo não, é o modelo que mais uso

[20:55] **+55 21 98102-9583:** Meus problemas às vezes é com burrice, mas um colega falou bem aí mais cedo, pode ser no meu prompt. Pra eu afirmar que é culpa da ferramenta eu teria que ter convicção...

[20:57] **+55 27 99694-0707:** _Mensagem apagada_

[20:57] **Jk Cli:** Ola

[20:57] **+55 47 9618-4437:**
> _+55 21 98321-2828: Falha ao autenticar no provedor PIX._
resolvido

[20:57] **Jk Cli:** Resolvido já

[20:57] **+55 21 98321-2828:** Já consegui

[21:01] **+55 21 97605-5544:** suporte só pelo discord ?

[21:03] **+55 27 99694-0707:** _Mensagem apagada_

[21:03] **+55 27 99694-0707:** _Mensagem apagada_

[21:03] **+55 27 99694-0707:** _Mensagem apagada_

[21:05] **+55 21 97605-5544:** to com problema com o fable tb

[21:12] **+55 88 9490-6319:**
> _+55 27 99694-0707: PESSOAL, QUEM TIVER 1 TEMPINHO, FALEM O QUANTO A GHOST ESTA SENDO UTIL E AJUDANDO O SEU DIA DIA_
Hoje me ajudou pra caramba, eu até tava na dúvida se ia dar certo, mas depois que fiz login e  vinculei a API consegui resolver um problema em um projeto que não tava conseguindo a dias e resolveu em uma tarde.

[21:18] **@fortytwowill:** Anthropic stream error (api_error): The model provider did not complete the request. Try again in a few moments.                                  
 Dismissed when you send your next message.

[21:34] **+55 21 97605-5544:** uma duvida.. posso utilizar minha key para projetos onde dependem de IA ?

[21:34] **+55 61 9273-2024:** O login da API roda direto no app do Codex?

[21:34] **+55 61 9273-2024:** Ou é em vscode?

[21:41] **+55 47 9618-4437:** astra segue em teste pra ser liberado ainda hoje

[22:14] **+55 27 99694-0707:** _Mensagem apagada_

[22:16] **+55 19 98416-9825:** Alguém ai do time da administração poderia me ajudar com a aquisição do plano e dúvidas? Tentei contato com o @Jk Cli mas acredito que ele esteja ocupado.

[22:17] **+55 47 9618-4437:**
> _+55 19 98416-9825: Alguém ai do time da administração poderia me ajudar com a aquisição do plano e dúvidas? Tentei contato com o @Jk Cli mas acredito que ele esteja ocupado._
@~Eduardo @Jk Cli

[22:17] **+55 47 9618-4437:**
> _+55 19 98416-9825: Alguém ai do time da administração poderia me ajudar com a aquisição do plano e dúvidas? Tentei contato com o @Jk Cli mas acredito que ele esteja ocupado._
consigo ajudar

[22:17] **+55 99 8145-3910:**
> _+55 19 98416-9825: Alguém ai do time da administração poderia me ajudar com a aquisição do plano e dúvidas? Tentei contato com o @Jk Cli mas acredito que ele esteja ocupado._
O plano é top mano

[22:17] **Jk Cli:**
> _+55 19 98416-9825: Alguém ai do time da administração poderia me ajudar com a aquisição do plano e dúvidas? Tentei contato com o @Jk Cli mas acredito que ele esteja ocupado._
Opaaaaa

[22:18] **Jk Cli:** To aqui

[22:18] **+55 27 99694-0707:** _Mensagem apagada_

[22:18] **+55 27 99694-0707:** _Mensagem apagada_

[22:18] **+55 27 99694-0707:** _Mensagem apagada_

[22:18] **Jk Cli:** Kkkkk

[22:18] **+55 19 98416-9825:**
> _Jk Cli: Opaaaaa_
Então me responde no pv po 😅

[22:18] **+55 99 8145-3910:** o plano é muito bom , fora que os token são ilimitados

[22:18] **+55 27 99694-0707:** _Mensagem apagada_

[22:18] **+55 27 99694-0707:** _Mensagem apagada_

[22:18] **+55 99 8145-3910:**
> _+55 19 98416-9825: Então me responde no pv po 😅_
funciona bem mano

[22:18] **+55 99 8145-3910:**
> _+55 27 99694-0707: mando ate nuds meu patrao_
vishiii

[22:18] **+55 27 99694-0707:** _Mensagem apagada_

[22:19] **+55 99 8145-3910:**
> _+55 27 99694-0707: to mentindo nao poh_
[Figurinha]

[22:19] **+55 27 99694-0707:** _Mensagem apagada_

[22:19] **+55 27 99694-0707:** _Mensagem apagada_

[22:19] **+55 27 99694-0707:** _Mensagem apagada_

[22:19] **+55 27 99694-0707:** _Mensagem apagada_

[22:25] **+55 11 95194-1749:**
> _+55 19 98416-9825: Alguém ai do time da administração poderia me ajudar com a aquisição do plano e dúvidas? Tentei contato com o @Jk Cli mas acredito que ele esteja ocupado._
Opa sou cliente enterprise oque eu posso te dizer que os cara é foda plano deles são ilimitados mesmo ,e eles sempre trazem novidade

[22:25] **+55 11 95194-1749:** Realmente qualidade de token é nível absurdo

[23:33] **+55 98 8536-3798:**
> _+55 27 99694-0707: PESSOAL, QUEM TIVER 1 TEMPINHO, FALEM O QUANTO A GHOST ESTA SENDO UTIL E AJUDANDO O SEU DIA DIA_
Tenho um sistema de estoque rodando, hoje ele fez uma varredura completa e conciliou muitos lotes com divergência de saldo, corrigindo todos, se eu fosse usar o Claude free ou até o plano de 110 creio que esgotaria cota sem terminar kkkkkkk top demais usar a Ghost

[23:33] **Jk Cli:**
> _+55 98 8536-3798: Tenho um sistema de estoque rodando, hoje ele fez uma varredura completa e conciliou muitos lotes com divergência de saldo, corrigindo todos, se eu fosse usar o Claude free ou até o plano de 110 creio que esgotaria cota sem terminar kkkkkkk top demais usar a Ghost_
🥹🥹🥹❤️❤️❤️

---

## 12 de setembro de 2026

[0:41] __+55 16 99727-8952 entraram usando o link de convite__

[1:15] **+55 22 98140-7236:** aqui ta dando isso sempre 

The model provider did not complete the request. Try again in a few moments.

alguém pode explicar oque pode ser?

[1:16] **+55 11 95194-1749:** Geralmente eu mando ticket lá no dc deles

[1:16] **+55 11 95194-1749:** Vc fez isso ?

[1:16] **+55 11 95194-1749:** Faça isso que eles resolvem lá

[1:17] **+55 22 98140-7236:** vou tentar obrigado

[8:31] __+55 31 9157-0107 entraram usando o link de convite__

[8:56] **+55 54 9368-5879:** Bom dia

[8:57] **+55 54 9368-5879:** Fiz assinatura plano max e agora no claude esta dizendo que o fable 5.1 esta restrito pelas conf da minha organizacao e que esta usando opus5 em vez disso???

[8:59] **+55 54 9368-5879:** [Imagem]

[8:59] **+55 54 9368-5879:** Agr lasko tudo aqi

[8:59] **+55 11 95194-1749:** Deve ser att dos cara

[8:59] **+55 11 95194-1749:** Quando for assim c cria ticket

[8:59] **+55 11 95194-1749:** E manda no discord

[9:00] **+55 54 9368-5879:** Mds como q faiz isso kkkk

[9:00] **+55 54 9368-5879:** 🤦🏼‍♂️

[9:00] **+55 11 95194-1749:** Só baixar discord man

[9:00] **+55 47 9618-4437:**
> _+55 54 9368-5879: Imagem_
/model claude-fable-5-1

[9:07] **+55 54 9368-5879:** Tirei todos os outros deixei so o fable deu boa

[9:24] **@fortytwowill:** Não é à toa que o fable zica direto, todo mundo só quer saber de fable

[9:36] **+55 11 94057-2122:**
> _@fortytwowill: Não é à toa que o fable zica direto, todo mundo só quer saber de fable_
Cara é desperdício, a maioria das pessoas que usam o Fable nem entende o contexto que ele é para ser aplicado

[9:36] **+55 11 94057-2122:** Tem gente que usa Fable e opus pra fazer ppt

[9:36] **+55 21 97605-5544:**
> _+55 11 94057-2122: Tem gente que usa Fable e opus pra fazer ppt_
Fica bom ? Kkk

[9:36] **+55 21 97605-5544:** Sacanagem

[9:36] **+55 11 94057-2122:** Aí ferra mesmo, vai gastar 10x mais tokens o que um sonnet 5 ia ter o mesmo resultado

[9:37] **+55 11 94057-2122:**
> _+55 21 97605-5544: Fica bom ? Kkk_
É literalmente a mesma coisa kkkk

Fable e opus são pra contextos muito complexos

[9:38] **+55 11 94057-2122:** Aqui eu uso com consciência.

Fable 5.1 e opus 5 só quando é programação pesada, ou pesquisa muito específica

[9:38] **+55 11 94057-2122:** Fora isso, sem estar usando o code, é sonnet ou no máximo opus

[9:39] **+55 11 95194-1749:**
> _+55 11 94057-2122: Aqui eu uso com consciência.

Fable 5.1 e opus 5 só quando é programação pesada, ou pesquisa muito específica_
Pessoal do meu time tbm faz o mesmo

[9:40] **+55 11 95194-1749:** Galera acha que é só jogar o fable seja o que Deus quiser

[9:40] **+55 11 95194-1749:** E assim n

[9:40] **+55 11 95194-1749:**
> _+55 11 94057-2122: Aí ferra mesmo, vai gastar 10x mais tokens o que um sonnet 5 ia ter o mesmo resultado_
Siim

[9:41] **+55 21 97605-5544:** Alguém já conseguiu atingir o vibe code supremo de montar toda a arquitetura e roadmap

[9:41] **+55 21 97605-5544:** E o Claude seguir solo ?

[9:45] **+55 83 9105-0660:**
> _+55 21 97605-5544: E o Claude seguir solo ?_
[Figurinha]

[9:45] **+55 83 9105-0660:** Tô montando o Jarvis e vou soltar pra galera

[9:46] **+55 11 94057-2122:**
> _+55 83 9105-0660: Tô montando o Jarvis e vou soltar pra galera_
Explica melhor isso aí kkk

[9:46] **+55 11 94057-2122:** Tô precisando aprender mais sobre o Claude, acho que estou subutilizado ele kkk

[9:46] **+55 83 9105-0660:**
> _+55 11 94057-2122: Explica melhor isso aí kkk_
[Figurinha]

[9:47] **+55 83 9105-0660:** É só juntar as APIs, colocar num harness, fazer a api com elevenlabs, umas skills de acesso à internet e pronto

[9:47] **+55 83 9105-0660:** Jarvis

[9:58] **+55 21 98321-2828:** [Imagem] Usando o fable para configurar o omarchy só de sacanagem

[10:00] __+503 7740 0436 entraram usando o link de convite__

[10:16] **Jk Cli:**
> _+55 21 98321-2828: Imagem: Usando o fable para configurar o omarchy só de sacanagem_
Marcha!!

[10:23] **+55 43 9106-8122:** [Imagem] em 1 dia acho

[10:24] **+55 43 9106-8122:** na vdd 8h

[10:24] **+55 11 95194-1749:**
> _+55 43 9106-8122: Imagem: em 1 dia acho_
50k dia?

[10:24] **+55 11 95194-1749:** Caralh

[10:24] **+55 11 95194-1749:** 🫠

[10:25] **Jk Cli:** Mkkkkkkkk mds do céu

[10:25] **Jk Cli:** Economizo um ônix

[10:25] **+55 43 9106-8122:** kkkkkkk a ideia é a economia

[10:26] **Jk Cli:** Absurdo isso economia que foi

[10:26] **Jk Cli:** Meu Deus

[10:26] **+55 43 9106-8122:** o ruim é q n tem como subir direto no github

[10:26] **+55 61 9273-2024:**
> _+55 43 9106-8122: Imagem: em 1 dia acho_
Mano?

[10:26] **+55 61 9273-2024:** Fez o Facebook 2

[10:26] **Jk Cli:** Vamos ajudar as melhores empresas do Brasil e do mundo

[10:26] **Jk Cli:**
> _+55 43 9106-8122: Imagem: em 1 dia acho_
Plano dele é o personalizado

[10:27] **Jk Cli:** Por iss

[10:27] **+55 43 9106-8122:**
> _Jk Cli: Plano dele é o personalizado_
Simmm

[10:28] **Jk Cli:** N é nem esse de 650 é + alto

[10:31] **+55 21 97605-5544:** como funciona o plano personalizado ?

[10:33] **Jk Cli:** Como se fosse o plano enterprise so que. Bem melhor

[10:33] **Jk Cli:** Bem flexível na questão de suas demandas

[10:33] **Jk Cli:** Por exemplo você gera 3 bilhões de tokens por dia em uma equipe de 10 a 15 devs

[10:34] **Jk Cli:** Conseguimos fazer isso e ajustamos para melhor qualidade possível para seu time utilizar a ghost

[10:34] __+55 49 8843-1956 entraram usando o link de convite__

[10:34] **+55 49 8843-1956:** Bom dia

[10:34] **+55 49 8843-1956:** Isso funciona de verdade?

[10:35] **+55 27 99694-0707:** _Mensagem apagada_

[10:35] **Jk Cli:**
> _+55 43 9106-8122: Imagem: em 1 dia acho_
Manda dnv @~Ruan M.

[10:36] **+55 43 9106-8122:**
> _Jk Cli: Por exemplo você gera 3 bilhões de tokens por dia em uma equipe de 10 a 15 devs_
Exatooooo

[10:36] **+55 27 99694-0707:** _Mensagem apagada_

[10:36] **+55 27 99694-0707:** _Mensagem apagada_

[10:36] **+55 27 99694-0707:** _Mensagem apagada_

[10:36] **+55 43 9106-8122:** [Imagem]

[10:36] **Jk Cli:** Mano …

[10:36] **+55 27 99694-0707:** _Mensagem apagada_

[10:36] **+55 43 9106-8122:**
> _Jk Cli: Manda dnv @~Ruan M._
Aqui

[10:36] **+55 27 99694-0707:** _Mensagem apagada_

[10:36] **+55 27 99694-0707:** _Mensagem apagada_

[10:36] **+55 27 99694-0707:** _Mensagem apagada_

[10:40] **+55 11 95194-1749:**
> _+55 49 8843-1956: Isso funciona de verdade?_
Muito mesmo

[10:41] **+55 11 95194-1749:** Melhor coisa que aconteceu na minha vida casamento da minha esposa e outro foi conhecer a ghost

[10:41] **+55 11 95194-1749:** Kkkk

[10:44] **Jk Cli:** 💙💙💙💙

[10:45] **+55 43 9106-8122:** [Mensagem de voz]

[10:45] **Signor For Programming:** I have an issue

[10:46] **Signor For Programming:** No one reply me on discord

[10:46] **+55 43 9106-8122:** [Mensagem de voz]

[10:50] **Jk Cli:** Top desde já agradecemos muito pela confiança 🫡

[10:53] **+55 27 99694-0707:** @Jk Cli pai pode me remover do suporte, quando eu poder ajudar vô ajudar

[10:53] **Jk Cli:** De boa

[11:02] **@fortytwowill:**
> _+55 11 94057-2122: Cara é desperdício, a maioria das pessoas que usam o Fable nem entende o contexto que ele é para ser aplicado_
Eu só uso pra planning. Daí uso glm ou sonnet pra fazer a maioria e opus pra review

[11:21] __+55 61 9136-5283 entraram usando o link de convite__

[11:25] __+966 57 279 5829 entraram usando o link de convite__

[12:30] __+55 11 99669-4521 entraram usando o link de convite__

[12:32] **+55 11 99669-4521:** Boa tarde galera, alguém que ja comprou sabe me dizer se a I.A é realmente Opus 5 / Fable 5.1?

Recentemente comprei de um rapaz que oferecia ilimitado também, mas a I.A era bem burrinha kkkkkk

[12:32] **+55 43 9106-8122:**
> _+55 43 9106-8122: Imagem_
[Imagem]

[12:33] **+55 43 9106-8122:**
> _+55 11 99669-4521: Boa tarde galera, alguém que ja comprou sabe me dizer se a I.A é realmente Opus 5 / Fable 5.1?

Recentemente comprei de um rapaz que oferecia ilimitado também, mas a I.A era bem burrinha kkkkkk_
te falar q é o fable 5.1 kkkkkk

[12:33] **+55 11 95194-1749:** Cara economizou 70k ☠️☠️☠️☠️☠️☠️☠️☠️☠️☠️☠️

[12:33] **+55 11 95194-1749:** ☠️☠️☠️☠️☠️☠️☠️☠️☠️☠️

[12:33] **+55 43 9106-8122:** 12h rodando sem parar

[12:33] **+55 43 9106-8122:** [Figurinha]

[12:33] **+55 43 9106-8122:** obs ta na fase 2.1 de 40 q eu crie pro projeto

[12:34] **+55 11 99669-4521:**
> _+55 43 9106-8122: te falar q é o fable 5.1 kkkkkk_
To usando 2 conta em paralelo pra sugar um pouco o Opus kkkkk, então é realmente próximo a eles né?

[12:35] **+55 11 95194-1749:**
> _+55 11 99669-4521: To usando 2 conta em paralelo pra sugar um pouco o Opus kkkkk, então é realmente próximo a eles né?_
Mano é o fable mesmo

[12:35] **+55 11 99669-4521:** La ele

[12:35] **+55 43 9106-8122:**
> _+55 11 99669-4521: To usando 2 conta em paralelo pra sugar um pouco o Opus kkkkk, então é realmente próximo a eles né?_
no caso eu rodei um bench e apontou q era o fable 5.1

[12:35] **+55 11 95194-1749:** Cara fez eu economizar 15k por aí

[12:35] **+55 43 9106-8122:** pq to rodando direto da interface do claude

[12:35] **+55 11 95194-1749:** Vou é viajar com essa economia kkk

[12:35] **+55 11 95194-1749:** Rs rs ghost amo vcs

[12:35] **+55 43 9106-8122:** [Imagem]

[12:35] **+55 11 99669-4521:**
> _+55 43 9106-8122: pq to rodando direto da interface do claude_
Então, o que eu tinha pegado era tbm... So que apontava pro servidor do rapaz, parecia mais a versão 4 do que a 5

[12:36] **+55 11 95194-1749:**
> _+55 43 9106-8122: Imagem_
Você é cliente personalizado? Ou enterprise

[12:36] **+55 11 99669-4521:** Acompanhar aqui acho que vou dar uma chance pra Ghost tbm

[12:36] **+55 43 9106-8122:**
> _+55 11 95194-1749: Você é cliente personalizado? Ou enterprise_
personalizado

[12:36] **+55 11 95194-1749:** E uns 1500

[12:36] **+55 11 95194-1749:** O mesmo do meu

[12:36] **+55 11 95194-1749:** E top

[12:37] **+55 43 9106-8122:**
> _+55 11 99669-4521: Então, o que eu tinha pegado era tbm... So que apontava pro servidor do rapaz, parecia mais a versão 4 do que a 5_
ia depende muito, como é compartilhado de certa forma vc tem q ser muito mais especifico noq pede

[12:37] **+55 11 95194-1749:**
> _+55 11 99669-4521: Então, o que eu tinha pegado era tbm... So que apontava pro servidor do rapaz, parecia mais a versão 4 do que a 5_
Vai na ghost que é melhor

[12:37] **+55 11 95194-1749:** Tomei muito golpe já

[12:37] **+55 43 9106-8122:** n adiantar ser muito leigo, no caso o prompt pequeno tem 200 a 300 linhas

[12:38] **+55 11 95194-1749:** A ghost salvou como os único que realmente é 100% Claude

[12:38] **+55 11 95194-1749:** Os cara deve ter uma infra absurda

[12:40] **+55 51 9184-0532:**
> _+55 11 99669-4521: Acompanhar aqui acho que vou dar uma chance pra Ghost tbm_
Olha, eu não daria uma chance…. Sabe por que?

Não terá mais volta…. Vai ativar o modo loop 🔁 e vai continuar e continuar kkkkk
Ou seja sua chance não será uma chance, será de fato um bom proveito….
OBs aos admin…. Tenta por uma forma no site de quem já tem o plano poder pagar já o próximo mês e também escolher quantos meses 😋

[12:41] **+55 81 9575-5362:**
> _+55 51 9184-0532: Olha, eu não daria uma chance…. Sabe por que?

Não terá mais volta…. Vai ativar o modo loop 🔁 e vai continuar e continuar kkkkk
Ou seja sua chance não será uma chance, será de fato um bom proveito….
OBs aos admin…. Tenta por uma forma no site de quem já tem o plano poder pagar já o próximo mês e também escolher quantos meses 😋_
Desconto pra quem assina trimestre ou semestre

[12:41] **+55 81 9575-5362:** Eu apoio kk

[12:46] **+55 51 9184-0532:** Eu nem me refiro a desconto, pois sabemos que todos tem custo e já estamos tendo uma mega economia, mas não mexendo no valor acredito que boa parte que está ativo e realmente usa pra trabalho, fica…. O problema é crescer o valor…. Mas isso é uma parte da adm decidir kkkkk
Só senti falta disso mesmo, meu plano tem alguns dias ainda pra vencer e só vou poder renovar quando vencer pois não me dá opção de pagar antes

[12:55] **+55 62 9444-5039:** como ficou a questao do astra ? já soltou ?

[12:57] **Jk Cli:** Ainda hoje

[12:57] **Jk Cli:**
> _+55 51 9184-0532: Olha, eu não daria uma chance…. Sabe por que?

Não terá mais volta…. Vai ativar o modo loop 🔁 e vai continuar e continuar kkkkk
Ou seja sua chance não será uma chance, será de fato um bom proveito….
OBs aos admin…. Tenta por uma forma no site de quem já tem o plano poder pagar já o próximo mês e também escolher quantos meses 😋_
Muito obrigado pelo feedbacks iremos atualizar no site tbm sobre os planos que vocês pedem ❤️💙👻

[14:51] **+55 18 99622-9907:** Quem estiver precisando de gateway, operações com baixo e alto volume de med, nominais novas, zero desvio, me da um alo.

[14:53] **+55 35 9946-8945:**
> _+55 18 99622-9907: Quem estiver precisando de gateway, operações com baixo e alto volume de med, nominais novas, zero desvio, me da um alo._
Gateway? Não é a mesma coisa que a ghost faz?

[14:54] **+55 18 99622-9907:**
> _+55 35 9946-8945: Gateway? Não é a mesma coisa que a ghost faz?_
Vc ta falando sobre a ghost cli ou ghostspay?

[14:55] **+55 35 9946-8945:**
> _+55 18 99622-9907: Vc ta falando sobre a ghost cli ou ghostspay?_
Depende do Gateway que está falando 😂 Gateway é porta de entrada de algo, Gateway de pagamento, API Gateway, Gateway de IA

[14:55] **+55 18 99622-9907:**
> _+55 35 9946-8945: Depende do Gateway que está falando 😂 Gateway é porta de entrada de algo, Gateway de pagamento, API Gateway, Gateway de IA_
Le a mensagem que vc enviou

[14:55] **+55 11 95194-1749:**
> _+55 18 99622-9907: Quem estiver precisando de gateway, operações com baixo e alto volume de med, nominais novas, zero desvio, me da um alo._
Isso aí é pagamento

[14:56] **+55 35 9946-8945:**
> _+55 18 99622-9907: Le a mensagem que vc enviou_
Sim sim

[14:56] **+55 35 9946-8945:** Erro meu

[14:56] **+55 35 9946-8945:** Descurpa

[14:56] **+55 11 95194-1749:** Tá falando sem as perm do admin kkk

[14:56] **+55 18 99622-9907:**
> _+55 11 95194-1749: Tá falando sem as perm do admin kkk_
Meu Deus

[14:56] **+55 18 99622-9907:** Kkkkkkkkkk

[14:57] **+55 98 8536-3798:**
> _+55 18 99622-9907: Quem estiver precisando de gateway, operações com baixo e alto volume de med, nominais novas, zero desvio, me da um alo._
De pagamento?

[15:24] __+90 545 800 19 85 entraram usando o link de convite__

[15:26] **Signor For Programming:** _Mensagem apagada por um admin (Jk Cli)_

[15:26] **Signor For Programming:** _Mensagem apagada por um admin (Jk Cli)_

[15:26] **Signor For Programming:** _Mensagem apagada por um admin (Jk Cli)_

[15:26] __Jk Cli removeu Signor For Programming__

[15:47] **+251 94 763 5552:** _Mensagem apagada por um admin (Jk Cli)_

[15:48] **+55 11 95194-1749:** Olha esses gringo louc

[16:35] **+55 62 9364-7674:** alguem consegue me ajudar com o passo a passo para usar o astra no codex?

[16:35] **+55 62 9364-7674:** nao estou sabendo configurar a conta

[16:36] **+55 11 95194-1749:** Acho que quando tiver disponível eles vão falar

[16:36] **+55 11 95194-1749:** Falei com os cara eles disseram que assim que tiver tudo ok

[16:36] **+55 62 9364-7674:** pensei que haviam dito que estava disponivel ontem. my bad

[16:36] **+55 11 95194-1749:** Vai avisar no grupo

[16:36] **+55 11 95194-1749:** Eu tbm achei

[16:37] **+55 11 95194-1749:** Mas hj sai pelo que me informaram

[16:49] **+55 43 9106-8122:** Eu so vou querer o tutorial de como rodar o astra no mac

[17:54] __+41 79 676 70 89 entraram usando o link de convite__

[18:08] **+55 21 97605-5544:** pessoal, alguem teve esse erro   ? 

Não consigo acessar o Google Sheets diretamente porque o domínio docs.google.com está bloqueado na rede do workspace, e o ambiente Linux continua indisponível para processar arquivos localmente.

[18:45] **+55 51 9425-4975:** [Imagem]

[18:45] **+55 51 9425-4975:** Ta bombando ai?

[18:53] **+55 67 8210-0717:** [Imagem] caiu o de vcs?

[18:54] **+55 11 95194-1749:** Ele tá colocando gpt 6 agr eu acho

[18:59] **+55 21 97605-5544:** o meu n caiu

[18:59] __@dgm.dev entraram usando o link de convite__

[20:39] **+55 47 9618-4437:** [Imagem] 🚀 GPT-6 Astra chegou na GhostCLI.

O modelo mais forte que já rodou na Ghost. Uso de computador, engenharia de software, segurança cibernética e ciência em nível de fronteira — tudo direto do seu terminal.

Os números:

Terminal-Bench 4.0 — 57,9%
FrontierMath Tier 4 — 97,6%
GPQA Diamond — 96,0%
ExploitBench — 100%

Liberado agora para o plano Max. Sem fila, sem waitlist, sem config extra.

⏳ Atenção: a janela do Max dura 24 horas. Depois disso, o GPT-6 Astra passa a ser exclusivo do Enterprise.

Se você é Max, esse é o momento de usar. Rode:

claude --model gpt-6-astra

Compatível com Codex, VS Code, Claude Desktop e Claude Code.
Docs: https://ghostcli.dev/docs

[20:39] __[Notificação do sistema]__

[20:40] **+356 7737 9669:** create English guide how to add astra into claude desktop🙏🏼🙏🏼🙏🏼

[20:41] **+55 35 9946-8945:** Uhuuu

[20:42] **+55 51 9425-4975:** Como faz pra aparecer? N ta aparecendo nos modelos

[20:42] **+55 47 9618-4437:**
> _+55 51 9425-4975: Como faz pra aparecer? N ta aparecendo nos modelos_
não aparece pois não é modelo da anthropic

[20:42] **+55 47 9618-4437:** claude --model gpt-6-astra

[20:42] **+55 47 9618-4437:** ou se tiver usando no app do claude: /model gpt-6-astra

[20:42] **+55 35 9946-8945:**
> _+55 47 9618-4437: Imagem: 🚀 GPT-6 Astra chegou na GhostCLI.

O modelo mais forte que já rodou na Ghost. Uso de computador, engenharia de software, segurança cibernética e ciência em nível de fronteira — tudo direto do seu terminal.

Os números:

Terminal-Bench 4.0 — 57,9%
FrontierMath Tier 4 — 97,6%
GPQA Diamond — 96,0%
ExploitBench — 100%

Liberado agora para o plano Max. Sem fila, sem waitlist, sem config extra.

⏳ Atenção: a janela do Max dura 24 horas. Depois disso, o GPT-6 Astra passa a ser exclusivo do Enterprise.

Se você é Max, esse é o momento de usar. Rode:

claude --model gpt-6-astra

Compatível com Codex, VS Code, Claude Desktop e Claude Code.
Docs: https://ghostcli.dev/docs_
Trabalho com imagens ele funciona?

[20:43] **+55 47 9618-4437:**
> _+55 35 9946-8945: Trabalho com imagens ele funciona?_
sim

[20:43] **+55 35 9946-8945:** Geração tudo? Aii sim Poh

[20:43] **+55 35 9946-8945:** Vou conseguir fazer o que queria

[20:43] **+55 47 9618-4437:** [Imagem] ta top dms

[20:44] **Você:** pra usar ele na quele modo q se so vai falando e ele vai mexendo no pc tem q ser direto no ids da openai?

[20:44] **+55 51 9425-4975:**
> _+55 47 9618-4437: ou se tiver usando no app do claude: /model gpt-6-astra_
Ele muda pro opus depois

[20:45] **+55 47 9618-4437:** usa no codex então

[20:45] **+55 87 9128-0580:** [Imagem] Testar agora

[20:45] **+55 47 9618-4437:** [Imagem] aqui com /model gpt-6-astra ta dando pra usar no app do claude

[20:45] **+55 87 9128-0580:** [Figurinha]

[20:46] **+55 51 9425-4975:** Quanto é o plano empresarial?

[20:47] **+55 47 9618-4437:**
> _+55 51 9425-4975: Quanto é o plano empresarial?_
[Imagem]

[20:47] **+55 51 9425-4975:** Saquei

[20:49] **Você:**
> _Você: pra usar ele na quele modo q se so vai falando e ele vai mexendo no pc tem q ser direto no ids da openai?_
tem como? ou so usar ele como agente padrao ?

[20:50] **+55 11 95194-1749:** [Imagem]

[20:50] **+55 11 95194-1749:** Gpt 6 on

[20:51] **Jk Cli:**
> _+55 11 95194-1749: Imagem_
Gostei da ft vou usar

[20:52] **+55 83 8798-9954:** ❯ /model gpt-6-astra
  ⎿  API error: 502 {"type":"error","error":{"type":"api_error","message":"The model provider did not complete the request. Try again in a few moments."}}

[20:53] **+55 87 9128-0580:** Aqui tá dboa

[20:54] **+55 47 9971-5265:**
> _Você: tem como? ou so usar ele como agente padrao ?_
duvida tbm

[21:02] **+55 83 8798-9954:** tem como usar o codex com api key da ghost?

[21:18] **+55 49 9977-0032:** como faço pra usar o GPT6-astra? Usa a mesma chave key?

[21:19] **+55 47 9618-4437:**
> _+55 49 9977-0032: como faço pra usar o GPT6-astra? Usa a mesma chave key?_
sim

[21:19] **Jk Cli:** Chegamos para mudar esse mercado ❤️👻👻👻👻👻

[21:23] **+55 15 99726-7892:**
> _Jk Cli: Chegamos para mudar esse mercado ❤️👻👻👻👻👻_
Vcs são d+

[21:32] **+55 49 9977-0032:** Fiz a configuração, mas aparece essa msg:
■ You've hit your usage limit. Upgrade to Pro (https://chatgpt.com/explore/pro), visit
https://chatgpt.com/codex/settings/usage to purchase more credits or try again at 11:56 PM.

[21:32] **+55 47 9618-4437:**
> _+55 49 9977-0032: Fiz a configuração, mas aparece essa msg:
■ You've hit your usage limit. Upgrade to Pro (https://chatgpt.com/explore/pro), visit
https://chatgpt.com/codex/settings/usage to purchase more credits or try again at 11:56 PM._
Fez errada

[21:33] **+55 47 9618-4437:** Tá logada na sua conta

[21:33] **+55 49 9977-0032:** Essa limitação de janela é do codex que tenho direto da OpenIA, mas configurei a chave e api da gosh

[21:33] **+55 47 9618-4437:** https://ghostcli.dev/docs

[21:33] **+55 49 9977-0032:**
> _+55 47 9618-4437: https://ghostcli.dev/docs_
Segui o passo ali

[21:34] **+55 47 9618-4437:** O Codex ignora OPENAI_BASE_URL para o provedor padrão: precisa de um provedor próprio no config.toml (~/.codex/config.toml, ou %USERPROFILE%\.codex\config.toml no Windows).

config.toml

model = "gpt-6-astra"
model_provider = "ghostcli"

[model_providers.ghostcli]
name = "GhostCLI"
base_url = "https://ghostcli.dev/v1"
env_key = "GHOSTCLI_API_KEY"
wire_api = "responses"

[21:34] **+55 47 9618-4437:** E tem que ter na env a key

[21:35] **+55 47 9618-4437:** Powershell:
$env:GHOSTCLI_API_KEY = "Key aqui"
codex

[21:37] **+55 49 9977-0032:** Agora aparece essa msg:
■ Missing environment variable: gcli_minahchave.

[21:37] **+55 21 97605-5544:** o meu tb ta assim

[21:38] **+55 47 9618-4437:** Tá errado

[21:38] **+55 47 9618-4437:** Cópia oque eu mandei no env

[21:38] **+55 47 9618-4437:** E tem que setar a Key na path

[21:38] **+55 98 8536-3798:** [Imagem] O mizerável é um gênio KKKKKKKKKKKKK

[21:38] **+55 49 9977-0032:**
> _+55 47 9618-4437: Powershell:
$env:GHOSTCLI_API_KEY = "Key aqui"
codex_
Esse? Eu fiz isso

[21:38] **+55 47 9618-4437:** @Jk Cli

[21:38] **+55 47 9618-4437:** Cadê o enfermeiro mds pra ajudar o cara

[21:38] **+55 47 9618-4437:** Vou ter que arrumar mais gente no suporte

[21:39] **Jk Cli:** Sim

[21:39] **+55 47 9618-4437:**
> _+55 49 9977-0032: Esse? Eu fiz isso_
Baixa anydesk e manda o código no pv

[21:40] **+55 21 97605-5544:** precisando de ajuda no suporte ?

[21:40] **+55 47 9618-4437:** Sim

[21:42] **+55 51 9425-4975:**
> _+55 47 9618-4437: Sim_
Precisar eu faço uns frela

[21:42] **+55 51 9425-4975:** [Figurinha]

[21:43] **Jk Cli:** Quem quiser ser sup cria ticket no dc manda xp

[21:43] **Jk Cli:** Pra gente da uma analisada ❤️🙏

[21:43] **+55 27 99694-0707:** tem que ir DC e abrir ticket rapa

[21:44] **Jk Cli:**
> _+55 27 99694-0707: tem que ir DC e abrir ticket rapa_
@all quem tiver com alguma dificuldade chama o Eduardo no pv

[21:44] **+55 47 9618-4437:**
> _+55 51 9425-4975: Precisar eu faço uns frela_
vou te chamar ai

[21:44] **Jk Cli:** Pfvr

[21:44] **Jk Cli:** As cria ticket

[21:45] **+55 47 9618-4437:** ja ajudei o claito

[21:45] **Jk Cli:** O recomendado sempre é melhor o ticket

[21:45] **+55 47 9618-4437:** no anydesk

[21:45] **+55 21 97605-5544:**
> _+55 49 9977-0032: Agora aparece essa msg:
■ Missing environment variable: gcli_minahchave._
resolvido o problema do amigo @~Claito

[21:45] **Jk Cli:** Pra gente ver

[21:45] **Jk Cli:** Pfvr !!!

[21:45] **+55 49 9977-0032:** Aqui deu boa. o pessoal do suporte acessou pelo anydesk e agora ta rodando...
Valeu!!!!

[21:45] **Jk Cli:** Boa mete marcha rapaziada

[21:46] **+55 27 99694-0707:** @Jk Cli  rapa o jorge vai mandar o link do DC

[21:46] **+55 27 99694-0707:** pra quem nao entrou

[21:47] **+55 27 99694-0707:** entra, e abre ticket

[21:47] **+55 27 99694-0707:** sup rapido, aqui nois ajuda, coisas que demanda tempo so no DC

[21:49] **Jk Cli:** https://discord.gg/ghostcli

[21:50] **+55 47 9618-4437:** nem precisa abrir ticket

[21:50] **+55 47 9618-4437:** é so dar suporte no pv pow

[21:50] **+55 47 9618-4437:** acho que o limite de ticket ja até excedeu

[21:51] **+55 27 99694-0707:** Semana que vem o meu agente fica pronto, e vai salvar um monte de gente, ele vai montar prompt rpa voces de implementacao da api em qualquer S.O

[21:51] **Jk Cli:**
> _+55 47 9618-4437: é so dar suporte no pv pow_
So hj eu respondi +de 10 por ai

[21:51] **Jk Cli:** Aproveitem Astra ilimitado 👻👻👻

[21:52] **+55 27 99694-0707:**
> _+55 47 9618-4437: é so dar suporte no pv pow_
isso memo meu mano, so que to de mudanca

[21:52] **Jk Cli:** Acredito que somos o único que nessa corrida está oficialmente com Astra ilimitado

[21:52] **+55 27 99694-0707:** vo tenta ajudar o max que posso

[21:57] __+55 64 9652-3104 entraram usando o link de convite__

[22:01] **+55 54 9620-1797:** Eu vi aqui que o GPT 6 da ghost usa o qwen para gerar imagens, ta certo isso?

[22:01] **+55 54 9620-1797:** Eu nao conheço

[22:01] **+55 54 9620-1797:** Nao sei qual é o padrão do gpt

[22:02] **+55 47 9618-4437:**
> _+55 54 9620-1797: Eu vi aqui que o GPT 6 da ghost usa o qwen para gerar imagens, ta certo isso?_
Sem suporte a geração de imagens

[22:02] **+55 54 9620-1797:** A

[22:03] **+55 47 9618-4437:** Nossa proposta é focada em coding

[22:03] **+55 54 9620-1797:** Entendi...

[22:04] **Jk Cli:**
> _+55 47 9618-4437: Sem suporte a geração de imagens_
Isso mesmo!!

[22:05] **+55 11 95194-1749:** Plano empresarial aqui tá top gpt 6 parabéns a @~João @Jk Cli  pelo belíssimo trabalho 🥹

[22:08] **+55 22 98140-7236:** só tem gpt 6 no enterprise?

[22:09] **Jk Cli:** 1 dia para quem tem o max

[22:10] **Jk Cli:** E dps só funciona no empresas

[22:10] __+55 35 9810-0933 entraram usando o link de convite__

[22:45] **+55 49 9977-0032:** [Imagem] Esse reconnecting.... é algum erro?

[22:49] **+55 27 99694-0707:**
> _+55 49 9977-0032: Imagem: Esse reconnecting.... é algum erro?_
e sua primeiro uso?

[22:50] **+55 49 9977-0032:** sim, mas já me responderam no PV, valeu....

---

## 13 de setembro de 2026

[0:37] **+55 62 9444-5039:** Quanto é o plano personalizado só com o astra ?

[0:39] **+55 21 97605-5544:** @~01  vem na direção

[1:39] __+55 21 98759-1267 entraram usando o link de convite__

[4:19] **+356 7737 9669:** @~João  can u create  English  guide  how to setup astra  into claude desktop?

[4:20] **+55 47 9618-4437:**
> _+356 7737 9669: @~João  can u create  English  guide  how to setup astra  into claude desktop?_
Yes tmrw

[4:21] **+356 7737 9669:** [Imagem] Ahh astra only for enterprise 🥲

[7:23] **+55 87 9128-0580:** [Imagem]

[7:23] **+55 87 9128-0580:** Bom dia

[7:23] **+55 87 9128-0580:** [Figurinha]

[9:48] **@dgm.dev:**
> _+55 87 9128-0580: Imagem_
coding from prison ❤️

[9:48] **+55 87 9128-0580:** Yes

[9:48] **+55 87 9128-0580:** [Figurinha]

[10:23] **@ziadhatem:** _Mensagem apagada por um admin (Jk Cli)_

[10:23] **@ziadhatem:** _Mensagem apagada por um admin (Jk Cli)_

[10:39] **@ziadhatem:** _Mensagem apagada por um admin (Jk Cli)_

[10:45] __+55 48 9201-8857 entraram usando o link de convite__

[10:50] **+55 35 9946-8945:**
> _@ziadhatem: Imagem_
@Jk Cli

[10:51] **@ziadhatem:** _Mensagem apagada por um admin (Jk Cli)_

[10:52] **+55 11 99669-4521:**
> _+55 47 9618-4437: Imagem: 🚀 GPT-6 Astra chegou na GhostCLI.

O modelo mais forte que já rodou na Ghost. Uso de computador, engenharia de software, segurança cibernética e ciência em nível de fronteira — tudo direto do seu terminal.

Os números:

Terminal-Bench 4.0 — 57,9%
FrontierMath Tier 4 — 97,6%
GPQA Diamond — 96,0%
ExploitBench — 100%

Liberado agora para o plano Max. Sem fila, sem waitlist, sem config extra.

⏳ Atenção: a janela do Max dura 24 horas. Depois disso, o GPT-6 Astra passa a ser exclusivo do Enterprise.

Se você é Max, esse é o momento de usar. Rode:

claude --model gpt-6-astra

Compatível com Codex, VS Code, Claude Desktop e Claude Code.
Docs: https://ghostcli.dev/docs_
Sobre essa mensagem, ele estará disponível pra sempre no max, ou so nessas 24hrs?

[10:53] __Jk Cli removeu @ziadhatem__

[10:55] **Jk Cli:** Esses gringo mete o louco

[11:08] **+55 88 9490-6319:** Bom dia galera como faz pra usar o astra no Claude desktop?

[11:09] **Jk Cli:** Tem o tutorial lá no site

[11:09] **+55 88 9490-6319:** Não achei só achei pra terminal

[11:11] **Jk Cli:** Tem sim

[11:11] **+55 88 9490-6319:** Na verdade eu não entendi foi nada que tem no site kkk

[11:11] **Jk Cli:** Oxi geral só seguiu passo a passo do tutorial

[11:12] **+55 11 95194-1749:**
> _+55 88 9490-6319: Na verdade eu não entendi foi nada que tem no site kkk_
Eu fiz que está no tutorial no site e deu certo ;)

[11:12] **+55 88 9490-6319:**
> _+55 11 95194-1749: Eu fiz que está no tutorial no site e deu certo ;)_
Manda aí o tutorial qual é pf

[11:13] **+55 11 95194-1749:** https://ghostcli.dev/docs

[11:13] **+55 88 9490-6319:** Mas pra ter o astra o que vi lá é o que fiz sexta pra ativar API no claude

[11:13] **+55 11 95194-1749:** Astra vai ser removido hj pelo que eu sei , e só para galera do plano empresarial

[11:13] **+55 88 9490-6319:**
> _+55 11 95194-1749: Astra vai ser removido hj pelo que eu sei , e só para galera do plano empresarial_
Tô ligado mas queria testar

[11:14] **+55 24 99950-4499:**
> _Jk Cli: Esses gringo mete o louco_
O que ele fez? Kkk

[11:19] **+55 61 9148-6214:**
> _+55 11 95194-1749: Astra vai ser removido hj pelo que eu sei , e só para galera do plano empresarial_
Palhaçada isso.

[11:26] **+55 22 98111-9467:** Mas o Astra não é da OpenAi? Dá pra usar ele no Claude Code?

[11:27] **+55 11 95194-1749:** Eu uso em ambos

[11:29] **@dgm.dev:**
> _+55 22 98111-9467: Mas o Astra não é da OpenAi? Dá pra usar ele no Claude Code?_
You can use any model in Claude Code, it's just a harness

[11:30] **@dgm.dev:** You just need to correctly configure the message endpoint, completion endpoint, and API key

[11:30] **+55 44 9839-3639:** se algum admin conseguir me dar um Alô, preciso tirar uma duvida sobre a Enterprise

[11:31] **Jk Cli:** Opa pode chamar

[11:39] __+55 63 8434-9873 entraram usando o link de convite__

[11:58] **+55 21 98321-2828:** eu estou testando usando isso

export ANTHROPIC_BASE_URL=https://ghostcli.dev
export ANTHROPIC_API_KEY=gcli_...
claude --model claude-fable-5.1

[11:58] **+55 21 98321-2828:** e ele pede para eu logar no claude

[11:58] **+55 21 98321-2828:** [Imagem]

[11:58] **@dgm.dev:**
> _+55 21 98321-2828: e ele pede para eu logar no claude_
Que mensagem de erro você está recebendo?

[11:59] **+55 21 97605-5544:** essa não é mensagem de erro

[11:59] **+55 21 97605-5544:** é pra seleção do modo de uso como darkmode e etc..

[11:59] **+55 21 98321-2828:** eu sei, mas depois disso

[11:59] **+55 21 98321-2828:** [Imagem]

[11:59] **+55 21 98321-2828:** ele deveria ler as variaveis de ambiente e ja logar

[12:00] **@dgm.dev:**
> _+55 21 98321-2828: ele deveria ler as variaveis de ambiente e ja logar_
is that MacOS? Did you install claude by npm or the native binary?

[12:00] **+55 21 98321-2828:** é macos e claude nativo

[12:02] **+55 21 98321-2828:** (yes its macos and native bin)

[12:04] **+55 21 98321-2828:** pela api funciona

[12:05] **+55 21 98321-2828:** curl https://ghostcli.dev/v1/messages -X POST <br />-H "x-api-key:xxx" -H "content-type: application/json" <br />-d '{"model":"claude-fable-5.1","max_tokens":1024,"messages":[{"role":"user","content":"Ola"}]}'{"id":"msg_01NT2AykQEQ1DIGOyoFmKai9","type":"message","role":"assistant","content":[{"type":"text","text":"Olá! Como posso ajudar você hoje?"}],"model":"claude-fable-5.1","stop_reason":"end_turn","stop_sequence":null,"usage":{"input_tokens":8,"output_tokens":8}}

[12:06] **+55 21 98321-2828:** vou testar numa vps

[12:06] **Jk Cli:** Quando for assim é só criar ticket

[12:07] **+55 21 98321-2828:** discord?

[12:07] **+55 21 97605-5544:** isso

[12:11] **+55 11 96654-2013:** [Imagem] Hj está devagar pra todos?
Tive que liberar o IP lá novamente, mas cada comando básico está demorando mt a resposta, se está assim pensando, vai dar problema denovo ou deixo rolar?

Desculpe, sou novo aqui, só reparei que está mais lerdo

[12:12] **+55 11 96654-2013:** Foi, desconsidera, demorou além do normal, mas tive resposta.

[12:14] **+55 11 95194-1749:** Aqui tá de boa

[12:14] **+55 11 95194-1749:** Geralmente quando for assim. É só criar um ticket que eles respondem

[12:14] **+55 11 95194-1749:** Sou cliente empresa e só faço isso

[12:17] **+55 11 96654-2013:** Blzz valeu!

[12:28] __+380 97 514 0831 entraram usando o link de convite__

[13:06] **+55 54 9658-5317:** Já tá funcionando o Codex ?

[13:13] **+55 21 97605-5544:** Sim

[13:14] **+55 21 97605-5544:** Plano max até as 20h

[13:22] **+55 21 98321-2828:** Porque o fable 5.1 apareço como fable 5 no CC?

[13:24] **+55 21 97605-5544:**
> _+55 21 98321-2828: Porque o fable 5.1 apareço como fable 5 no CC?_
Tem como alterar lá mais no original depois de selecionado fica sssim também

[13:24] **+55 21 97605-5544:** Geralmente só exibem a versão major

[13:25] **+55 21 98321-2828:** Não fica

[13:25] **+55 21 98321-2828:** No plano do CC ele fica 5.1 e responde a pergunta que modelo você é de forma diferente

[13:26] **+55 21 97605-5544:** Vou verificar.. mas aqui a seleção tá usando o 5.1 de forma normal

[13:29] **+55 21 98321-2828:** Eu quero passar para o empresarial mas esse tipo de coisa me dá medo

[13:30] **+55 21 97605-5544:** Temos diversos usuários que comprovam a qualidade do empresarial

[13:30] **+55 21 97605-5544:** @~Rennyson Cavalcante, @~Tech

[13:31] **+55 21 97605-5544:** Se não me engano são os maiores no personalizado

[13:31] **+55 21 97605-5544:** E não tem problema com nada

[13:31] **+55 21 98321-2828:** Eu só quero de alguma forma confirmar que o fable 5.1 é o fable 5.1

[13:32] **+55 21 98321-2828:** Eu faço muita coisa complexa com matemática e estatística

[13:32] **+55 21 97605-5544:** Roda um benchmark

[13:32] **+55 21 97605-5544:** E verifica

[13:33] **+55 21 97605-5544:** Inclusive terá o astra ilimitado

[13:33] **+55 21 97605-5544:** No enterprise

[13:33] **+55 21 98321-2828:** Benchmark externo?

[13:34] **+55 21 98321-2828:** Não estou reclamando da qualidade da api, é boa, funciona bem

[13:34] **+55 21 97605-5544:** Então.. o modelo ele funciona. Inclusive eu tenho somente utilizado o fable 5.1

[13:35] **+55 21 97605-5544:** Sempre apareceu pra mim dessa forma. E não tive problemas

[13:42] **+55 21 98759-1267:** [Imagem] Boa tarde, pessoal.
Fiz o passo a passo para usar a API no Claude Desktop e está aparecendo essa mensagem abaixo. Liberei meu IP para a chav API já.

Alguém sabe o que fazer?

[13:43] **+55 21 97605-5544:**
> _+55 21 98759-1267: Imagem: Boa tarde, pessoal.
Fiz o passo a passo para usar a API no Claude Desktop e está aparecendo essa mensagem abaixo. Liberei meu IP para a chav API já.

Alguém sabe o que fazer?_
Liberou o ip no site ?

[13:43] **+55 21 98759-1267:**
> _+55 21 97605-5544: Liberou o ip no site ?_
Sim

[13:43] **+55 83 8782-8287:**
> _+55 21 97605-5544: @~Rennyson Cavalcante, @~Tech_
Opa, falando sobre minha experiência os caras aí são 100% verdadeiros e de confiança até o presente momentos não tive nenhum problema e fora que ela nem se compara com essas que tem no mercado que vendem como se fosse Claude , sendo que é um modelo nada a ver..

[13:44] **+55 83 8782-8287:** Sou cliente personalizado ou seja plano maior que enterprise

[13:45] **+55 47 9767-6672:**
> _+55 21 98759-1267: Imagem: Boa tarde, pessoal.
Fiz o passo a passo para usar a API no Claude Desktop e está aparecendo essa mensagem abaixo. Liberei meu IP para a chav API já.

Alguém sabe o que fazer?_
no meu eu dei um verificar novamente e foi

[13:46] **+55 21 98759-1267:** A mensagem detalhado do erro é essa:
"message: Gateway /v1/models returned HTTP 404. The connection test needs at least one model — add entries under Models to skip discovery, or fix the provider's model list endpoint.
httpStatus: 404
requestUrl: https://ghostcli.dev/v1/v1/models
endpoint: https://ghostcli.dev/
checkedAt: 2026-09-13T16:45:18.109Z"

Continua dando o erro, mesmo eu tentnado novamente.

[13:48] **+55 21 98759-1267:** Está dizendo que eu tenho de fazer uma lista de modelos... Você tiveram de fazer isso?

[13:48] **+55 21 97605-5544:**
> _+55 21 98759-1267: Está dizendo que eu tenho de fazer uma lista de modelos... Você tiveram de fazer isso?_
Qual modelo tá selecionado ?

[13:49] **+55 47 9618-4437:**
> _+55 21 98759-1267: A mensagem detalhado do erro é essa:
"message: Gateway /v1/models returned HTTP 404. The connection test needs at least one model — add entries under Models to skip discovery, or fix the provider's model list endpoint.
httpStatus: 404
requestUrl: https://ghostcli.dev/v1/v1/models
endpoint: https://ghostcli.dev/
checkedAt: 2026-09-13T16:45:18.109Z"

Continua dando o erro, mesmo eu tentnado novamente._
/v1 duplicado

[13:49] **+55 47 9618-4437:**
> _+55 11 96654-2013: Imagem: Hj está devagar pra todos?
Tive que liberar o IP lá novamente, mas cada comando básico está demorando mt a resposta, se está assim pensando, vai dar problema denovo ou deixo rolar?

Desculpe, sou novo aqui, só reparei que está mais lerdo_
Manutenção temporária

[13:53] **+55 21 98759-1267:**
> _+55 47 9618-4437: /v1 duplicado_
[Imagem] Não está não

[13:53] **+55 21 98759-1267:**
> _+55 21 97605-5544: Qual modelo tá selecionado ?_
Nenhum. Nem consegiu abrir. Fiz a configuração conforme o tutorial e já foi pro Claude Desktop com essa mensagem aparecendo.

[13:53] **+55 81 9398-4490:** Alguem ta usando o codex e ta fazendo edição de vídeo?

[13:53] **+55 35 9946-8945:**
> _+55 21 98759-1267: Imagem: Não está não_
não precisa do v1 no final

[13:54] **+55 21 97605-5544:**
> _+55 21 98759-1267: Imagem: Não está não_
Remove esse v1 daí

[13:54] **+55 35 9946-8945:**
> _+55 81 9398-4490: Alguem ta usando o codex e ta fazendo edição de vídeo?_
Tem como?

[13:54] **+55 81 9398-4490:**
> _+55 35 9946-8945: Tem como?_
Nao sei, perguntando ja pra eu ir la testar 😂

[13:55] **+55 21 98759-1267:**
> _+55 35 9946-8945: não precisa do v1 no final_
Era isso. Valeu!

[13:55] **+55 21 98759-1267:**
> _+55 21 97605-5544: Remove esse v1 daí_
Era isso. Valeu!

[13:56] **+55 21 97605-5544:**
> _+55 21 98759-1267: Era isso. Valeu!_
Nada irmão

[13:56] **+55 21 97605-5544:** Qualquer coisa só chamar

[13:56] **+55 21 97605-5544:** Mais alguém com erro ?

[14:00] **+55 47 9618-4437:**
> _+55 21 98759-1267: Imagem: Não está não_
Remove o /v1 amigo

[14:01] **+55 21 97605-5544:**
> _+55 47 9618-4437: Remove o /v1 amigo_
Já ajustou

[14:01] **+55 21 98759-1267:** Sim. Consegui aqui. Valeu pessoal!

[14:46] **Jk Cli:** On! Qualquer coisa só me chamar

[14:50] **+55 49 8843-1956:** Pessoal o fable 5 roda no cloude desktop?

[14:51] **+55 21 98759-1267:**
> _+55 49 8843-1956: Pessoal o fable 5 roda no cloude desktop?_
O 5.1 está torando aqui. O 5 não reparei se ainda aparece.

[14:52] **+55 11 95194-1749:**
> _+55 21 98321-2828: Eu quero passar para o empresarial mas esse tipo de coisa me dá medo_
Empresarial e a melhor coisa que você faz

[14:52] **+55 11 95194-1749:** Plano personalizado

[14:52] **+55 11 95194-1749:** Geralmente quando acontece uma intercorrência eu apenas crio ticket e o time resolve mais breve possível

[14:52] **+55 11 95194-1749:** Mas é raramente isso acontece

[14:53] **+55 11 95194-1749:**
> _+55 49 8843-1956: Pessoal o fable 5 roda no cloude desktop?_
Roda de boa!

[14:54] **+55 49 8843-1956:** Amanhã vou ter que pegar não tem como escapar 🙏🏻

[14:55] **+55 27 99691-4255:** o modelo novo gpt-6-astra não tem vision?

[14:59] **+55 21 97605-5544:**
> _+55 49 8843-1956: Pessoal o fable 5 roda no cloude desktop?_
Sim

[14:59] **+55 21 97605-5544:**
> _+55 49 8843-1956: Amanhã vou ter que pegar não tem como escapar 🙏🏻_
Bora.. to aqui só me chamar

[14:59] **+55 21 97605-5544:**
> _+55 27 99691-4255: o modelo novo gpt-6-astra não tem vision?_
Acho que so no codex

[15:05] **+55 49 8843-1956:** Eu fico imaginando eu que só sei o básico construo um app imagina quem usa de verde, vendi um app pra um salão aqui da cidade com ia para o cliente acessar via navegador 2k cobrei é muito loco isso

[15:05] **Jk Cli:** Sério ?

[15:05] **Jk Cli:** Caraca

[15:07] **+55 49 8843-1956:** Sim

[15:08] **+55 49 8843-1956:** Estou fazendo o protótipo pra apresentar

[15:08] **+55 49 8843-1956:** [Mensagem de album]

[15:08] **+55 49 8843-1956:** [Imagem]

[15:09] **+55 49 8843-1956:** [Imagem]

[15:09] **+55 21 97605-5544:** Bacana

[15:09] **+55 49 8843-1956:** Layout do app que o cliente acessa

[15:09] **+55 21 97605-5544:** PWA ?

[15:16] **Jk Cli:**
> _+55 49 8843-1956: Estou fazendo o protótipo pra apresentar_
Fico feliz d+ por iss Noss ai sim

[15:31] **+55 11 98191-0224:** quais modelos do chat gpt tem no plamo max alem do CODEX?

[15:35] **+55 27 99691-4255:** [Imagem]

[15:35] **+55 27 99691-4255:** [Imagem] Onde estou errando?

[15:39] **+55 81 9398-4490:**
> _+55 49 8843-1956: [album]_
Fez com o claude da ghost ?

[15:40] **+55 49 8843-1956:** Não, a imagem gerei no gpt e por enquanto estou usando o devin o swe-2 que está grátis por enquanto la

[15:42] **+55 21 97605-5544:**
> _+55 27 99691-4255: Imagem_
Já verificou no painel como está ?

[15:42] **+55 27 99691-4255:**
> _+55 21 97605-5544: Já verificou no painel como está ?_
Normal

[15:50] **+55 21 97605-5544:** abre um tkt la e passa o codigo do anydesk

[15:57] **+55 11 98191-0224:** tem como ver o historico do ip, pra ver o que foi consumido nele?

[16:00] **+55 83 8798-9954:** ja q tem o astra no Enterprise dava pra colocar o gpt 5.6 no max… kkkkk

[16:01] **+55 21 97605-5544:**
> _+55 11 98191-0224: tem como ver o historico do ip, pra ver o que foi consumido nele?_
acredito que n tenha.. vou buscar essa info pra você e te informo

[16:07] **+55 98 8536-3798:**
> _+55 83 8798-9954: ja q tem o astra no Enterprise dava pra colocar o gpt 5.6 no max… kkkkk_
Ja tem o astra

[16:07] **+55 83 8798-9954:** astra so hj no Max

[16:15] **+55 21 97605-5544:** @~Ivan Informática  pegando o enterprise já fica diretão o astra

[16:15] **+55 11 95194-1749:**
> _+55 21 97605-5544: @~Ivan Informática  pegando o enterprise já fica diretão o astra_
Recomendo !!

[16:15] **+55 11 95194-1749:** Feliz da vida ☺️☺️☺️

[16:25] **+55 47 9618-4437:** gpt 6 ta voando

[16:25] **+55 47 9618-4437:** comprem enterprise que daqui algumas horas gpt 6 só vai tar disponivel nele

[16:25] **+55 47 9618-4437:** [Imagem]

[16:29] **+55 98 8536-3798:**
> _+55 21 97605-5544: @~Ivan Informática  pegando o enterprise já fica diretão o astra_
Futuramente hehe

[16:45] **+55 27 99898-8510:**
> _+55 47 9618-4437: comprem enterprise que daqui algumas horas gpt 6 só vai tar disponivel nele_
Qual valor?

[16:45] **+55 47 9618-4437:**
> _+55 27 99898-8510: Qual valor?_
https://ghostcli.dev/

[16:45] **+55 47 9618-4437:** valores no site

[16:45] **+55 27 99898-8510:**
> _+55 47 9618-4437: https://ghostcli.dev/_
Está mostrnem dola

[16:46] **+55 27 99898-8510:** Por isso q perguntei 😅

[16:46] **+55 47 9618-4437:** [Imagem] valor do plano é 650,00 se ja tiver o max a diferença fica 485,10

[16:48] **+55 11 95194-1749:** Recomendo,compensa muito

[16:48] **+55 11 95194-1749:** Quando você pensa a longo prazo compensa bastante

[16:48] **+55 11 95194-1749:** Token está ficando cada vez mais caro bastante caro

[16:50] **+55 65 8407-8761:**
> _+55 47 9618-4437: Imagem: valor do plano é 650,00 se ja tiver o max a diferença fica 485,10_
não achei esse valor no site

[16:50] **Jk Cli:** Você já é assinante ?

[16:50] **Jk Cli:** Do max ?

[16:50] **+57 304 3533218:**
> _+55 49 8843-1956: [album]_
Wow, how did you achieve such a polished visual style? Was it with AI?

[16:50] **+55 65 8407-8761:** Não

[16:50] **+55 65 8407-8761:** esestou conhecendo agora

[16:50] **Jk Cli:** Esse valor fica pra quem já é assinante

[16:51] **+55 65 8407-8761:** Ata ]

[16:51] **Jk Cli:** Galera tá economizado bastante em tokens inclusive Astra ilimitado acredito que somos o primeiro do br a trazer isso

[16:51] **Jk Cli:** E do mundo

[16:52] **+55 47 9971-5265:** Eai jk, vai me responder privado man ?

[16:52] **+55 27 99898-8510:**
> _Jk Cli: Galera tá economizado bastante em tokens inclusive Astra ilimitado acredito que somos o primeiro do br a trazer isso_
Estao usando api oficial da openai ou modelo?

[16:52] **Jk Cli:**
> _+55 47 9971-5265: Eai jk, vai me responder privado man ?_
Cria ticket lá no discord e manda td blz

[16:52] **Jk Cli:** Vamos resolver hj

[16:52] **+55 27 99694-0707:** [Imagem] ta em manutencao rapa ?

[16:52] **Jk Cli:** Pode ser ?

[16:52] **+55 47 9971-5265:** Não dá pra criar ticket no discord

[16:53] **Jk Cli:** Mada um.

[16:53] **Jk Cli:** No geral

[16:53] **Jk Cli:** Consegue ?

[16:53] **+55 47 9618-4437:**
> _+55 27 99694-0707: Imagem: ta em manutencao rapa ?_
não

[16:53] **+55 27 99694-0707:**
> _+55 47 9618-4437: não_
uai

[16:53] **+55 47 9618-4437:** algo errado ai

[16:53] **+55 27 99694-0707:** vo upar de novo pra ve

[16:53] **+55 47 9618-4437:** na url da gateway

[16:53] **+55 47 9618-4437:** to usando normal aq

[16:53] **+55 27 99694-0707:**
> _+55 47 9618-4437: algo errado ai_
deve se

[16:53] **+55 27 99694-0707:** to vendo aki

[16:54] **+55 47 9971-5265:** @Jk Cli mandei

[16:55] **+55 27 99694-0707:**
> _+55 47 9618-4437: algo errado ai_
nada, vou setar meu gpt pra investigar o que ta rolando

[16:58] **+55 27 99694-0707:** [Imagem] fui banido sera?

[16:58] **+55 27 99694-0707:** vo gera a chave de novo

[16:58] **+55 27 99694-0707:** tava funfando redondin

[16:58] **+55 27 99694-0707:** q louco

[16:59] **+55 11 95194-1749:** Mano quando for assim é só mandar no discord dos caras que eles resolvem

[16:59] **+55 11 95194-1749:** Muito simples

[16:59] **+55 11 95194-1749:** Eu nunca mando nada aqui

[16:59] **+55 11 95194-1749:** E olha que eu pago 5k

[16:59] **+55 51 9184-0532:** Pra ser banido tem que estar fora das diretrizes

[17:00] **+55 27 99694-0707:**
> _+55 47 9618-4437: algo errado ai_
[Imagem]

[17:01] **+55 27 99694-0707:** deve ta em manutencao

[17:01] **Jk Cli:** Mano n é

[17:02] **+55 27 99694-0707:** oxe

[17:02] **Jk Cli:** Abre ticket lá

[17:03] **+55 27 99694-0707:**
> _+55 11 95194-1749: Mano quando for assim é só mandar no discord dos caras que eles resolvem_
ta funfando o seu ae pai

[17:09] **+55 21 97605-5544:** aqui ta de boa

[17:09] **+55 21 97605-5544:** acabei de rodar um benchmark

[17:17] **@dgm.dev:** [Imagem] its down

[17:17] **+55 47 9618-4437:**
> _@dgm.dev: Imagem: its down_
up again

[17:34] **@dgm.dev:** something is blocking claude code with the ghostcli provider API,I tried with Codex and it works

[17:34] **@dgm.dev:** [Figurinha]

[17:35] **@dgm.dev:** I prefer Claude Code rather than Codex, but I guess it works good

[18:12] **Você:** caiu ?

[18:13] **@dgm.dev:**
> _Você: caiu ?_
yes, doesn't work for me

[18:13] **@dgm.dev:** neither in Codex

[18:13] **Jk Cli:** Manutenção agora!!

[18:13] **Jk Cli:** Updates

[18:13] **Jk Cli:** Astra está on!!

[18:13] **Jk Cli:** Is back

[18:14] **@dgm.dev:**
> _Jk Cli: Astra está on!!_
Any discount code for Enterprise? 🫣

[18:15] **Você:** como puxa o astra no ids do claude ? so dar /model ? se eu dou /model gpt-6-astra volta pro opus sozinho

[18:15] **+55 47 9618-4437:** Modelos da anthropic estáveis e rápidos novamente.

[18:16] **+55 21 98759-1267:** No Claude Desktop não aparece nem o Astra nem o GLM 5.3.
Sabem como faz?

[18:17] **+55 47 9618-4437:**
> _+55 21 98759-1267: No Claude Desktop não aparece nem o Astra nem o GLM 5.3.
Sabem como faz?_
@~Marlon Martins

[18:17] **+55 47 9618-4437:**
> _Você: como puxa o astra no ids do claude ? so dar /model ? se eu dou /model gpt-6-astra volta pro opus sozinho_
@~Marlon Martins

[18:19] **Jk Cli:**
> _+55 21 98759-1267: No Claude Desktop não aparece nem o Astra nem o GLM 5.3.
Sabem como faz?_
Opa cria ticket

[18:19] **Jk Cli:** Ajudamos dc

[18:19] **+55 21 98759-1267:** Ok

[18:24] **@dgm.dev:** Parece que o Webfetch e o Websearch estao causando problemas com a API do GhostCLI, as ferramentas de busca nao estao bloqueadas no Codex. Voce sabe algo sobre isso?

[18:25] **+55 47 9618-4437:**
> _@dgm.dev: Parece que o Webfetch e o Websearch estao causando problemas com a API do GhostCLI, as ferramentas de busca nao estao bloqueadas no Codex. Voce sabe algo sobre isso?_
vem no pv

[18:31] **@fortytwowill:** [Imagem] Tá em manutenção?

[18:31] **+55 47 9618-4437:** sim

[18:32] **+55 47 9618-4437:**
> _@fortytwowill: Imagem: Tá em manutenção?_
me manda seu email no pv

[18:37] **@dgm.dev:** [Imagem]

[18:37] **+55 21 97605-5544:**
> _Você: como puxa o astra no ids do claude ? so dar /model ? se eu dou /model gpt-6-astra volta pro opus sozinho_
Fez a configuração do config.toml ?

[18:37] **+55 47 9618-4437:** Manutenção

[18:37] **+55 21 97605-5544:**
> _+55 21 98759-1267: No Claude Desktop não aparece nem o Astra nem o GLM 5.3.
Sabem como faz?_
Tem que atribuir via /model.. abre um ticket lá no discord

[18:37] __+55 47 9618-4437 mudou as configurações: somente admins podem enviar mensagens__

[19:01] **+55 47 9618-4437:** Aplicamos uma correção para resolver a instabilidade nos modelos da Anthropic, seguimos testando para confirmar que foi resolvido.

[19:08] **+55 47 9618-4437:** Instabilidade resolvida, chat aberto.

[19:08] __+55 47 9618-4437 mudou as configurações: somente admins podem enviar mensagens__

[19:09] **Jk Cli:** tudo ok

[19:10] **+55 47 9618-4437:** GPT-6 Saira do plano Max e estará disponivel somente para assinantes do enterprise daqui uma hora, se você tem algo rodando no GPT-6 nao esquece de fazer upgrade pra poder usar o Astra

[19:10] __[Notificação do sistema]__

[19:11] **+55 91 8744-7174:**
> _+55 47 9618-4437: GPT-6 Saira do plano Max e estará disponivel somente para assinantes do enterprise daqui uma hora, se você tem algo rodando no GPT-6 nao esquece de fazer upgrade pra poder usar o Astra_
Mas o GPT-5.6 Sol ainda ficará disponível no Max ?

[19:12] **+55 47 9618-4437:**
> _+55 91 8744-7174: Mas o GPT-5.6 Sol ainda ficará disponível no Max ?_
Não temos acesso a o GPT 5.6 Sol, somente o mais recente GPT 6

[19:12] **+55 47 9618-4437:** Os modelos da anthropic, Fable 5.1,Opus 5 e Sonnet 5 seguem no plano Max

[19:12] **+55 91 8744-7174:**
> _+55 47 9618-4437: Não temos acesso a o GPT 5.6 Sol, somente o mais recente GPT 6_
Ah sim, tranquilo!👍🏼

[19:19] **+55 21 98321-2828:** Enterpriseado

[19:20] **+55 21 98321-2828:** A prioridade na fila muda na hora?

[19:21] **+55 47 9618-4437:**
> _+55 21 98321-2828: A prioridade na fila muda na hora?_
Sim

[19:24] **+55 11 94293-8475:** @~João estende até amanhã o Astra pro Max, acho que assim como eu teve uma galera que não conseguiu testar

[19:30] **Jk Cli:** Isso mesmo galera

[19:32] **Jk Cli:** Desfrutem do melhor !!

[19:41] **+55 67 8210-0717:** Pessoal como funciona o plano entherprise, atende até quantas pessoas etc ?

[19:42] **+55 83 8782-8287:**
> _+55 67 8210-0717: Pessoal como funciona o plano entherprise, atende até quantas pessoas etc ?_
Muito top, tem prioridade, aguenta 50 IPS simultâneos e tem atendimento prioritário

[19:43] **+55 21 97605-5544:**
> _+55 67 8210-0717: Pessoal como funciona o plano entherprise, atende até quantas pessoas etc ?_
Bom demais irmão

[19:43] **+55 21 97605-5544:** Já pega logo

[19:43] **+55 83 8782-8287:** Muito top

[19:43] **+55 83 8782-8287:** Pode ir sem falta

[19:43] **@fortytwowill:** Vou abrir uma filial aqui no Canadá 😅

[19:44] **+55 11 95194-1749:**
> _+55 67 8210-0717: Pessoal como funciona o plano entherprise, atende até quantas pessoas etc ?_
Irmão eu gastava sem meme uns 15k mes para +

[19:44] **+55 11 95194-1749:** Muito muito mesmo

[19:44] **+55 11 95194-1749:** Aqui eu pago 5k feliz

[19:45] **+55 11 95194-1749:** Compensa muito o suporte dos caras e top

[19:45] **+55 83 8782-8287:**
> _+55 11 95194-1749: Aqui eu pago 5k feliz_
Eu pago 1.5k é muito bem pago

[19:45] **+55 83 8782-8287:**
> _+55 11 95194-1749: Compensa muito o suporte dos caras e top_
Total transparência

[19:45] **+55 83 8782-8287:** E o 01 do Astra

[19:45] **+55 11 95194-1749:**
> _+55 83 8782-8287: Eu pago 1.5k é muito bem pago_
Eu paguei 1.5 no começo dps n teve como eu falei eu quero pagar 5k logo ai os cara resolveram

[19:45] **+55 11 95194-1749:** Mas é top

[19:45] **+55 83 8782-8287:**
> _+55 11 95194-1749: Eu paguei 1.5 no começo dps n teve como eu falei eu quero pagar 5k logo ai os cara resolveram_
E eles resolvem tudo kkkk

[19:46] **+55 83 8782-8287:** O bom é isso

[19:46] **+55 11 95194-1749:** Cara me atende 2 da manhã

[19:46] **+55 11 95194-1749:** Num domingo

[19:46] **+55 83 8782-8287:** Kkkkkkk

[19:46] **+55 83 8782-8287:** Foda dms

[19:46] **+55 21 97605-5544:** Suporte 100%

[19:47] **+55 83 8782-8287:** E realmente é o modelo verdadeiro né não @~Tech

[19:47] **+55 83 8782-8287:** Pq pelo menos o meu antigo era “sabor” @Jk Cli 😂

[19:50] **+55 11 95194-1749:** Já tomei um golpe de 5k

[19:51] **+55 11 95194-1749:** De um sabor Claude

[19:51] **+55 11 95194-1749:** Raiva e ódio desses caras

[19:51] **+55 11 95194-1749:** Por isso que a ghost é top slk muito honesto os caras

[20:24] **+55 54 9658-5317:** Mais pra que existe o plano 20x do claude e do Codex?

[20:24] **+55 54 9658-5317:** Pagar 600 reais ou 1000 reais em uma api acho demais

[20:24] **+55 54 9658-5317:** Eu paguei 180 pra ter acesso a api
Até aí não me arrependo

[20:24] **+55 54 9658-5317:** Agora esses valores que vocês tão falando é loucura

[20:25] **+55 11 95194-1749:**
> _+55 54 9658-5317: Eu paguei 180 pra ter acesso a api
Até aí não me arrependo_
Mano vai por mim compensa muito mais

[20:25] **+55 11 95194-1749:** Eu pago 5k

[20:25] **+55 11 95194-1749:** N reclamo nd

[20:25] **+55 21 97605-5544:** A diferença que aqui você tem ilimitado

[20:26] **+55 11 95194-1749:** Depende da sua demanda

[20:31] **+55 27 99694-0707:** _Mensagem apagada_

[20:32] **+55 27 99694-0707:** _Mensagem apagada_

[20:32] **+55 27 99694-0707:** _Mensagem apagada_

[20:32] **+55 27 99694-0707:** _Mensagem apagada_

[20:36] **+55 62 8630-8180:** Quanto tá o Astra daqui?

[20:36] **+55 21 97605-5544:**
> _+55 62 8630-8180: Quanto tá o Astra daqui?_
Só no enterprise

[20:37] **+55 11 95194-1749:**
> _+55 62 8630-8180: Quanto tá o Astra daqui?_
Se você já tem plano só paga a diferença

[20:37] **+55 62 8630-8180:** Enterprise daqui cobra como?

[20:37] **+55 62 8630-8180:** Não tenho o plano

[20:37] **+55 62 8630-8180:** Qual o site? Pra eu parar de encher o saco de vocês kkkk

[20:37] **+55 11 95194-1749:** https://ghostcli.dev

[20:38] **+55 11 95194-1749:** Sou cliente tbm

[20:38] **+55 11 95194-1749:**
> _+55 62 8630-8180: Enterprise daqui cobra como?_
650

[20:38] **+55 11 95194-1749:** Mais bem pagos da sua vida vai por mim

[20:38] **+55 54 9658-5317:** [Figurinha]

[20:42] **+55 27 99694-0707:** [Imagem] so tarefa complexa fml, amanha cedo postarei o relatorio pra voces verem

[20:42] **+55 27 99694-0707:** o trem e poderoso

[20:44] **+55 27 99694-0707:** [Imagem] E lembrando que a openai bloqueou a compra do plano 20x ta fml, e aqui e ilimitado, so deixando esse bizu pra voces

[20:44] **+55 27 99694-0707:** Acorda RAPA vem para luz, e ilimitado carai

[20:48] **+55 69 9207-4370:**
> _+55 27 99694-0707: Imagem: E lembrando que a openai bloqueou a compra do plano 20x ta fml, e aqui e ilimitado, so deixando esse bizu pra voces_
Claude>>>max

[20:50] **+55 27 99694-0707:**
> _+55 69 9207-4370: Claude>>>max_
nop

[20:50] **+55 27 99694-0707:** openai mesmo

[20:50] **+55 27 99694-0707:** se a claude ceifo o deles n sei

[20:50] **Jk Cli:**
> _+55 27 99694-0707: Imagem: E lembrando que a openai bloqueou a compra do plano 20x ta fml, e aqui e ilimitado, so deixando esse bizu pra voces_
🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣🤣

[20:51] **+55 27 99694-0707:** openai lanco o astra e nao aguento a catrancada kkkkk

[20:51] **Jk Cli:** Claude fechando demanda de 20x

[20:58] **+55 91 8744-7174:** [Imagem] botei pra rodar no OpenClaw, tá lindo!!👏🏼👏🏼👏🏼

[20:59] **+55 77 8811-7500:**
> _+55 91 8744-7174: Imagem: botei pra rodar no OpenClaw, tá lindo!!👏🏼👏🏼👏🏼_
Também botei

[21:01] __+212 660-930731 entraram usando o link de convite__

[21:31] **+55 47 9618-4437:** @~Eduardo

[21:51] **+57 304 3533218:**
> _+55 11 94293-8475: @~João estende até amanhã o Astra pro Max, acho que assim como eu teve uma galera que não conseguiu testar_
@~João Concordo plenamente, muitos de nós não poderíamos experimentar hoje.

[22:04] **+55 51 9425-4975:** [Imagem] Bora pro turno da noite gurizada

[22:10] **+55 27 99694-0707:** [Imagem] caraio consigui vai chuve apanhando igual pia pequeno slk

[22:10] **+55 27 99694-0707:** nem sei o que eu fiz aki mds

[22:10] **+55 27 99694-0707:** pra ajudar a rapa nos ticket

[22:23] **+55 27 99694-0707:** [Imagem] e pressao na babilonia meus amigo, sera que aguenta pressao rapa?

[22:39] **+55 21 98759-1267:**
> _+55 91 8744-7174: Imagem: botei pra rodar no OpenClaw, tá lindo!!👏🏼👏🏼👏🏼_
Por acaso sabe colocar no Hermes Agent?

[22:43] **+55 91 8744-7174:**
> _+55 21 98759-1267: Por acaso sabe colocar no Hermes Agent?_
Nunca usei, o OpenClaw comecei a usa recentemente.
Pra configurar eu solicitei o GPT informando pra ele estudar a documentação ali no site da Ghost, ele me deu os passos, fui executando e deu certo!.

[22:44] **+55 21 98759-1267:**
> _+55 91 8744-7174: Nunca usei, o OpenClaw comecei a usa recentemente.
Pra configurar eu solicitei o GPT informando pra ele estudar a documentação ali no site da Ghost, ele me deu os passos, fui executando e deu certo!._
uhmmm. É uma boa ideia.
